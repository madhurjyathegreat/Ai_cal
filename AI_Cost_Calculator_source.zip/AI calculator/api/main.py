"""
main.py — FastAPI app exposing the deterministic costing engine.

Endpoints (this increment — estimates core only):
  POST /estimates        validate -> engine -> persist frozen -> return result
  GET  /estimates/{id}   read the IMMUTABLE stored estimate (never recomputed)

Error contract:
  422  request shape invalid (Pydantic) OR engine rejected the solution
       (unapproved component, missing price) — client-fixable, so 422.
  404  estimate id not found.
  500  catalogue data integrity problems (unknown pricing model) — our fault.

Run:  uvicorn main:app --reload   (from the api/ directory)
"""
from __future__ import annotations
import sys
from pathlib import Path

from fastapi import Depends, FastAPI, File, Form, Header, Request, UploadFile
from fastapi.exceptions import HTTPException
from fastapi.responses import FileResponse, JSONResponse

ENGINE_DIR = Path(__file__).resolve().parent.parent / "engine"
if str(ENGINE_DIR) not in sys.path:
    sys.path.insert(0, str(ENGINE_DIR))

from domain import (                                       # noqa: E402
    UnapprovedComponentError, MissingPriceError, UnknownPricingModelError,
)
from schemas import (                                      # noqa: E402
    EstimateRequest, EstimateResponse, LineOut,
    StoredEstimateResponse, StoredLineOut,
    ObservabilityOut, AssumptionOut, ProjectionResponse,
    CompareRequest, CompareCandidateOut, PriceChangeIn,
    ActualIn, ActualOut, SolutionOut, EstimateListItem,
    FiguresOut, TokensPerRequestOut, DraftIn, ComponentAdminIn,
)
from service import EstimateService                        # noqa: E402

DEFAULT_DB = str(Path(__file__).resolve().parent.parent / "db" / "calculator.db")


def create_app(db_path: str = DEFAULT_DB) -> FastAPI:
    app = FastAPI(title="AI Cost Calculator", version="0.1.0")
    service = EstimateService(db_path)

    # ---- Epic 3a AC4 / Epic 7: RBAC dependency ----
    # Identity is pluggable: locally the X-API-Key header maps to a role via
    # the api_key table; in production this same dependency validates an
    # Entra ID bearer token and reads the role claim. Routes don't change.
    def require_admin(x_api_key: str | None = Header(None)) -> str:
        who = service.resolve_role(x_api_key)
        if who is None:
            raise HTTPException(status_code=401, detail="Missing or unknown API key "
                                "(send X-API-Key; Entra ID replaces this in production)")
        holder, role = who
        if role != "Admin":
            raise HTTPException(status_code=403, detail=f"'{holder}' has role '{role}' "
                                "— Admin required for catalogue changes")
        return holder

    # ---- engine errors -> HTTP (the engine stays HTTP-ignorant) ----
    @app.exception_handler(UnapprovedComponentError)
    async def _unapproved(request: Request, exc: UnapprovedComponentError):
        return JSONResponse(status_code=422, content={
            "error": "unapproved_component", "component": exc.code, "detail": str(exc)})

    @app.exception_handler(MissingPriceError)
    async def _no_price(request: Request, exc: MissingPriceError):
        return JSONResponse(status_code=422, content={
            "error": "missing_price", "component": exc.code, "unit": exc.unit,
            "detail": str(exc)})

    @app.exception_handler(UnknownPricingModelError)
    async def _bad_model(request: Request, exc: UnknownPricingModelError):
        # a component referencing a model with no strategy is a DATA bug, not
        # a client mistake — surface as 500 so it's never silently absorbed
        return JSONResponse(status_code=500, content={
            "error": "unknown_pricing_model", "model": exc.code, "detail": str(exc)})

    # ---- routes ----
    @app.get("/", include_in_schema=False)
    def index():
        # no-store: the UI is a single self-contained file — never let a stale
        # cached copy run against a newer API (bit us twice during V2)
        return FileResponse(Path(__file__).resolve().parent / "static" / "index.html",
                            headers={"Cache-Control": "no-store, must-revalidate"})

    @app.get("/v3", include_in_schema=False)
    def v3_site():
        # V3 entry point = the public landing page (Estimation Ledger story:
        # hero, ticker, non-negotiables, 5-stage engine, product surfaces).
        # Its Sign in / Run an estimate CTAs lead to /v3/app.
        return FileResponse(Path(__file__).resolve().parent / "static" / "site.html",
                            headers={"Cache-Control": "no-store, must-revalidate"})

    @app.get("/v3/about", include_in_schema=False)
    def v3_about():
        # About page: the product story (manifesto, non-negotiables, engine,
        # surfaces) moved off the landing page per design feedback.
        return FileResponse(Path(__file__).resolve().parent / "static" / "about.html",
                            headers={"Cache-Control": "no-store, must-revalidate"})

    @app.get("/v3/app", include_in_schema=False)
    def v3_app():
        # V3 app = the Estimation Ledger reskin of the real calculator
        # (dark Entra sign-in → top-bar screens). Same API, same logic as V2;
        # only the presentation differs. V2 (at "/") is untouched.
        return FileResponse(Path(__file__).resolve().parent / "static" / "v3.html",
                            headers={"Cache-Control": "no-store, must-revalidate"})

    @app.get("/catalogue")
    def get_catalogue():
        """Read-only catalogue listing for the UI (components + current prices
        + archetypes). Purely presentational — estimates never read from here."""
        return service.get_catalogue_listing()

    @app.post("/estimates", response_model=EstimateResponse, status_code=201)
    def create_estimate(req: EstimateRequest) -> EstimateResponse:
        out = service.create_estimate(req)
        r = out["result"]
        cov = out["coverage"]
        return EstimateResponse(
            estimate_id=out["estimate_id"],
            solution_name=req.solution_name,
            total_low=r.total_low,
            total_expected=r.total_expected,
            total_high=r.total_high,
            by_business_area=r.by_business_area,
            lines=[
                LineOut(
                    component_code=l.priced.component.code,
                    component_name=l.priced.component.name,
                    unit=l.priced.unit,
                    quantity=l.priced.quantity,
                    unit_price=l.priced.unit_price,
                    cost=l.cost,
                    mi_tag=l.mi_tag,
                    derivation=d,
                    shared=l.shared,
                )
                for l, d in zip(r.lines, out["derivations"])
            ],
            warnings=list(r.warnings),
            priced_on=r.priced_on,
            shared_cost=r.shared_cost,
            observability=ObservabilityOut(
                coverage_pct=cov["coverage_pct"], covered=cov["covered"],
                missing=cov["missing"], warnings=cov["warnings"]),
            assumptions=[AssumptionOut(**a) for a in out["assumptions"]],
            confidence_pct=out["confidence"],
            confidence_band=out["confidence_band"],
            figures=FiguresOut(
                total=out["figures"]["total"], monthly=out["figures"]["monthly"],
                daily=out["figures"]["daily"],
                per_request_ai=out["figures"]["per_request_ai"],
                tokens_per_request=TokensPerRequestOut(**out["figures"]["tokens_per_request"]),
            ),
        )

    @app.post("/estimates/projection", response_model=ProjectionResponse)
    def project(req: EstimateRequest) -> ProjectionResponse:
        """Epic 5 AC1: monthly series with compounding growth. A VIEW over the
        engine — nothing is persisted; estimates stay the single saved artefact."""
        p = service.project(req)
        return ProjectionResponse(months=p["months"], growth_rate_monthly=p["growth"],
                                  monthly=p["monthly"], total=p["total"],
                                  warnings=p["warnings"])

    @app.post("/estimates/compare", response_model=list[CompareCandidateOut])
    def compare(creq: CompareRequest):
        """Epic 5 AC2-3: the same solution priced once per candidate model —
        repeated pure engine runs, no new maths."""
        try:
            rows = service.compare(creq.request, creq.swap_from, creq.candidates)
        except ValueError as e:
            return JSONResponse(status_code=422, content={
                "error": "bad_swap_from", "detail": str(e)})
        return [CompareCandidateOut(**row) for row in rows]

    @app.get("/estimates", response_model=list[EstimateListItem])
    def list_estimates(limit: int = 50):
        """Epic 6: the saved-estimate ledger, newest first."""
        return [EstimateListItem(
                    estimate_id=r["id"], name=r["name"],
                    archetype_code=r["archetype_code"], business_area=r["business_area"],
                    total_expected=r["total_expected"], priced_on=r["priced_on"],
                    created_at=r["created_at"], created_by=r["created_by"])
                for r in service.list_estimates(min(limit, 200))]

    # ---- Epic 3a: catalogue admin (Admin role enforced, actions logged) ----
    @app.post("/admin/prices", status_code=201)
    def change_price(pc: PriceChangeIn, actor: str = Depends(require_admin)):
        """A price change is a DATA operation: the open row is closed at
        effective_from and a new dated row is inserted, stamped with the
        editor's identity. History is never overwritten; saved estimates
        are untouched (frozen copies)."""
        out = service.change_price(pc.component_code, pc.unit, pc.new_price,
                                   pc.currency, pc.effective_from, actor=actor)
        if out is None:
            return JSONResponse(status_code=404, content={
                "error": "not_found", "detail": f"No component '{pc.component_code}'"})
        return out

    @app.post("/admin/components", status_code=201)
    def add_component(c: ComponentAdminIn, actor: str = Depends(require_admin)):
        """Epic 7 AC3: add a catalogue component — data, logged, no deploy."""
        out = service.add_component(c, actor)
        if out is None:
            return JSONResponse(status_code=409, content={
                "error": "already_exists", "detail": f"Component '{c.code}' exists"})
        return out

    @app.post("/admin/components/{code}/archive")
    def archive_component(code: str, actor: str = Depends(require_admin)):
        """Epic 7 AC3: archived components disappear from the catalogue and
        cannot be estimated — but their frozen history remains intact."""
        if not service.set_component_archived(code, True, actor):
            return JSONResponse(status_code=404, content={"error": "not_found"})
        return {"code": code, "archived": True}

    @app.post("/admin/components/{code}/restore")
    def restore_component(code: str, actor: str = Depends(require_admin)):
        if not service.set_component_archived(code, False, actor):
            return JSONResponse(status_code=404, content={"error": "not_found"})
        return {"code": code, "archived": False}

    @app.get("/admin/log")
    def get_admin_log(actor: str = Depends(require_admin), limit: int = 100):
        """Epic 7 AC3: every admin change, who and when."""
        return {"log": service.admin_log(min(limit, 500))}

    # ---- identity: any signed-in user can ask who they are ----
    @app.get("/whoami")
    def whoami(x_api_key: str | None = Header(None)):
        who = service.resolve_role(x_api_key)
        if who is None:
            return JSONResponse(status_code=401, content={
                "error": "unauthenticated", "detail": "Unknown or missing API key"})
        holder, role = who
        return {"holder": holder, "role": role}

    # ---- Epic 7: user management (Admin only) ----
    @app.get("/admin/users")
    def list_users(actor: str = Depends(require_admin)):
        return {"users": service.list_users()}

    @app.post("/admin/users", status_code=201)
    def add_user(body: dict, actor: str = Depends(require_admin)):
        holder = (body.get("holder") or "").strip()
        role = body.get("role")
        if not holder or role not in ("User", "Admin"):
            return JSONResponse(status_code=422, content={
                "error": "bad_request", "detail": "holder + role (User|Admin) required"})
        out = service.add_user(holder, role, actor)
        if out is None:
            return JSONResponse(status_code=409, content={
                "error": "already_exists", "detail": f"User '{holder}' already exists"})
        return out   # includes the one-time api_key

    @app.post("/admin/users/{holder}/deactivate")
    def deactivate_user(holder: str, actor: str = Depends(require_admin)):
        if not service.set_user_active(holder, False, actor):
            return JSONResponse(status_code=409, content={
                "error": "cannot_deactivate",
                "detail": "User not found, or this is the last active Admin"})
        return {"holder": holder, "active": False}

    @app.post("/admin/users/{holder}/activate")
    def activate_user(holder: str, actor: str = Depends(require_admin)):
        if not service.set_user_active(holder, True, actor):
            return JSONResponse(status_code=404, content={"error": "not_found"})
        return {"holder": holder, "active": True}

    # ---- Phase 2: the LLM advisor — asks, proposes, human signs off ----
    @app.post("/advisor/chat")
    def advisor_chat(body: dict):
        """ReAct loop: returns {type: question|proposal|refusal}. Grounded
        retrieval-first on the approved catalogue; server-side validation
        strips anything else. The advisor NEVER prices."""
        message = (body.get("message") or "").strip()
        if not message:
            return JSONResponse(status_code=422, content={
                "error": "empty_message", "detail": "Say something about the solution."})
        out = service.advisor_chat(body.get("session_id"), message,
                                   body.get("created_by", "api"))
        if out.get("error") == "no_api_key":
            return JSONResponse(status_code=503, content=out)
        if out.get("error") == "llm_failed":
            return JSONResponse(status_code=502, content=out)
        if out.get("error") == "unknown_session":
            return JSONResponse(status_code=404, content=out)
        return out

    @app.post("/advisor/upload")
    async def advisor_upload(file: UploadFile = File(...), created_by: str = Form("api")):
        """Document-first entry: upload a BRD/FRD/Stage-0 deck; the advisor
        extracts the text, distills the requirement brief itself, then runs
        the same ask→propose pipeline. Same guardrails; it still never prices."""
        data = await file.read()
        if len(data) > 15 * 1024 * 1024:
            return JSONResponse(status_code=413, content={
                "error": "too_large", "detail": "File too large — 15 MB max."})
        try:
            text = service.extract_document_text(file.filename, data)
        except ValueError:
            return JSONResponse(status_code=415, content={
                "error": "unsupported_type",
                "detail": "Unsupported file type — upload .pdf, .docx, .pptx, .txt or .md."})
        except Exception:
            return JSONResponse(status_code=422, content={
                "error": "unreadable", "detail": "Could not read the document."})
        if len(text) < 80:
            return JSONResponse(status_code=422, content={
                "error": "too_little_text",
                "detail": "The document contains too little readable text to derive a brief."})
        out = service.advisor_from_document(file.filename, text, created_by)
        if out.get("error") == "no_api_key":
            return JSONResponse(status_code=503, content=out)
        if out.get("error") == "llm_failed":
            return JSONResponse(status_code=502, content=out)
        return out

    @app.get("/advisor/assist/config")
    def advisor_assist_config():
        """The field assistants' single source of truth: the conversion
        dictionary + per-field playbooks. Chip clicks resolve client-side
        against exactly this data — zero LLM calls on the common path."""
        return service.assist_config()

    @app.post("/advisor/assist")
    def advisor_assist(body: dict):
        """One extraction step for a Usage-field popover. The LLM names shapes;
        the server converts and clamps. mode='mine' reads the document brief
        (client confirms before applying); mode='answer' reads free text."""
        field = (body.get("field") or "").strip()
        text = (body.get("text") or "").strip()
        if not field or not text:
            return JSONResponse(status_code=422, content={
                "error": "missing_input", "detail": "field and text are required."})
        out = service.assist(field, text,
                             mode=body.get("mode", "answer"),
                             history=body.get("history"))
        if out.get("error") == "unknown_field":
            return JSONResponse(status_code=404, content=out)
        if out.get("error") == "no_api_key":
            return JSONResponse(status_code=503, content=out)
        if out.get("error") == "llm_failed":
            return JSONResponse(status_code=502, content=out)
        return out

    @app.get("/advisor/sessions/{session_id}")
    def get_advisor_session(session_id: str):
        """Resume a session: proposals are durable — a page reload never loses one."""
        s = service.get_advisor_session(session_id)
        if s is None:
            return JSONResponse(status_code=404, content={"error": "not_found"})
        return s

    @app.post("/advisor/signoff")
    def advisor_signoff(body: dict):
        """Records the human decision PER COMPONENT (audit trail), then returns
        the accepted draft for the builder. Pricing still happens in /estimates."""
        session_id = body.get("session_id")
        decisions = body.get("decisions") or []
        if not session_id or not isinstance(decisions, list):
            return JSONResponse(status_code=422, content={
                "error": "bad_request", "detail": "session_id + decisions[] required"})
        out = service.advisor_signoff(session_id, decisions,
                                      body.get("decided_by", "api"))
        if out is None:
            return JSONResponse(status_code=404, content={
                "error": "not_found", "detail": "No proposal on that session"})
        return out

    # ---- Epic 6 AC1: drafts (save the journey at any stage) ----
    @app.post("/drafts", status_code=201)
    def save_draft(d: DraftIn):
        return {"draft_id": service.save_draft(d.name, d.payload, d.created_by)}

    @app.get("/drafts")
    def list_drafts():
        return service.list_drafts()

    @app.get("/drafts/{draft_id}")
    def get_draft(draft_id: str):
        d = service.get_draft(draft_id)
        if d is None:
            return JSONResponse(status_code=404, content={"error": "not_found"})
        return d

    # ---- Epic 8 AC2/AC5: business view dashboard ----
    @app.get("/dashboard/business")
    def business_dashboard(area: str | None = None):
        """Aggregated attributed cost by MI tag across ALL saved estimates,
        optionally filtered by business area."""
        return service.business_dashboard(area)

    @app.get("/dashboard/business/export")
    def business_dashboard_export(area: str | None = None):
        d = service.business_dashboard(area)
        import csv
        import io
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["mi_tag", "total", "estimates", "filter_area"])
        for row in d["by_mi_tag"]:
            w.writerow([row["mi_tag"], row["total"], row["estimates"], d["filter_area"] or "ALL"])
        from fastapi.responses import Response
        return Response(content=buf.getvalue(), media_type="text/csv", headers={
            "Content-Disposition": 'attachment; filename="business-view.csv"'})

    @app.get("/admin/prices/{component_code}")
    def get_price_history(component_code: str):
        """Full dated price history — the audit trail Epic 3a AC3 asks for."""
        rows = service.price_history(component_code)
        if not rows:
            return JSONResponse(status_code=404, content={
                "error": "not_found", "detail": f"No prices for '{component_code}'"})
        return {"component_code": component_code, "history": rows}

    # ---- Epic 8: actuals + export ----
    @app.post("/estimates/{estimate_id}/actuals", status_code=201)
    def add_actual(estimate_id: str, actual: ActualIn):
        """Record a real cost against a FROZEN estimate. Comparison only —
        the estimate itself never changes."""
        ok = service.add_actual(estimate_id, actual.period, actual.amount)
        if not ok:
            return JSONResponse(status_code=404, content={
                "error": "not_found", "detail": f"No estimate with id {estimate_id}"})
        return {"estimate_id": estimate_id, "period": actual.period,
                "amount": str(actual.amount)}

    @app.get("/estimates/{estimate_id}/export")
    def export_csv(estimate_id: str):
        """Epic 8: the frozen estimate as CSV for finance."""
        stored = service.get_estimate(estimate_id)
        if stored is None:
            return JSONResponse(status_code=404, content={
                "error": "not_found", "detail": f"No estimate with id {estimate_id}"})
        import csv
        import io
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["component", "unit", "quantity", "unit_price_used", "line_total", "mi_tag"])
        for l in stored["lines"]:
            w.writerow([l["component_name"], l["unit"], l["quantity"],
                        l["unit_price_used"], l["line_total"], l["mi_tag"]])
        w.writerow([])
        w.writerow(["TOTAL_LOW", stored["total_low"]])
        w.writerow(["TOTAL_EXPECTED", stored["total_expected"]])
        w.writerow(["TOTAL_HIGH", stored["total_high"]])
        w.writerow(["PRICED_ON", stored["priced_on"]])
        # Epic 9 AC5: the final report reflects every assumption's status
        if stored.get("assumptions_json"):
            import json as _json
            w.writerow([])
            w.writerow(["assumption", "value", "source", "status"])
            for a in _json.loads(stored["assumptions_json"]):
                w.writerow([a["field"], a["value"], a["source"], a["status"]])
        from fastapi.responses import Response
        return Response(content=buf.getvalue(), media_type="text/csv", headers={
            "Content-Disposition": f'attachment; filename="estimate-{estimate_id[:8]}.csv"'})

    @app.get("/estimates/{estimate_id}", response_model=StoredEstimateResponse)
    def get_estimate(estimate_id: str):
        stored = service.get_estimate(estimate_id)
        if stored is None:
            return JSONResponse(status_code=404, content={
                "error": "not_found", "detail": f"No estimate with id {estimate_id}"})
        sol = stored.get("solution") or {}
        return StoredEstimateResponse(
            estimate_id=stored["id"],
            total_low=stored["total_low"],
            total_expected=stored["total_expected"],
            total_high=stored["total_high"],
            priced_on=stored["priced_on"],
            created_by=stored["created_by"],
            lines=[
                StoredLineOut(
                    component_name=l["component_name"],
                    unit=l["unit"],
                    quantity=l["quantity"],
                    unit_price_used=l["unit_price_used"],
                    line_total=l["line_total"],
                    mi_tag=l["mi_tag"],
                )
                for l in stored["lines"]
            ],
            solution=SolutionOut(
                name=sol.get("name"), description=sol.get("description"),
                archetype_code=sol.get("archetype_code"),
                business_area=sol.get("business_area"),
                usage=sol.get("usage", {}), components=sol.get("components", []),
            ),
            actuals=[ActualOut(period=a["period"], amount=a["amount"],
                               recorded_at=a["recorded_at"])
                     for a in stored.get("actuals", [])],
            actual_total=stored.get("actual_total"),
            expected_to_date=stored.get("expected_to_date"),
            variance=stored.get("variance"),
        )

    return app


app = create_app()
