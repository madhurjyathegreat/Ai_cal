"""
service.py — EstimateService: the ONLY place the API touches the engine.

Responsibilities (and nothing more):
  1. Translate the request DTO -> the engine's frozen SolutionSpec.
  2. Load a CatalogueView snapshot via the repository (one read per estimate).
  3. Run the pure engine.
  4. Persist the immutable estimate; return (id, result).
The service does NO arithmetic and holds NO prices — same rules as everywhere.
"""
from __future__ import annotations
import sys
from datetime import date
from pathlib import Path

# the engine package uses bare imports (from domain import ...); put it on the path
ENGINE_DIR = Path(__file__).resolve().parent.parent / "engine"
if str(ENGINE_DIR) not in sys.path:
    sys.path.insert(0, str(ENGINE_DIR))

import engine                                              # noqa: E402
from domain import (                                       # noqa: E402
    SolutionSpec, SolutionComponent, UsageAssumptions, TokenAnatomy,
    EstimateResult, ComponentType,
)
from repository import SqliteCatalogueRepository           # noqa: E402

from schemas import EstimateRequest                        # noqa: E402

from decimal import Decimal                                # noqa: E402


def _n(d) -> str:
    """Format a Decimal/int for humans: thousands separators, no trailing zeros."""
    d = Decimal(str(d))
    if d == d.to_integral_value():
        return f"{int(d):,}"
    return f"{d.normalize():,f}"


def _build_derivations(spec: SolutionSpec, catalogue, usage: UsageAssumptions,
                       result: EstimateResult) -> list[str]:
    """One human-readable derivation string per costed line, in line order.
    Mirrors (never re-does) the engine's stage-1 quantity logic: every number
    here is read from the SAME merged usage the engine used, and the printed
    total is the engine's own quantity/cost — so the trace cannot drift."""
    u = usage
    elig = "" if u.eligibility_rate == 1 else f" × {_n(u.eligibility_rate * 100)}% eligible"
    months = u.time_horizon_months
    anatomy_note = (" (input from token anatomy)"
                    if u.anatomy is not None and not u.anatomy.is_empty() else "")

    # which lines were auto-added dependencies, and of what
    direct = {sc.component_code for sc in spec.components}
    parents: dict[str, set[str]] = {}
    for sc in spec.components:
        comp = catalogue.get(sc.component_code)
        if comp is None:
            continue
        for dep in catalogue.dependencies_of(comp):
            parents.setdefault(dep.requires_code, set()).add(comp.name)

    out: list[str] = []
    for l in result.lines:
        comp = l.priced.component
        unit, qty, price, cost = l.priced.unit, l.priced.quantity, l.priced.unit_price, l.cost
        in_tok = u.effective_input_tokens()
        cached = u.cached_input_tokens_per_request

        if unit in ("input_token", "cached_input_token", "output_token"):
            if unit == "input_token" and comp.component_type == ComponentType.LLM_MODEL and cached:
                per_call = f"({_n(in_tok)} − {_n(cached)} cached) tok/call"
            elif unit == "input_token":
                per_call = f"{_n(in_tok)} tok/call{anatomy_note}"
            elif unit == "cached_input_token":
                per_call = f"{_n(cached)} cached tok/call"
            else:
                per_call = f"{_n(u.output_tokens_per_request)} out tok/call"
            out.append(
                f"{_n(u.requests_per_month)} req/mo{elig} × {_n(u.calls_per_request)} calls"
                f" × {per_call} × {_n(months)} mo = {_n(qty)} tokens"
                f" · ÷1M × ${price:,} = ${cost:,.2f}")

        elif unit in ("month", "hour"):
            base = qty / Decimal(months)
            dep_note = ""
            if comp.code in parents and comp.code not in direct:
                dep_note = f"auto-dependency of {', '.join(sorted(parents[comp.code]))} · "
            out.append(f"{dep_note}{_n(base)} × {_n(months)} mo"
                       f" × ${price:,}/{unit} = ${cost:,.2f}")

        else:  # licence, GB and other one-off units — no time multiplication
            out.append(f"{_n(qty)} {unit} × ${price:,} = ${cost:,.2f} (one-off, not × horizon)")
        if l.shared:
            out[-1] += "  ·  SHARED — costed elsewhere, NOT in this estimate's totals"
    return out


def _requests_per_month(u) -> int:
    """Epic 1a volume adapter: translate business-stated volume into the raw
    monthly number the engine consumes. Engine stays untouched."""
    if u.volume is None:
        return u.requests_per_month
    v = u.volume
    if v.mode == "per_day":
        return v.count * 30                              # documented convention
    if v.mode == "per_user":
        return int(Decimal(v.count) * v.per_unit_rate)   # users x req/user/month
    return v.count                                       # per_event: events ARE requests


def _to_spec(req: EstimateRequest) -> SolutionSpec:
    """DTO -> frozen engine spec. Field-for-field, no interpretation."""
    anatomy = None
    if req.usage.anatomy is not None:
        anatomy = TokenAnatomy(**req.usage.anatomy.model_dump())
    usage = UsageAssumptions(
        requests_per_month=_requests_per_month(req.usage),
        input_tokens_per_request=req.usage.input_tokens_per_request,
        output_tokens_per_request=req.usage.output_tokens_per_request,
        cached_input_tokens_per_request=req.usage.cached_input_tokens_per_request,
        calls_per_request=req.usage.calls_per_request,
        eligibility_rate=req.usage.eligibility_rate,
        time_horizon_months=req.usage.time_horizon_months,
        growth_rate_monthly=req.usage.growth_rate_monthly,
        anatomy=anatomy,
    )
    # Epic 8 AC1: one or more business areas — normalised to a comma list
    area = req.business_area
    if isinstance(area, list):
        area = ", ".join(a.strip() for a in area if a.strip()) or None
    return SolutionSpec(
        archetype_code=req.archetype_code,
        components=tuple(
            SolutionComponent(c.component_code, c.quantity, shared=c.shared)
            for c in req.components
        ),
        usage=usage,
        business_area=area,
    )


class EstimateService:
    def __init__(self, db_path: str):
        self._db_path = db_path
        self._repo = SqliteCatalogueRepository(db_path)

    def get_catalogue_listing(self) -> dict:
        """Read-only listing for the UI: components (+ their CURRENT prices)
        and archetypes. Presentation data only — the engine never sees this."""
        import json as _json
        import sqlite3
        from datetime import date as _date
        today = _date.today().isoformat()
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        try:
            prices_by_comp: dict[str, list[dict]] = {}
            for r in conn.execute(
                "SELECT component_code, unit, unit_price, currency FROM price "
                "WHERE effective_from <= ? AND (effective_to IS NULL OR effective_to > ?)",
                (today, today)):
                prices_by_comp.setdefault(r["component_code"], []).append({
                    "unit": r["unit"], "unit_price": r["unit_price"],
                    "currency": r["currency"]})
            components = [{
                "code": r["code"], "name": r["name"],
                "component_type": r["component_type"],
                "approved": bool(r["approved"]),
                "default_unit": r["default_unit"], "mi_tag": r["mi_tag"],
                "observability_category": r["observability_category"],
                "cloud": r["cloud"], "layer": r["layer"],
                "description": r["description"],
                "default_quantity": r["default_quantity"],
                "sizing_unit": r["sizing_unit"],
                "current_prices": prices_by_comp.get(r["code"], []),
            } for r in conn.execute(
                "SELECT * FROM component WHERE archived=0 ORDER BY component_type, name")]
            # V2: template bill-of-materials — pre-selected components per archetype
            bom: dict[str, list[dict]] = {}
            for r in conn.execute("SELECT archetype_code, component_code, quantity, shared "
                                  "FROM archetype_component"):
                bom.setdefault(r["archetype_code"], []).append({
                    "component_code": r["component_code"],
                    "quantity": r["quantity"], "shared": bool(r["shared"])})
            archetypes = [{
                "code": r["code"], "name": r["name"],
                "low_range": r["low_range"], "high_range": r["high_range"],
                "default_usage": _json.loads(r["default_usage"]) if r["default_usage"] else {},
                "components": bom.get(r["code"], []),
            } for r in conn.execute("SELECT * FROM archetype ORDER BY name")]
            dependencies = [{
                "component_code": r["component_code"],
                "requires_code": r["requires_code"], "ratio": r["ratio"],
            } for r in conn.execute("SELECT * FROM component_dependency")]
            return {"components": components, "archetypes": archetypes,
                    "dependencies": dependencies}
        finally:
            conn.close()

    def create_estimate(self, req: EstimateRequest) -> dict:
        import json as _json
        spec = _to_spec(req)
        priced_on = req.priced_on or date.today()
        catalogue = self._repo.load_catalogue()            # fresh snapshot
        result = engine.run_estimate(spec, catalogue, priced_on=priced_on)
        merged = engine._effective_usage(spec, catalogue)
        assumptions, confidence = _assumption_report(                # Epic 9
            spec, merged, explicit=req.usage.model_fields_set)
        estimate_id = self._repo.save_estimate(
            spec, result, created_by=req.created_by,
            name=req.solution_name, description=req.description,
            assumptions_json=_json.dumps(assumptions))     # Epic 9 AC5: frozen statuses
        # trace strings use the engine's OWN merged usage (same function it runs)
        derivations = _build_derivations(spec, catalogue, merged, result)
        # Epic 2 AC5: coverage across the register's six dimensions (+ alerting)
        coverage = engine.observability_coverage(spec, catalogue,
                                                 expected=EXPECTED_DIMS)
        # Epic 2 AC6: quantify the financial impact of missing observability
        if coverage["warnings"] and result.total_expected > 0:
            lo = (result.total_expected * Decimal("0.05")).quantize(Decimal("0.01"))
            hi = (result.total_expected * Decimal("0.15")).quantize(Decimal("0.01"))
            coverage["warnings"][0] += f" Financial impact: ~${lo:,} to ${hi:,} unbudgeted."
        return {
            "estimate_id": estimate_id, "result": result, "derivations": derivations,
            "coverage": coverage, "assumptions": assumptions, "confidence": confidence,
            "confidence_band": _band(confidence),
            "figures": _figures(result, merged),
        }

    # ---- Epic 5: projection + model comparison (pure engine calls) ----
    def project(self, req: EstimateRequest) -> dict:
        spec = _to_spec(req)
        priced_on = req.priced_on or date.today()
        catalogue = self._repo.load_catalogue()
        merged = engine._effective_usage(spec, catalogue)
        months = merged.time_horizon_months
        series = engine.project_monthly(spec, catalogue, priced_on, months=months)
        # the engine's simple model repeats one-off components in every month's
        # base (documented in project_monthly) — surface that, don't hide it
        warnings = []
        one_offs = [c.component_code for c in spec.components
                    if (comp := catalogue.get(c.component_code)) is not None
                    and comp.default_unit not in ("month", "hour")
                    and comp.component_type.value in ("licence",)]
        if one_offs:
            warnings.append(
                f"One-off components ({', '.join(one_offs)}) are counted in every "
                f"month of this run-rate projection — read it as monthly run-rate "
                f"only, or project without them.")
        return {"months": months, "growth": str(merged.growth_rate_monthly),
                "monthly": series, "total": sum(series, Decimal(0)),
                "warnings": warnings}

    def compare(self, req: EstimateRequest, swap_from: str, candidates: list[str]) -> list[dict]:
        spec = _to_spec(req)
        if swap_from not in {c.component_code for c in spec.components}:
            raise ValueError(f"swap_from '{swap_from}' is not in the solution's components")
        priced_on = req.priced_on or date.today()
        catalogue = self._repo.load_catalogue()
        results = engine.compare_models(spec, catalogue, priced_on, candidates, swap_from)
        out = []
        for code, r in results.items():
            comp = catalogue.get(code)
            out.append({"model_code": code,
                        "model_name": comp.name if comp else code,
                        "total_low": r.total_low, "total_expected": r.total_expected,
                        "total_high": r.total_high})
        out.sort(key=lambda x: x["total_expected"])
        return out

    # ---- Epic 3a: price change as DATA (close old dated row, insert new) ----
    def change_price(self, component_code: str, unit: str, new_price: Decimal,
                     currency: str, effective_from: date | None,
                     actor: str = "system") -> dict | None:
        import sqlite3
        eff = (effective_from or date.today()).isoformat()
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        try:
            comp = conn.execute("SELECT code FROM component WHERE code=?",
                                (component_code,)).fetchone()
            if comp is None:
                return None
            old = conn.execute(
                "SELECT id, unit_price FROM price WHERE component_code=? AND unit=? "
                "AND effective_to IS NULL", (component_code, unit)).fetchone()
            if old is not None:
                conn.execute("UPDATE price SET effective_to=? WHERE id=?", (eff, old["id"]))
            # Epic 3a AC3: the new dated row carries the editor's identity
            conn.execute(
                "INSERT INTO price (component_code, unit, unit_price, currency, effective_from, changed_by) "
                "VALUES (?,?,?,?,?,?)", (component_code, unit, str(new_price), currency, eff, actor))
            conn.commit()
        finally:
            conn.close()
        self._log_admin(actor, "price_change", f"{component_code}/{unit}",
                        f"{old['unit_price'] if old else 'NEW'} -> {new_price}")
        return {"component_code": component_code, "unit": unit,
                "old_price": old["unit_price"] if old else None,
                "new_price": str(new_price), "effective_from": eff,
                "changed_by": actor}

    def price_history(self, component_code: str) -> list[dict]:
        import sqlite3
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute(
                "SELECT unit, unit_price, currency, effective_from, effective_to "
                "FROM price WHERE component_code=? ORDER BY unit, effective_from",
                (component_code,)).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    # ---- Epic 6 + 8 ----
    # ---- Epic 3a AC4 / Epic 7: application-layer RBAC ----
    # Locally the identity source is the api_key table; in production the same
    # role check reads Entra ID token claims — the caller code doesn't change.
    def resolve_role(self, api_key: str | None) -> tuple[str, str] | None:
        """Returns (holder, role) or None if the key is unknown/inactive."""
        if not api_key:
            return None
        import sqlite3
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        try:
            r = conn.execute("SELECT holder, role FROM api_key WHERE key=? AND active=1",
                             (api_key,)).fetchone()
            return (r["holder"], r["role"]) if r else None
        finally:
            conn.close()

    # ---- Epic 7: user management (Admin only) ----
    def list_users(self) -> list[dict]:
        import sqlite3
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        try:
            return [{"holder": r["holder"], "role": r["role"],
                     "active": bool(r["active"]),
                     "key_hint": r["key"][:4] + "…" + r["key"][-4:]}
                    for r in conn.execute(
                        "SELECT key, holder, role, active FROM api_key ORDER BY role, holder")]
        finally:
            conn.close()

    def add_user(self, holder: str, role: str, actor: str) -> dict | None:
        """Create a user with a freshly generated API key. Returns the key ONCE
        (like a password — the admin copies it, we never show it again)."""
        import secrets
        import sqlite3
        key = "key-" + secrets.token_hex(20)
        conn = sqlite3.connect(self._db_path)
        try:
            exists = conn.execute("SELECT 1 FROM api_key WHERE holder=?", (holder,)).fetchone()
            if exists:
                return None
            conn.execute("INSERT INTO api_key (key, holder, role, active) VALUES (?,?,?,1)",
                         (key, holder, role))
            conn.commit()
        finally:
            conn.close()
        self._log_admin(actor, "user_add", holder, f"role={role}")
        return {"holder": holder, "role": role, "api_key": key}

    def set_user_active(self, holder: str, active: bool, actor: str) -> bool:
        """Deactivate (remove access) or reactivate a user. We deactivate rather
        than hard-delete so the audit log's actor references stay meaningful."""
        import sqlite3
        conn = sqlite3.connect(self._db_path)
        try:
            # guard: never let the last active Admin be removed
            if not active:
                r = conn.execute("SELECT role, active FROM api_key WHERE holder=?",
                                 (holder,)).fetchone()
                if r and r[0] == "Admin":
                    admins = conn.execute(
                        "SELECT COUNT(*) FROM api_key WHERE role='Admin' AND active=1").fetchone()[0]
                    if admins <= 1:
                        return False   # would lock everyone out of admin
            cur = conn.execute("UPDATE api_key SET active=? WHERE holder=?",
                               (1 if active else 0, holder))
            conn.commit()
            found = cur.rowcount > 0
        finally:
            conn.close()
        if found:
            self._log_admin(actor, "user_activate" if active else "user_deactivate", holder)
        return found

    def _log_admin(self, actor: str, action: str, target: str, detail: str = ""):
        import sqlite3
        conn = sqlite3.connect(self._db_path)
        try:
            conn.execute("INSERT INTO admin_log (actor, action, target, detail) VALUES (?,?,?,?)",
                         (actor, action, target, detail))
            conn.commit()
        finally:
            conn.close()

    def admin_log(self, limit: int = 100) -> list[dict]:
        import sqlite3
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        try:
            return [dict(r) for r in conn.execute(
                "SELECT * FROM admin_log ORDER BY id DESC LIMIT ?", (limit,))]
        finally:
            conn.close()

    # ---- Epic 7 AC3: component add / archive / restore (data, logged) ----
    def add_component(self, c, actor: str) -> dict | None:
        import sqlite3
        conn = sqlite3.connect(self._db_path)
        try:
            exists = conn.execute("SELECT 1 FROM component WHERE code=?", (c.code,)).fetchone()
            if exists:
                return None
            conn.execute(
                "INSERT INTO component (code,name,component_type,approved,pricing_model_code,"
                "default_unit,mi_tag,observability_category,cloud,layer,description) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (c.code, c.name, c.component_type, 1 if c.approved else 0,
                 c.pricing_model_code, c.default_unit, c.mi_tag,
                 c.observability_category, c.cloud, c.layer, c.description))
            conn.commit()
        finally:
            conn.close()
        self._log_admin(actor, "component_add", c.code, c.name)
        return {"code": c.code, "name": c.name}

    def set_component_archived(self, code: str, archived: bool, actor: str) -> bool:
        import sqlite3
        conn = sqlite3.connect(self._db_path)
        try:
            cur = conn.execute("UPDATE component SET archived=? WHERE code=?",
                               (1 if archived else 0, code))
            conn.commit()
            found = cur.rowcount > 0
        finally:
            conn.close()
        if found:
            self._log_admin(actor, "archive" if archived else "restore", code)
        return found

    # ---- Epic 6 AC1: drafts (builder state, saved before pricing) ----
    def save_draft(self, name: str | None, payload: dict, created_by: str) -> str:
        import json as _json
        import sqlite3
        import uuid
        draft_id = str(uuid.uuid4())
        conn = sqlite3.connect(self._db_path)
        try:
            conn.execute("INSERT INTO draft (id, name, payload, created_by) VALUES (?,?,?,?)",
                         (draft_id, name, _json.dumps(payload), created_by))
            conn.commit()
        finally:
            conn.close()
        return draft_id

    def list_drafts(self, limit: int = 20) -> list[dict]:
        import sqlite3
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        try:
            return [dict(r) for r in conn.execute(
                "SELECT id, name, created_by, created_at FROM draft "
                "ORDER BY created_at DESC, rowid DESC LIMIT ?", (limit,))]
        finally:
            conn.close()

    def get_draft(self, draft_id: str) -> dict | None:
        import json as _json
        import sqlite3
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        try:
            r = conn.execute("SELECT * FROM draft WHERE id=?", (draft_id,)).fetchone()
            if r is None:
                return None
            return {"id": r["id"], "name": r["name"], "created_by": r["created_by"],
                    "created_at": r["created_at"], "payload": _json.loads(r["payload"])}
        finally:
            conn.close()

    # ---- Epic 8 AC2/AC5: cross-estimate business view ----
    def business_dashboard(self, area: str | None = None) -> dict:
        """Aggregate ATTRIBUTED (non-shared) line totals by MI tag across all
        saved estimates, optionally filtered by the solution's business area."""
        import sqlite3
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        try:
            area_filter = "AND s.business_area LIKE ? " if area else ""
            params = [f"%{area}%"] if area else []
            # money stays Decimal: aggregate the TEXT-stored decimals in Python
            rows = conn.execute(
                "SELECT el.mi_tag, el.line_total, e.id AS eid "
                "FROM estimate_line el JOIN estimate e ON e.id = el.estimate_id "
                "JOIN solution s ON s.id = e.solution_id "
                "WHERE el.shared = 0 " + area_filter, params).fetchall()
            totals: dict[str, Decimal] = {}
            est_ids: dict[str, set] = {}
            for r in rows:
                tag = r["mi_tag"] or "(untagged)"
                totals[tag] = totals.get(tag, Decimal(0)) + Decimal(str(r["line_total"]))
                est_ids.setdefault(tag, set()).add(r["eid"])
            n = conn.execute(
                "SELECT COUNT(*) FROM estimate e JOIN solution s ON s.id=e.solution_id "
                + ("WHERE s.business_area LIKE ?" if area else ""), params).fetchone()[0]
            by_tag = sorted(totals.items(), key=lambda kv: kv[1], reverse=True)
            return {"filter_area": area, "estimate_count": n,
                    "by_mi_tag": [{"mi_tag": tag,
                                   "total": str(t.quantize(Decimal("0.01"))),
                                   "estimates": len(est_ids[tag])} for tag, t in by_tag]}
        finally:
            conn.close()

    # ================= Phase 2: the LLM advisor =================
    # ReAct loop: the model asks clarifying questions until satisfied, then
    # proposes a full draft (archetype + components + usage). Grounding is
    # retrieval-first — the model is shown ONLY the approved catalogue — and
    # the server validates the proposal anyway: unknown/unapproved component
    # codes are stripped before a human ever sees them. The advisor never
    # prices anything; the signed-off draft re-enters POST /estimates.

    MAX_QUESTIONS = 5
    MAX_ITERATIONS = 3   # architect->evaluator loop bound (cost + latency)

    def _openai_key(self) -> str | None:
        import os
        key = os.environ.get("OPENAI_API_KEY")
        if key:
            return key.strip()
        from pathlib import Path as _P
        f = _P(self._db_path).resolve().parent.parent / ".openai_key"
        return f.read_text().strip() if f.exists() else None

    def _llm_call(self, messages: list[dict], max_tokens: int = 4096) -> dict:
        """One chat-completion call returning the model's JSON action.
        Injectable: tests replace this method with scripted responses.

        max_tokens defaults high: the architect emits one JSON object covering
        every component with rationale, how-to-use, confidence, reason and
        alternatives — for a full RAG + observability solution that runs to
        thousands of tokens, and a truncated reply is an unterminated JSON string
        the parser rejects (seen as 'An agent call failed' in the UI)."""
        import json as _json
        import os
        import urllib.request
        key = self._openai_key()
        if not key:
            raise RuntimeError("no_api_key")
        req = urllib.request.Request(
            "https://api.openai.com/v1/chat/completions", method="POST")
        req.add_header("Authorization", f"Bearer {key}")
        req.add_header("Content-Type", "application/json")
        body = _json.dumps({
            "model": os.environ.get("OPENAI_MODEL", "gpt-4o"),
            "messages": messages,
            "temperature": 0,
            "max_tokens": max_tokens,
            "response_format": {"type": "json_object"},
        }).encode()
        with urllib.request.urlopen(req, body, timeout=90) as r:
            out = _json.loads(r.read())
        choice = out["choices"][0]
        content = choice["message"]["content"]
        try:
            return _json.loads(content)
        except _json.JSONDecodeError as e:
            # a length-capped reply is truncated JSON; say so precisely so the
            # UI can suggest retrying rather than surfacing a raw parser offset
            if choice.get("finish_reason") == "length":
                raise ValueError("the model's reply was too long and was cut off "
                                 "before it finished — please try again") from e
            raise

    def _catalogue_context(self) -> str:
        """Retrieval-first grounding: the ONLY components any agent ever sees
        are approved ones; unapproved kit is simply absent from their world."""
        import json as _json
        listing = self.get_catalogue_listing()
        comps = [{
            "code": c["code"], "name": c["name"], "type": c["component_type"],
            "layer": c["layer"], "unit": c["default_unit"],
            "observability_category": c["observability_category"],
            "what_it_is": c["description"],
        } for c in listing["components"] if c["approved"]]
        archs = [{
            "code": a["code"], "name": a["name"],
            "default_usage": a["default_usage"],
            "template_components": a["components"],
        } for a in listing["archetypes"]]
        return (f"THE APPROVED CATALOGUE (only these component codes exist):\n{_json.dumps(comps)}\n\n"
                f"SOLUTION TEMPLATES (archetypes):\n{_json.dumps(archs)}")

    # ---- the three agents + triage, each one focused prompt ----

    def _triage_prompt(self) -> str:
        return f"""You are the intake triage for a bank's AI cost calculator. Understand the user's
solution through clarifying questions; you never propose components yourself — a separate
architect agent does that once you are satisfied.

{self._catalogue_context()}

RULES:
1. Ask ONE question at a time, only what you genuinely need (what it does, volumes, what share of
   events reach the AI, whether infra is shared with existing systems). At most {self.MAX_QUESTIONS} questions.
2. When you have enough, reply ready. If after {self.MAX_QUESTIONS} questions this still is not an
   AI solution you can brief, refuse.
3. NEVER mention prices or totals.
4. Reply with EXACTLY ONE JSON object, one of:
   {{"action":"ask","question":"..."}}
   {{"action":"refuse","reason":"..."}}
   {{"action":"ready","brief":"a complete requirement brief: what the solution does, volumes,
     eligibility, sharing arrangements, business area — everything the architect needs"}}"""

    def _inventory_prompt(self, brief: str) -> list[dict]:
        return [{"role": "system", "content": f"""You are the DEPLOYMENT COMPLETENESS agent. Given a
requirement brief and the approved catalogue, produce the capability checklist a COMPLETE production
deployment of this solution needs — the holistic view: experience/hosting, orchestration, intelligence
(models/guardrails), data platform, observability (logs/metrics/traces/alerting + drift/rag_eval/
governance where relevant), and human-in-the-loop if autonomous. Mark each capability required or
optional for THIS solution, and list which catalogue codes could satisfy it.
If the brief involves generative AI in any form (model calls, tokens, drafting, reasoning
agents), the checklist MUST include a generation-model capability whose catalogue_options
are llm_model components — a runtime or orchestrator hosts a model, it is not one.
For each capability also rate your confidence that it is genuinely needed for THIS brief:
"high" = clearly needed, "medium" = usually needed for this shape of solution but the brief
does not confirm it, "low" = speculative. Give a one-sentence reason.

{self._catalogue_context()}

Reply with EXACTLY this JSON: {{"checklist":[{{"capability":"...","layer":"experience|orchestration|intelligence|data_platform|observability","required":true,"catalogue_options":["code",...],"confidence":"high|medium|low","confidence_reason":"one sentence"}}]}}"""},
                {"role": "user", "content": f"REQUIREMENT BRIEF:\n{brief}"}]

    def _architect_prompt(self, brief: str, checklist: dict,
                          feedback: dict | None) -> list[dict]:
        import json as _json
        fb = ""
        if feedback:
            fb = (f"\n\nTHE EVALUATOR REJECTED YOUR PREVIOUS ATTEMPT (score "
                  f"{feedback.get('score')}). Fix these issues:\n{_json.dumps(feedback.get('issues', []))}")
        return [{"role": "system", "content": f"""You are the SOLUTION ARCHITECT agent. Given the brief
and the deployment checklist, select the components for the COMPLETE solution and specify the right
way to use each. Cover every REQUIRED checklist capability or say in the summary why one is skipped.
You NEVER compute costs — a deterministic engine prices, and a human signs off first.
HARD RULE 1: if the workflow calls a model (any calls per request, any tokens per request, any
generation or reasoning step), the proposal MUST include exactly one llm_model catalogue
component. Agent runtimes and orchestrators HOST models — they are never the model itself.
HARD RULE 2: if the solution retrieves from a document corpus or knowledge base (RAG, semantic
search, "grounded on documents", a RAG Assistant / document-Q&A archetype), the proposal MUST
include BOTH an embedding model AND a vector store. A search service alone does not create
embeddings; an embedding model alone has nowhere to store or search them. Never propose one
without the other for a retrieval solution.
HARD RULE 3: observability is a set of DISTINCT priced components, not one catch-all. If the brief
asks for observability or monitoring, propose the components for EACH capability it names —
logging, metrics, tracing and alerting are the baseline for any production AI; add model-drift
monitoring for any model in production, a RAG/answer-quality evaluation harness for any retrieval
solution, and AI governance/audit where compliance is in scope. Do not assume one logging tool
covers metrics, tracing, drift or evaluation — it does not. It is your job to include them, not the user's.

EVERY decision you make carries a confidence rating — this applies to the WHOLE proposal, not just
model picks:
- Each COMPONENT: how confident you are that THIS specific pick (vs a substitute from the same
  catalogue) is the right call. "high" = structurally required, no reasonable catalogue alternative
  for this brief. "medium" = sound default, but a listed alternative could do the job with acceptable
  trade-offs. "low" = speculative — depends on assumptions the user has not confirmed.
  Wherever the catalogue lists a viable substitute, name it in alternatives — this applies to every
  category: models (if a smaller/cheaper model with well-crafted system and user prompts could handle
  the workload, rate the bigger model medium and name the cheaper ones), embedding sizes,
  orchestration/hosting choices, vector stores, observability tooling, and licences vs building on
  platform services. alternatives may ONLY contain catalogue codes.
- The ARCHETYPE choice: how well this template genuinely fits the brief.
- The USAGE numbers: how firmly the brief supports them ("high" = user stated them, "medium" =
  reasonable inference, "low" = mostly guessed).

{self._catalogue_context()}

Keep it TERSE to fit one JSON object: every free-text field (rationale, how_to_use,
confidence_reason, summary sentences) is at most ONE short clause of ≤ 14 words. Never repeat
text between fields. The whole reply must be a single, complete, valid JSON object.

Reply with EXACTLY ONE JSON object:
{{"archetype_code":"...","solution_name":"...","business_area":"...",
 "archetype_confidence":"high|medium|low","archetype_confidence_reason":"≤14 words",
 "summary":"2-3 short sentences incl. any deliberately-skipped checklist items",
 "usage":{{"requests_per_month":int,"input_tokens_per_request":int,"output_tokens_per_request":int,
          "calls_per_request":number,"eligibility_rate":number,"time_horizon_months":int}},
 "usage_confidence":"high|medium|low","usage_confidence_reason":"≤14 words",
 "components":[{{"component_code":"...","quantity":number,"shared":bool,
                "rationale":"≤14 words","how_to_use":"≤14 words",
                "confidence":"high|medium|low","confidence_reason":"≤14 words",
                "alternatives":["catalogue codes that could substitute, cheapest-viable first"]}}]}}"""},
                {"role": "user", "content": f"REQUIREMENT BRIEF:\n{brief}\n\n"
                 f"DEPLOYMENT CHECKLIST:\n{_json.dumps(checklist)}{fb}"}]

    def _evaluator_prompt(self, brief: str, checklist: dict,
                          proposal: dict) -> list[dict]:
        import json as _json
        return [{"role": "system", "content": f"""You are the EVALUATOR agent — a sceptical reviewer.
Judge the architect's proposal against the brief and the deployment checklist:
completeness (every required capability covered?), shared flags (does sharing match what the user
said?), usage sanity (do the numbers reflect the brief?), model choice sanity (fit for the workload?),
and INTERNAL CONSISTENCY: a proposal whose usage assumes tokens or model calls but contains no
llm_model component is incomplete — that is a HIGH-severity issue (a runtime is not a model).
You NEVER discuss costs.

{self._catalogue_context()}

Reply with EXACTLY this JSON: {{"satisfied":true|false,"score":0-100,
 "issues":[{{"severity":"high|medium|low","issue":"...","fix":"..."}}]}}
satisfied=true only if score >= 80 and no high-severity issues."""},
                {"role": "user", "content": f"BRIEF:\n{brief}\n\nCHECKLIST:\n"
                 f"{_json.dumps(checklist)}\n\nPROPOSAL:\n{_json.dumps(proposal)}"}]

    @staticmethod
    def _clean_confidence(value) -> str:
        """Whitelist a confidence rating — anything unrecognised becomes 'medium'."""
        conf = str(value or "").strip().lower()
        return conf if conf in ("low", "medium", "high") else "medium"

    def _ground_checklist(self, checklist_raw, approved: dict) -> list[dict]:
        """Guardrail for the inventory agent's checklist: layers whitelisted,
        catalogue options filtered to approved codes, confidence sanitized."""
        layers = {"experience", "orchestration", "intelligence",
                  "data_platform", "observability"}
        clean = []
        for item in (checklist_raw or []):
            if not isinstance(item, dict) or not item.get("capability"):
                continue
            layer = str(item.get("layer", "")).strip().lower()
            clean.append({
                "capability": str(item["capability"])[:200],
                "layer": layer if layer in layers else "orchestration",
                "required": bool(item.get("required", False)),
                "catalogue_options": [o for o in (item.get("catalogue_options") or [])
                                      if o in approved][:8],
                "confidence": self._clean_confidence(item.get("confidence")),
                "confidence_reason": str(item.get("confidence_reason", ""))[:300],
            })
        return clean

    def _ground_proposal(self, proposal: dict, brief: str = "") -> dict:
        """Server-side guardrail: strip anything not in the APPROVED catalogue,
        clamp usage to sane bounds. The prompt promises; this enforces."""
        listing = self.get_catalogue_listing()
        approved = {c["code"]: c for c in listing["components"] if c["approved"]}
        arch_codes = {a["code"] for a in listing["archetypes"]}
        stripped = []
        clean_components = []
        for c in proposal.get("components", []):
            code = c.get("component_code")
            if code in approved:
                # confidence: whitelist only — anything else becomes "medium"
                conf = self._clean_confidence(c.get("confidence"))
                # alternatives: approved catalogue codes only, no self, deduped
                alts, seen = [], {code}
                for a in (c.get("alternatives") or []):
                    if a in approved and a not in seen:
                        alts.append(a)
                        seen.add(a)
                clean_components.append({
                    "component_code": code,
                    "name": approved[code]["name"],
                    "layer": approved[code]["layer"],
                    "quantity": str(c.get("quantity", 1)),
                    "shared": bool(c.get("shared", False)),
                    "rationale": str(c.get("rationale", ""))[:400],
                    "how_to_use": str(c.get("how_to_use", ""))[:400],
                    "confidence": conf,
                    "confidence_reason": str(c.get("confidence_reason", ""))[:300],
                    "alternatives": alts[:4],
                    "alternative_names": [approved[a]["name"] for a in alts[:4]],
                    "current_prices": approved[code]["current_prices"],
                })
            else:
                stripped.append(code)
        usage = proposal.get("usage") or {}
        def clamp(v, lo, hi, default):
            try:
                return max(lo, min(hi, type(default)(v)))
            except (TypeError, ValueError):
                return default
        clean_usage = {
            "requests_per_month": clamp(usage.get("requests_per_month"), 0, 10**9, 0),
            "input_tokens_per_request": clamp(usage.get("input_tokens_per_request"), 0, 10**6, 0),
            "output_tokens_per_request": clamp(usage.get("output_tokens_per_request"), 0, 10**6, 0),
            "calls_per_request": clamp(usage.get("calls_per_request"), 0.1, 1000.0, 1.0),
            "eligibility_rate": clamp(usage.get("eligibility_rate"), 0.0, 1.0, 1.0),
            "time_horizon_months": clamp(usage.get("time_horizon_months"), 1, 120, 12),
        }
        # deterministic consistency checks: the engine will faithfully price
        # whatever this proposal says, so internal contradictions must be
        # caught HERE — loudly — not discovered as a too-low estimate later.
        consistency = []
        types = {approved[c["component_code"]]["component_type"] for c in clean_components}
        codes = {c["component_code"] for c in clean_components}
        tokens = (clean_usage["input_tokens_per_request"]
                  + clean_usage["output_tokens_per_request"])
        if tokens > 0 and "llm_model" not in types:
            consistency.append(
                "The usage assumes model tokens per request, but NO LLM model component is "
                "proposed — agent runtimes and orchestrators host a model, they are not one. "
                "Without a model the engine prices zero token cost. Add a model from the "
                "catalogue or challenge the advisor.")
        if "rageval" in codes and "vector_store" not in types and "embedding" not in types:
            consistency.append(
                "RAG evaluation is proposed but there is no retrieval stack (embedding model "
                "or vector store) to evaluate — add retrieval or drop the harness.")
        # retrieval / RAG completeness: a solution that retrieves from a corpus needs
        # BOTH an embedding model (to vectorise) AND a vector store (to search).
        # The advisor repeatedly drops this on RAG briefs, so enforce it here.
        _sig = (str(proposal.get("archetype_code") or "") + " "
                + str(proposal.get("solution_name") or "") + " "
                + str(proposal.get("summary") or "") + " "
                + str(brief or "")).lower()
        _retrieval = (proposal.get("archetype_code") in ("rag_assistant", "doc_qa")
                      or any(k in _sig for k in ("retriev", "corpus", "semantic search",
                             " rag", "rag ", "knowledge base", "knowledge assistant",
                             "vector search")))
        has_embed = "embedding" in types
        has_vs = "vector_store" in types
        if _retrieval and not has_embed and not has_vs:
            consistency.append(
                "This is a retrieval (RAG) solution — it answers from a document corpus — but "
                "NEITHER an embedding model NOR a vector store is proposed. Retrieval needs both: "
                "an embedding model to vectorise queries and documents, and a vector store to "
                "search them. Without them the estimate omits the entire retrieval cost. "
                "Add an embedding model (e.g. Azure OpenAI Embeddings) and a vector store "
                "(e.g. Azure AI Search).")
        elif _retrieval and not has_embed:
            consistency.append(
                "A vector store is proposed but no embedding model — vector search still needs an "
                "embedding model to create the vectors it searches. Add an embedding model.")
        elif _retrieval and not has_vs:
            consistency.append(
                "An embedding model is proposed but no vector store to hold and search the vectors — "
                "add a vector store (e.g. Azure AI Search).")
        # observability completeness: whatever monitoring the brief asks for must be
        # covered by a component. Each dimension is a distinct priced component, so a
        # requirement for "full observability" or "drift monitoring" that isn't in the
        # proposal is a real gap the advisor should have filled — not the user.
        obs_covered = {approved[c["component_code"]].get("observability_category")
                       for c in clean_components}
        obs_covered.discard(None); obs_covered.discard("")
        want = {}
        if any(k in _sig for k in ("full observability", "observability", "monitoring")):
            want.update({"logging": 1, "metrics": 1, "tracing": 1, "alerting": 1})
        if "drift" in _sig:
            want["drift"] = 1
        if _retrieval and any(k in _sig for k in
                ("rag eval", "rag-eval", "rag evaluation", "answer quality",
                 "groundedness", "citation accuracy")):
            want["rag_eval"] = 1
        if any(k in _sig for k in ("governance", "audit trail", "audit log")):
            want["governance"] = 1
        if "alerting" in _sig or " alert" in _sig:
            want["alerting"] = 1
        if "tracing" in _sig or " trace" in _sig:
            want["tracing"] = 1
        _obs_name = {"logging": "logging", "metrics": "metrics", "tracing": "tracing",
                     "alerting": "alerting", "drift": "model-drift monitoring",
                     "rag_eval": "RAG evaluation", "governance": "AI governance"}
        missing_obs = [d for d in want if d not in obs_covered]
        if missing_obs:
            consistency.append(
                "The brief calls for observability the proposal does not fully cover — missing: "
                + ", ".join(_obs_name[d] for d in missing_obs)
                + ". Each is a separate priced component; the advisor should include the "
                "ones the requirement names, or the estimate understates the monitoring cost.")
        return {
            "archetype_code": proposal.get("archetype_code")
                if proposal.get("archetype_code") in arch_codes else "none",
            "solution_name": str(proposal.get("solution_name") or "")[:200],
            "business_area": str(proposal.get("business_area") or "")[:200],
            "archetype_confidence": self._clean_confidence(proposal.get("archetype_confidence")),
            "archetype_confidence_reason": str(proposal.get("archetype_confidence_reason", ""))[:300],
            "summary": str(proposal.get("summary") or "")[:1000],
            "usage": clean_usage,
            "usage_confidence": self._clean_confidence(proposal.get("usage_confidence")),
            "usage_confidence_reason": str(proposal.get("usage_confidence_reason", ""))[:300],
            "components": clean_components,
            "stripped_by_guardrail": stripped,   # transparency: what the model tried
            "consistency_warnings": consistency,  # contradictions the human must judge
        }

    # ---- document upload: BRD/FRD in, requirement brief out ----
    @staticmethod
    def extract_document_text(filename: str, data: bytes) -> str:
        """Extract plain text from an uploaded requirements document.
        Supported: .pdf (pypdf), .docx / .pptx (stdlib zip+xml), .txt/.md."""
        import html as _html
        name = (filename or "").lower()
        if name.endswith(".pdf"):
            import io
            from pypdf import PdfReader
            reader = PdfReader(io.BytesIO(data))
            text = "\n".join((page.extract_text() or "") for page in reader.pages)
        elif name.endswith(".docx"):
            import io
            import re as _re
            import zipfile
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                xml = z.read("word/document.xml").decode("utf-8", "ignore")
            xml = _re.sub(r"</w:p>", "\n", xml)
            text = _html.unescape(_re.sub(r"<[^>]+>", "", xml))
        elif name.endswith(".pptx"):
            # a deck is a zip of ppt/slides/slideN.xml; text lives in <a:t> runs.
            # Stage-0 decks are a common Stage-0 artifact, so read them natively.
            import io
            import re as _re
            import zipfile
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                slides = [n for n in z.namelist()
                          if _re.match(r"ppt/slides/slide\d+\.xml$", n)]
                slides.sort(key=lambda s: int(_re.search(r"slide(\d+)\.xml$", s).group(1)))
                parts = []
                for s in slides:
                    xml = z.read(s).decode("utf-8", "ignore")
                    runs = _re.findall(r"<a:t>(.*?)</a:t>", xml, _re.DOTALL)
                    if runs:
                        parts.append(" ".join(_html.unescape(r) for r in runs))
            text = "\n".join(parts)
        elif name.endswith((".txt", ".md")):
            text = data.decode("utf-8", "ignore")
        else:
            raise ValueError("unsupported_type")
        text = "\n".join(line.strip() for line in text.splitlines() if line.strip())
        return text[:15000]

    # ---- per-field usage assistants: dictionary + playbooks + extractor ----
    # The translation dictionary: everyday units -> tokens. DATA, like prices:
    # the LLM only ever names a shape; the server does the lookup and the math.
    ASSIST_DICTIONARY = {
        "sentence": 25, "paragraph": 100, "email": 300, "page": 650,
        "several_pages": 2000, "chunk": 400, "tool_def": 150, "turn": 350,
        "sys_simple": 200, "sys_typical": 400, "sys_agentic": 800,
        "lookup": 100, "record": 500, "document_result": 1000,
    }
    # value bounds per writable field (server-side clamp, mirrors engine limits)
    ASSIST_BOUNDS = {
        "u_req": (0, 10**9), "u_rate": (1, 10**6), "u_elig": (0, 100),
        "u_calls": (0.1, 1000), "u_in": (0, 10**6), "u_out": (0, 10**6),
        "u_cached": (0, 10**6), "u_months": (1, 120), "u_growth": (0, 100),
        "a_sys": (0, 10**6), "a_hist": (0, 10**6), "a_rag": (0, 10**6),
        "a_tool": (0, 10**6), "a_res": (0, 10**6), "a_user": (0, 10**6),
    }
    ASSIST_MODES = ("per_month", "per_day", "per_user", "per_event")
    # One playbook per assisted field: the question, the click-to-fill chips
    # (zero LLM cost), and which fields the extractor may write.
    ASSIST_PLAYBOOKS = [
        {"field": "u_req", "label": "Volume",
         "question": "How does demand arrive, and roughly how much?",
         "hint": "e.g. “12,000 enquiries a month” · “400 cases a day” · “300 users, ~20 questions each” · “only the 5% of 80k transactions we flag”",
         "chips": [], "free": True,
         "writes": ["u_volmode", "u_req", "u_rate", "u_elig"]},
        {"field": "u_calls", "label": "Calls per request",
         "question": "When one request is handled, what happens?",
         "chips": [
            {"label": "one-shot answer", "set": {"u_calls": 1}},
            {"label": "retrieve then draft", "set": {"u_calls": 2}},
            {"label": "small agent (~3 tools)", "set": {"u_calls": 5}},
            {"label": "complex agent", "set": {"u_calls": 10}}],
         "free": True, "writes": ["u_calls"]},
        {"field": "u_in", "label": "Input tokens per call",
         "question": "How much does the AI read per call, all in?",
         "hint": "for a detailed breakdown, use the token anatomy fields below instead",
         "chips": [
            {"label": "just the question", "set": {"u_in": 600}},
            {"label": "question + a page of context", "set": {"u_in": 1500}},
            {"label": "heavy context", "set": {"u_in": 3000}},
            {"label": "agent with tools", "set": {"u_in": 4500}}],
         "free": True, "writes": ["u_in"]},
        {"field": "u_out", "label": "Output tokens per call",
         "question": "What does one answer look like?",
         "chips": [
            {"label": "a yes/no with a reason", "set": {"u_out": 80}},
            {"label": "a paragraph", "set": {"u_out": 250}},
            {"label": "a drafted email/letter", "set": {"u_out": 450}},
            {"label": "a structured report", "set": {"u_out": 1200}}],
         "free": True, "writes": ["u_out"]},
        {"field": "u_cached", "label": "Cached input tokens",
         "question": "Do requests share the same fixed instructions every call?",
         "chips": [
            {"label": "yes — same instructions each time", "set": {"u_cached": "sys_typical"}},
            {"label": "no reuse", "set": {"u_cached": 0}}],
         "free": True, "writes": ["u_cached"]},
        {"field": "u_elig", "label": "Eligibility",
         "question": "Does everything reach the AI, or only a subset?",
         "chips": [
            {"label": "everything", "set": {"u_elig": 100}},
            {"label": "only a flagged subset", "ask": "What share reaches the AI, roughly? Type a %", "askField": "u_elig"}],
         "free": True, "writes": ["u_elig"]},
        {"field": "u_months", "label": "Horizon",
         "question": "What period should the business case cover?",
         "chips": [
            {"label": "12 months", "set": {"u_months": 12}},
            {"label": "24 months", "set": {"u_months": 24}},
            {"label": "36 months", "set": {"u_months": 36}}],
         "free": True, "writes": ["u_months"]},
        {"field": "u_growth", "label": "Growth",
         "question": "Flat volumes, or growing over the horizon?",
         "chips": [
            {"label": "flat", "set": {"u_growth": 0}},
            {"label": "steady growth (~5%/mo)", "set": {"u_growth": 5}},
            {"label": "doubling in a year (~6%/mo)", "set": {"u_growth": 6}},
            {"label": "aggressive rollout (~10%/mo)", "set": {"u_growth": 10}}],
         "free": True, "writes": ["u_growth"]},
        {"field": "a_sys", "label": "System prompt",
         "question": "How complex are the assistant’s standing instructions?",
         "chips": [
            {"label": "simple", "set": {"a_sys": "sys_simple"}},
            {"label": "typical", "set": {"a_sys": "sys_typical"}},
            {"label": "agentic (tools, policies)", "set": {"a_sys": "sys_agentic"}}],
         "free": True, "writes": ["a_sys"]},
        {"field": "a_hist", "label": "Conversation history",
         "question": "Single-shot, or a conversation?",
         "chips": [
            {"label": "single-shot", "set": {"a_hist": 0}},
            {"label": "short chat (~3 turns)", "set": {"a_hist": 1050}},
            {"label": "long chat (~8 turns)", "set": {"a_hist": 2800}}],
         "free": True, "writes": ["a_hist"]},
        {"field": "a_rag", "label": "RAG context",
         "question": "How much source material should the AI read each time?",
         "chips": [
            {"label": "a paragraph", "set": {"a_rag": 150}},
            {"label": "about a page", "set": {"a_rag": "page"}},
            {"label": "several pages", "set": {"a_rag": "several_pages"}}],
         "free": True, "writes": ["a_rag"]},
        {"field": "a_tool", "label": "Tool definitions",
         "question": "How many tools can the agent call?",
         "chips": [
            {"label": "none", "set": {"a_tool": 0}},
            {"label": "a few (~3)", "set": {"a_tool": 450}},
            {"label": "many (~8)", "set": {"a_tool": 1200}}],
         "free": True, "writes": ["a_tool"]},
        {"field": "a_res", "label": "Tool results",
         "question": "What do the tools return?",
         "chips": [
            {"label": "short lookups", "set": {"a_res": "lookup"}},
            {"label": "full records", "set": {"a_res": "record"}},
            {"label": "whole documents", "set": {"a_res": "document_result"}}],
         "free": True, "writes": ["a_res"]},
        {"field": "a_user", "label": "User message",
         "question": "How long is what the user submits?",
         "chips": [
            {"label": "a sentence", "set": {"a_user": "sentence"}},
            {"label": "a paragraph", "set": {"a_user": "paragraph"}},
            {"label": "an email", "set": {"a_user": "email"}},
            {"label": "a document (~page)", "set": {"a_user": "page"}}],
         "free": True, "writes": ["a_user"]},
    ]

    def assist_config(self) -> dict:
        """Everything the popovers need: served from one source of truth so the
        chip lookups on the client use the exact same dictionary as the server."""
        return {"dictionary": self.ASSIST_DICTIONARY,
                "playbooks": self.ASSIST_PLAYBOOKS,
                "modes": list(self.ASSIST_MODES)}

    def _assist_resolve(self, playbook: dict, raw_values: dict) -> tuple[dict, list[str]]:
        """Deterministic core: shapes/numbers from the LLM (or a chip) become
        clamped field values. Anything not writable or not resolvable is dropped."""
        out, working = {}, []
        for fid, val in (raw_values or {}).items():
            if fid == "u_volmode":
                if str(val) in self.ASSIST_MODES:
                    out[fid] = str(val)
                    working.append(f"volume mode = {val}")
                continue
            if fid not in (playbook.get("writes") or []):
                continue
            if isinstance(val, str):
                if val not in self.ASSIST_DICTIONARY:
                    continue
                working.append(f"{fid}: “{val.replace('_', ' ')}” = {self.ASSIST_DICTIONARY[val]} tokens")
                val = self.ASSIST_DICTIONARY[val]
            try:
                num = float(val)
            except (TypeError, ValueError):
                continue
            lo, hi = self.ASSIST_BOUNDS.get(fid, (0, 10**9))
            num = max(lo, min(hi, num))
            out[fid] = num if fid in ("u_calls", "u_growth") else int(round(num))
            if not working or not working[-1].startswith(fid):
                working.append(f"{fid} = {out[fid]}")
        return out, working

    def _assist_prompt(self, playbook: dict, text: str, mode: str,
                       history: list[dict] | None) -> list[dict]:
        import json as _json
        writes = playbook.get("writes") or [playbook["field"]]
        source = ("the user's answer" if mode == "answer"
                  else "a requirements brief derived from the user's document")
        hist = ""
        if history:
            hist = "\nEARLIER IN THIS EXCHANGE:\n" + "\n".join(
                f"Q: {h.get('q', '')}\nA: {h.get('a', '')}" for h in history[:3])
        return [{"role": "system", "content": f"""You fill ONE usage field of an AI cost
estimate by interpreting {source} into SHAPES from a fixed dictionary, or explicit numbers
the text states. You NEVER do arithmetic and NEVER invent a number the text does not support.
DICTIONARY (shape token -> tokens): {_json.dumps(self.ASSIST_DICTIONARY)}
FIELD BEING FILLED: {playbook['field']} — “{playbook['label']}”: {playbook['question']}
FIELDS YOU MAY SET: {writes}{' (u_volmode must be one of ' + str(list(self.ASSIST_MODES)) + ')' if 'u_volmode' in writes else ''}
u_elig and u_growth are percentages 0-100. Daily volumes: set u_volmode per_day and u_req to the DAILY number.
Reply with EXACTLY ONE JSON object, one of:
 {{"status":"derived","values":{{"<field>": <number or shape token>}},"basis":"short quote or reason"}}
 {{"status":"ask","question":"one short clarifying question"}}
 {{"status":"unknown"}}"""},
                {"role": "user", "content": f"{'ANSWER' if mode == 'answer' else 'BRIEF'}:\n{str(text)[:4000]}{hist}"}]

    def assist(self, field: str, text: str, mode: str = "answer",
               history: list[dict] | None = None) -> dict:
        """One extraction step for a field popover. mode='mine' reads the
        document brief (confirm-first on the client); mode='answer' reads the
        user's free-text reply. Chips never reach this method at all."""
        playbook = next((p for p in self.ASSIST_PLAYBOOKS if p["field"] == field), None)
        if playbook is None:
            return {"error": "unknown_field"}
        import urllib.error as _uerr
        try:
            raw = self._llm_call(self._assist_prompt(playbook, text, mode, history),
                                 max_tokens=600)
        except RuntimeError:
            return {"error": "no_api_key",
                    "detail": "OPENAI_API_KEY not configured on this server."}
        except (_uerr.HTTPError, _uerr.URLError, TimeoutError, ValueError) as e:
            return {"error": "llm_failed", "detail": f"Assist call failed ({e}); try again."}
        status = str(raw.get("status") or "unknown")
        if status == "ask":
            return {"status": "ask", "question": str(raw.get("question") or "")[:300]}
        if status != "derived":
            return {"status": "unknown"}
        values, working = self._assist_resolve(playbook, raw.get("values") or {})
        if not values:
            return {"status": "unknown"}
        return {"status": "derived", "values": values,
                "working": "; ".join(working),
                "basis": str(raw.get("basis") or "")[:300]}

    def _distill_prompt(self, doc_text: str) -> list[dict]:
        return [{"role": "system", "content": """You read requirements documents (BRD, FRD,
Stage-0 decks) and write the requirement message a user would type to a solution advisor.
Extract ONLY what the document supports: what the solution does and its workflow, volumes
(requests/cases per month, tokens, calls if stated), which systems are existing or shared vs
new, business area, human-in-the-loop needs, retrieval / document-corpus needs, and observability.
Do NOT invent numbers — omit what the document does not state. NEVER mention prices or costs.

PRESERVE REQUIREMENTS VERBATIM — do not summarise a list down to a few examples. In particular:
- If the document names specific observability / monitoring capabilities, carry EVERY one through
  by name (e.g. logging, metrics, tracing, alerting, model-drift monitoring, RAG / answer-quality
  evaluation, governance / audit). Never shorten "logging, metrics, tracing, alerting, drift and
  RAG evaluation" to "logging, metrics and drift".
- If it describes retrieval over a document corpus / knowledge base, say so explicitly (it implies
  an embedding model and a vector store).
- Keep every stated non-functional requirement that affects components (security, HITL, compliance).

Reply with EXACTLY this JSON: {"brief":"the requirement message, complete but concise, under 240 words"}"""},
                {"role": "user", "content": f"DOCUMENT (extracted text):\n{doc_text}"}]

    def advisor_from_document(self, filename: str, text: str, created_by: str) -> dict:
        """Distill an uploaded document into the brief the user would have typed,
        then run it through the normal advisor pipeline (which may still ask)."""
        import urllib.error as _uerr
        try:
            distilled = self._llm_call(self._distill_prompt(text))
        except RuntimeError:
            return {"error": "no_api_key",
                    "detail": "OPENAI_API_KEY not configured on this server."}
        except (_uerr.HTTPError, _uerr.URLError, TimeoutError, ValueError) as e:
            return {"error": "llm_failed",
                    "detail": f"Document distillation failed ({e}); try again."}
        brief = str(distilled.get("brief") or "").strip()
        if not brief:
            return {"error": "llm_failed",
                    "detail": "Could not derive a requirement brief from the document."}
        out = self.advisor_chat(None, brief, created_by)
        out["generated_brief"] = brief
        out["source_document"] = str(filename or "document")[:200]
        return out

    def advisor_chat(self, session_id: str | None, message: str,
                     created_by: str) -> dict:
        import json as _json
        import sqlite3
        import uuid
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        try:
            if session_id:
                row = conn.execute("SELECT * FROM advisor_session WHERE id=?",
                                   (session_id,)).fetchone()
                if row is None:
                    return {"error": "unknown_session"}
                messages = _json.loads(row["messages"])
            else:
                session_id = str(uuid.uuid4())
                messages = []
                conn.execute("INSERT INTO advisor_session (id, messages, created_by) "
                             "VALUES (?,?,?)", (session_id, "[]", created_by))
            messages.append({"role": "user", "content": message})
            questions_asked = sum(1 for m in messages if m["role"] == "assistant")
            llm_messages = ([{"role": "system", "content": self._triage_prompt()}]
                            + messages)
            try:
                action = self._llm_call(llm_messages)
            except RuntimeError:
                return {"error": "no_api_key",
                        "detail": "OPENAI_API_KEY not configured on this server."}
            kind = action.get("action")
            if kind == "ask" and questions_asked >= self.MAX_QUESTIONS:
                kind = "refuse"
                action = {"action": "refuse",
                          "reason": "Could not pin the solution down within the question budget."}
            if kind == "ask":
                messages.append({"role": "assistant", "content": _json.dumps(action)})
                conn.execute("UPDATE advisor_session SET messages=? WHERE id=?",
                             (_json.dumps(messages), session_id))
                conn.commit()
                return {"session_id": session_id, "type": "question",
                        "question": action.get("question", ""),
                        "questions_asked": questions_asked + 1,
                        "max_questions": self.MAX_QUESTIONS}
            if kind in ("ready", "propose"):
                # ---- the multi-agent pipeline ----
                brief = action.get("brief") or message
                import urllib.error as _uerr
                try:
                    checklist = self._llm_call(self._inventory_prompt(brief))   # Agent 1
                    iterations, feedback, proposal = [], None, {}
                    for attempt in range(1, self.MAX_ITERATIONS + 1):
                        # the architect emits the whole component list with per-item
                        # rationale/confidence/alternatives — give it the most room
                        proposal = self._llm_call(                               # Agent 2
                            self._architect_prompt(brief, checklist, feedback),
                            max_tokens=8000)
                        verdict = self._llm_call(                                # Agent 3
                            self._evaluator_prompt(brief, checklist, proposal))
                        iterations.append({
                            "attempt": attempt,
                            "score": verdict.get("score"),
                            "satisfied": bool(verdict.get("satisfied")),
                            "issues": verdict.get("issues", [])})
                        if verdict.get("satisfied"):
                            break
                        feedback = verdict
                except (_uerr.HTTPError, _uerr.URLError, TimeoutError, ValueError) as e:
                    return {"error": "llm_failed",
                            "detail": f"An agent call failed ({e}); try again."}
                grounded = self._ground_proposal(proposal, brief)
                grounded["brief"] = str(brief)[:1500]
                _approved = {c["code"] for c in
                             self.get_catalogue_listing()["components"] if c["approved"]}
                grounded["checklist"] = self._ground_checklist(
                    checklist.get("checklist", []), _approved)
                grounded["iterations"] = iterations
                grounded["evaluator_satisfied"] = iterations[-1]["satisfied"]
                grounded["open_issues"] = ([] if iterations[-1]["satisfied"]
                                           else iterations[-1]["issues"])
                messages.append({"role": "assistant", "content": _json.dumps(
                    {"action": "propose", "iterations": len(iterations)})})
                conn.execute("UPDATE advisor_session SET messages=?, status='proposed', "
                             "proposal=? WHERE id=?",
                             (_json.dumps(messages), _json.dumps(grounded), session_id))
                conn.commit()
                return {"session_id": session_id, "type": "proposal", **grounded}
            # refuse (or anything unrecognised is treated as a refusal)
            messages.append({"role": "assistant", "content": _json.dumps(action)})
            conn.execute("UPDATE advisor_session SET messages=?, status='refused' WHERE id=?",
                         (_json.dumps(messages), session_id))
            conn.commit()
            return {"session_id": session_id, "type": "refusal",
                    "reason": action.get("reason", "The advisor could not infer an AI solution.")}
        finally:
            conn.close()

    def get_advisor_session(self, session_id: str) -> dict | None:
        import json as _json
        import sqlite3
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        try:
            row = conn.execute("SELECT * FROM advisor_session WHERE id=?",
                               (session_id,)).fetchone()
            if row is None:
                return None
            return {"session_id": row["id"], "status": row["status"],
                    "created_by": row["created_by"], "created_at": row["created_at"],
                    "proposal": _json.loads(row["proposal"]) if row["proposal"] else None}
        finally:
            conn.close()

    def advisor_signoff(self, session_id: str, decisions: list[dict],
                        decided_by: str) -> dict | None:
        """Record the human decision per component (the audit trail), mark the
        session signed off, and return the ACCEPTED subset + draft context."""
        import json as _json
        import sqlite3
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        try:
            row = conn.execute("SELECT * FROM advisor_session WHERE id=?",
                               (session_id,)).fetchone()
            if row is None or not row["proposal"]:
                return None
            proposal = _json.loads(row["proposal"])
            decided = {d["component_code"]: bool(d["accepted"]) for d in decisions}
            for c in proposal["components"]:
                conn.execute(
                    "INSERT INTO advisor_signoff (session_id, component_code, accepted, decided_by) "
                    "VALUES (?,?,?,?)",
                    (session_id, c["component_code"],
                     1 if decided.get(c["component_code"], False) else 0, decided_by))
            conn.execute("UPDATE advisor_session SET status='signed_off' WHERE id=?",
                         (session_id,))
            conn.commit()
            accepted = [c for c in proposal["components"]
                        if decided.get(c["component_code"], False)]
            return {"session_id": session_id, "accepted": accepted,
                    "archetype_code": proposal["archetype_code"],
                    "solution_name": proposal["solution_name"],
                    "business_area": proposal["business_area"],
                    "usage": proposal["usage"], "summary": proposal["summary"]}
        finally:
            conn.close()

    def list_estimates(self, limit: int = 50) -> list[dict]:
        return self._repo.list_estimates(limit)

    def add_actual(self, estimate_id: str, period: str, amount: Decimal) -> bool:
        return self._repo.add_actual(estimate_id, period, str(amount))

    def get_estimate(self, estimate_id: str) -> dict | None:
        stored = self._repo.get_estimate(estimate_id)
        if stored is None:
            return None
        # Epic 8: variance of recorded actuals vs the FROZEN expected total,
        # pro-rated by how many periods have been recorded. Never mutates the estimate.
        actuals = stored.get("actuals", [])
        if actuals:
            months = int(stored["solution"]["usage"].get("time_horizon_months", 12) or 12)
            actual_total = sum(Decimal(str(a["amount"])) for a in actuals)
            per_period = stored["total_expected"] / Decimal(months)
            expected_to_date = (per_period * len(actuals)).quantize(Decimal("0.01"))
            stored["actual_total"] = actual_total
            stored["expected_to_date"] = expected_to_date
            stored["variance"] = actual_total - expected_to_date
        return stored


# ---- Epic 2 AC5: the register's six observability dimensions (+ alerting) ----
EXPECTED_DIMS = ("logging", "metrics", "tracing", "alerting",
                 "drift", "rag_eval", "governance")


def _band(confidence_pct: Decimal) -> str:
    """Epic 2 AC8: Low/Medium/High from assumption completeness."""
    if confidence_pct >= 75:
        return "High"
    if confidence_pct >= 40:
        return "Medium"
    return "Low"


def _figures(result, merged) -> dict:
    """Epic 2 AC1 + AC3: time-grain views (30-day months) and per-request
    token/cost anatomy. Pure arithmetic over the engine's own output."""
    months = Decimal(merged.time_horizon_months)
    monthly = (result.total_expected / months).quantize(Decimal("0.01"))
    daily = (monthly / Decimal(30)).quantize(Decimal("0.01"))
    token_cost = sum((l.cost for l in result.lines
                      if not l.shared and l.priced.unit.endswith("token")), Decimal(0))
    requests_total = Decimal(merged.requests_per_month) * merged.eligibility_rate * months
    per_request = (token_cost / requests_total).quantize(Decimal("0.0001")) \
        if requests_total > 0 else Decimal(0)
    in_tok = merged.effective_input_tokens()
    cached = merged.cached_input_tokens_per_request
    calls = merged.calls_per_request
    return {
        "total": result.total_expected, "monthly": monthly, "daily": daily,
        "per_request_ai": per_request,
        "tokens_per_request": {
            "uncached_input": str(Decimal(max(in_tok - cached, 0)) * calls),
            "cached_input": str(Decimal(cached) * calls),
            "output": str(Decimal(merged.output_tokens_per_request) * calls),
        },
    }


# ---- Epic 9: which usage values were supplied vs assumed ----
_USAGE_DEFAULTS = [
    ("requests_per_month", 0), ("input_tokens_per_request", 0),
    ("output_tokens_per_request", 0), ("cached_input_tokens_per_request", 0),
    ("calls_per_request", Decimal(1)), ("eligibility_rate", Decimal(1)),
    ("time_horizon_months", 12), ("growth_rate_monthly", Decimal(0)),
]


def _assumption_report(spec: SolutionSpec, merged: UsageAssumptions,
                       explicit: set[str] = frozenset()):
    """For each usage value: did the user supply it, did the archetype default
    it, or is it a system default? `explicit` = the request fields the user
    actually sent (so 'user sent 12' is distinguishable from 'defaulted to 12').
    Confidence = share of MATERIAL values (ones actually driving this estimate)
    that the user supplied (Epic 9)."""
    assumptions, supplied, material = [], 0, 0
    for name, default in _USAGE_DEFAULTS:
        uval, mval = getattr(spec.usage, name), getattr(merged, name)
        if (name in explicit or uval != default) and mval == uval:
            source = "user"          # user sent it AND the engine used their value
        elif mval != default:
            source = "archetype_default"
        else:
            source = "system_default"
        is_material = (mval != default) or name == "time_horizon_months"
        if is_material:
            material += 1
            if source == "user":
                supplied += 1
        assumptions.append({"field": name, "value": str(mval), "source": source,
                            "status": "supplied" if source == "user" else "assumed"})
    if spec.usage.anatomy is not None and not spec.usage.anatomy.is_empty():
        assumptions.append({"field": "token_anatomy",
                            "value": str(spec.usage.anatomy.total()), "source": "user",
                            "status": "supplied"})
        material += 1
        supplied += 1
    confidence = (Decimal(supplied) / Decimal(material) * 100).quantize(Decimal("0.1")) \
        if material else Decimal(100)
    return assumptions, confidence
