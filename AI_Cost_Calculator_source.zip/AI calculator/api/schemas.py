"""
schemas.py — Pydantic v2 DTOs for the /estimates API.

Design rules carried over from the engine:
  - Money is Decimal in, Decimal through, STRING out. A JSON float never
    touches a monetary value (json.dumps(Decimal) would crash; float would
    silently corrupt — string is the only safe wire format).
  - The API validates SHAPE (types, bounds); the engine validates MEANING
    (approval, prices). Validation errors are 422 either way.
  - Response DTOs mirror the engine's frozen output — nothing recomputed here.
"""
from __future__ import annotations
from datetime import date
from decimal import Decimal
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, PlainSerializer

# Decimal that serializes to a JSON *string* — never a float.
Money = Annotated[Decimal, PlainSerializer(lambda v: str(v), return_type=str, when_used="json")]


# ---------------------------------------------------------------- requests
class TokenAnatomyIn(BaseModel):
    """Optional breakdown of one request's input tokens (Epic 2 AC2).
    If provided (any part > 0), its total overrides input_tokens_per_request."""
    model_config = ConfigDict(extra="forbid")
    system_prompt: int = Field(0, ge=0)
    conversation_history: int = Field(0, ge=0)
    rag_context: int = Field(0, ge=0)
    tool_definitions: int = Field(0, ge=0)
    tool_results: int = Field(0, ge=0)
    user_message: int = Field(0, ge=0)


class VolumeIn(BaseModel):
    """Volume the way the business states it (Epic 1a): per day, per user, or
    per event. The SERVICE translates this into requests_per_month — the engine
    only ever sees raw monthly numbers (deterministic, no interpretation).
      per_day   -> count requests/day x 30
      per_user  -> count users x per_unit_rate requests/user/month
      per_event -> count events/month (eligibility_rate trims to the AI-eligible share)
    """
    model_config = ConfigDict(extra="forbid")
    mode: Literal["per_day", "per_user", "per_event"]
    count: int = Field(gt=0)
    per_unit_rate: Decimal = Field(Decimal(1), gt=0)


class UsageIn(BaseModel):
    """Raw metered numbers. Anything omitted may be pre-filled by the
    archetype's defaults (engine behaviour — user values always win).
    If `volume` is set, it overrides requests_per_month."""
    model_config = ConfigDict(extra="forbid")
    volume: VolumeIn | None = None
    requests_per_month: int = Field(0, ge=0)
    input_tokens_per_request: int = Field(0, ge=0)
    output_tokens_per_request: int = Field(0, ge=0)
    cached_input_tokens_per_request: int = Field(0, ge=0)
    calls_per_request: Decimal = Field(Decimal(1), gt=0)
    eligibility_rate: Decimal = Field(Decimal(1), ge=0, le=1)
    time_horizon_months: int = Field(12, ge=1, le=120)
    growth_rate_monthly: Decimal = Field(Decimal(0), ge=0)
    anatomy: TokenAnatomyIn | None = None


class ComponentIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    component_code: str = Field(min_length=1)
    quantity: Decimal = Field(Decimal(1), gt=0)
    # shared=True: already runs elsewhere in the estate — listed on the
    # estimate but NOT attributed to its totals; brings no new dependencies
    shared: bool = False


class EstimateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    archetype_code: str = Field(min_length=1)
    components: list[ComponentIn] = Field(min_length=1)
    usage: UsageIn = UsageIn()
    business_area: str | list[str] | None = None   # Epic 8 AC1: one or more areas
    priced_on: date | None = None      # None -> priced today
    created_by: str = "api"
    solution_name: str | None = Field(None, max_length=200)   # Epic 1a
    description: str | None = Field(None, max_length=2000)    # Epic 1a


# ---------------------------------------------------------------- responses
class LineOut(BaseModel):
    component_code: str
    component_name: str
    unit: str
    quantity: Money
    unit_price: Money        # the frozen price used
    cost: Money
    mi_tag: str
    derivation: str | None = None   # human-readable trace of how quantity -> cost
    shared: bool = False            # listed but NOT in the totals


class ObservabilityOut(BaseModel):
    """Epic 2 AC4-6: which observability categories the solution covers."""
    coverage_pct: Money
    covered: list[str]
    missing: list[str]
    warnings: list[str]


class AssumptionOut(BaseModel):
    """Epic 9: one usage value + where it came from. 'assumed' values are the
    ones a reviewer should confirm before trusting the estimate."""
    field: str
    value: str
    source: Literal["user", "archetype_default", "system_default"]
    status: Literal["supplied", "assumed"]


class EstimateResponse(BaseModel):
    estimate_id: str
    solution_name: str | None = None
    total_low: Money
    total_expected: Money
    total_high: Money
    currency: str = "USD"
    by_business_area: dict[str, Money]
    lines: list[LineOut]
    warnings: list[str]
    priced_on: date
    observability: ObservabilityOut | None = None
    assumptions: list[AssumptionOut] = []
    confidence_pct: Money = Decimal(0)   # share of material usage values user-supplied
    confidence_band: Literal["Low", "Medium", "High"] = "Low"   # Epic 2 AC8
    shared_cost: Money = Decimal(0)      # value of shared components — NOT in totals
    figures: "FiguresOut | None" = None  # Epic 2 AC1/AC3: time + per-request views


class TokensPerRequestOut(BaseModel):
    """Epic 2 AC3: one request's token anatomy with the prices applied."""
    uncached_input: str
    cached_input: str
    output: str


class FiguresOut(BaseModel):
    """Epic 2 AC1: the same estimate viewed at different time grains
    (30-day month convention), plus the AI cost of a single request."""
    total: Money
    monthly: Money
    daily: Money
    per_request_ai: Money        # token-line cost / (requests x months)
    tokens_per_request: TokensPerRequestOut


EstimateResponse.model_rebuild()   # resolve the FiguresOut forward reference


class DraftIn(BaseModel):
    """Epic 6 AC1: builder state saved BEFORE pricing. Not an estimate —
    immutability of estimates is untouched."""
    model_config = ConfigDict(extra="forbid")
    name: str | None = Field(None, max_length=200)
    payload: dict                 # the request-in-progress, as-is
    created_by: str = "api"


class ComponentAdminIn(BaseModel):
    """Epic 7 AC3: admin adds a catalogue component (data, not code)."""
    model_config = ConfigDict(extra="forbid")
    code: str = Field(min_length=1, max_length=50)
    name: str = Field(min_length=1, max_length=200)
    component_type: Literal["llm_model", "embedding", "infra", "licence",
                            "vector_store", "observability"]
    pricing_model_code: str = "per_unit"
    default_unit: str = "month"
    mi_tag: str | None = None
    observability_category: str | None = None
    cloud: Literal["azure", "aws", "gcp"] = "azure"
    layer: Literal["experience", "orchestration", "intelligence", "data_platform"] = "data_platform"
    description: str | None = None
    approved: bool = True


class ProjectionResponse(BaseModel):
    """Epic 5 AC1: compounding month-on-month growth projection."""
    months: int
    growth_rate_monthly: str
    monthly: list[Money]
    total: Money
    warnings: list[str] = []


class CompareRequest(BaseModel):
    """Epic 5 AC2-3: run the SAME solution once per candidate model."""
    model_config = ConfigDict(extra="forbid")
    request: EstimateRequest
    swap_from: str = Field(min_length=1)
    candidates: list[str] = Field(min_length=1, max_length=10)


class CompareCandidateOut(BaseModel):
    model_code: str
    model_name: str
    total_low: Money
    total_expected: Money
    total_high: Money


class PriceChangeIn(BaseModel):
    """Epic 3a AC2: a price change is DATA — close the old dated row, insert a
    new one. Never an update-in-place, never a deploy. (RBAC: next increment.)"""
    model_config = ConfigDict(extra="forbid")
    component_code: str = Field(min_length=1)
    unit: str = Field(min_length=1)
    new_price: Decimal = Field(gt=0)
    currency: str = "USD"
    effective_from: date | None = None   # None -> today


class ActualIn(BaseModel):
    """Epic 8: a real cost recorded against a FROZEN estimate."""
    model_config = ConfigDict(extra="forbid")
    period: str = Field(pattern=r"^\d{4}-\d{2}$")   # YYYY-MM
    amount: Decimal = Field(gt=0)


class ActualOut(BaseModel):
    period: str
    amount: Money
    recorded_at: str


class SolutionOut(BaseModel):
    name: str | None = None
    description: str | None = None
    archetype_code: str | None = None
    business_area: str | None = None
    usage: dict = {}
    components: list[dict] = []


class EstimateListItem(BaseModel):
    estimate_id: str
    name: str | None
    archetype_code: str | None
    business_area: str | None
    total_expected: Money
    priced_on: str
    created_at: str
    created_by: str | None


class StoredLineOut(BaseModel):
    component_name: str
    unit: str
    quantity: Money
    unit_price_used: Money
    line_total: Money
    mi_tag: str | None


class StoredEstimateResponse(BaseModel):
    """The immutable estimate as persisted — read straight from the frozen
    ESTIMATE/ESTIMATE_LINE rows, not recomputed. Actuals (Epic 8) compare
    against the frozen figures; they never modify them."""
    estimate_id: str
    total_low: Money
    total_expected: Money
    total_high: Money
    priced_on: str
    created_by: str | None
    lines: list[StoredLineOut]
    solution: SolutionOut | None = None
    actuals: list[ActualOut] = []
    actual_total: Money | None = None
    expected_to_date: Money | None = None    # expected/months x periods recorded
    variance: Money | None = None            # actual_total - expected_to_date
