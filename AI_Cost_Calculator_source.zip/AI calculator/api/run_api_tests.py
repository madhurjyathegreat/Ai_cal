"""
run_api_tests.py — prove the API layer is a FAITHFUL adapter over the engine.

The engine maths is already proven (65 assertions). What can go wrong HERE:
  - money corrupted crossing the JSON boundary (Decimal -> float)
  - the saved estimate differing from the returned one
  - engine rejections leaking as 500s instead of clean 422s
  - bad request shapes reaching the engine at all

Runs against a THROWAWAY DB built fresh from schema.sql + seed.sql —
the real db/calculator.db is never touched.

Run:  python run_api_tests.py     (from the api/ directory)
"""
from __future__ import annotations
import json
import sqlite3
import tempfile
from decimal import Decimal
from pathlib import Path

from fastapi.testclient import TestClient

from main import create_app

D = Decimal
ROOT = Path(__file__).resolve().parent.parent

PASS, FAIL = 0, 0
def check(name, cond):
    global PASS, FAIL
    if cond: PASS += 1; print(f"  PASS  {name}")
    else:    FAIL += 1; print(f"  FAIL  {name}")


# ---- throwaway DB: fresh schema + seed, real DB untouched ----
def build_test_db() -> str:
    f = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    f.close()
    conn = sqlite3.connect(f.name)
    conn.executescript((ROOT / "db" / "schema.sql").read_text())
    conn.executescript((ROOT / "db" / "seed.sql").read_text())
    conn.commit(); conn.close()
    return f.name


DB = build_test_db()
client = TestClient(create_app(DB))

# the canonical RAG solution — same numbers as engine Test 1 (£111,116.80)
RAG_REQUEST = {
    "archetype_code": "rag_assistant",
    "components": [
        {"component_code": "gpt4o"},
        {"component_code": "embed"},
        {"component_code": "aisearch"},
        {"component_code": "pega", "quantity": "2"},
    ],
    "usage": {
        "requests_per_month": 10000,
        "input_tokens_per_request": 1500,
        "output_tokens_per_request": 300,
        "calls_per_request": "3",
        "time_horizon_months": 12,
    },
    "business_area": "Mortgages",
    "priced_on": "2026-06-28",
    "created_by": "madhurjya",
}


# ----------------------------------------------------------------------
print("\nAPI TEST 1 — POST /estimates returns the hand-calculated result")
resp = client.post("/estimates", json=RAG_REQUEST)
check("201 created", resp.status_code == 201)
body = resp.json()
check("total_expected = 111116.80", D(body["total_expected"]) == D("111116.80"))
check("total_low = 110140.48",  D(body["total_low"])  == D("110140.48"))
check("total_high = 112093.12", D(body["total_high"]) == D("112093.12"))
check("MI split AI = 5440.80",        D(body["by_business_area"]["AI"]) == D("5440.80"))
check("MI split Platform = 5676.00",  D(body["by_business_area"]["Platform"]) == D("5676.00"))
check("MI split Mortgages = 100000",  D(body["by_business_area"]["Mortgages"]) == D("100000.00"))
check("7 lines (4 direct + cached-split none + 2 deps + embed)", len(body["lines"]) == 7)
check("no warnings (within archetype band)", body["warnings"] == [])
check("priced_on echoed", body["priced_on"] == "2026-06-28")
ESTIMATE_ID = body["estimate_id"]

# ----------------------------------------------------------------------
print("\nAPI TEST 2 — money is a JSON STRING on the wire, never a float")
raw = json.loads(resp.text)   # re-parse the raw wire text, no client magic
check("total_expected is str on the wire", isinstance(raw["total_expected"], str))
check("line cost is str on the wire", isinstance(raw["lines"][0]["cost"], str))
check("MI value is str on the wire", isinstance(raw["by_business_area"]["AI"], str))
# the literal string appears quoted in the raw JSON text
check('raw text contains "111116.80" quoted', '"111116.80"' in resp.text)

# ----------------------------------------------------------------------
print("\nAPI TEST 3 — GET /estimates/{id} returns the FROZEN stored copy")
resp2 = client.get(f"/estimates/{ESTIMATE_ID}")
check("200 ok", resp2.status_code == 200)
stored = resp2.json()
check("stored total matches returned total", D(stored["total_expected"]) == D("111116.80"))
check("stored line count = 7", len(stored["lines"]) == 7)
check("created_by persisted", stored["created_by"] == "madhurjya")
pega = [l for l in stored["lines"] if "PEGA" in l["component_name"]]
check("frozen unit_price_used = 50000", pega and D(pega[0]["unit_price_used"]) == D("50000.00"))

print("\nAPI TEST 4 — unknown id -> 404, not a crash")
resp3 = client.get("/estimates/no-such-id")
check("404 returned", resp3.status_code == 404)
check("error body says not_found", resp3.json().get("error") == "not_found")

# ----------------------------------------------------------------------
print("\nAPI TEST 5 — engine rejections surface as clean 422s")
bad = dict(RAG_REQUEST, components=[{"component_code": "rogue"}])
resp4 = client.post("/estimates", json=bad)
check("unapproved component -> 422", resp4.status_code == 422)
check("error identifies the component", resp4.json().get("component") == "rogue")
check("error type is unapproved_component", resp4.json().get("error") == "unapproved_component")

nonexistent = dict(RAG_REQUEST, components=[{"component_code": "does_not_exist"}])
resp5 = client.post("/estimates", json=nonexistent)
check("unknown component -> 422 (same rejection path)", resp5.status_code == 422)

# ----------------------------------------------------------------------
print("\nAPI TEST 6 — bad request SHAPES rejected before the engine")
for name, mutation in [
    ("empty components list", {"components": []}),
    ("negative requests_per_month", {"usage": {"requests_per_month": -5}}),
    ("eligibility_rate > 1", {"usage": {"eligibility_rate": "1.5"}}),
    ("zero time horizon", {"usage": {"time_horizon_months": 0}}),
    ("unknown extra field", {"usage": {"requests_per_month": 1, "made_up_field": 9}}),
]:
    r = client.post("/estimates", json=dict(RAG_REQUEST, **mutation))
    check(f"{name} -> 422", r.status_code == 422)

# ----------------------------------------------------------------------
print("\nAPI TEST 7 — token anatomy through the API == flat equivalent")
anatomy_req = json.loads(json.dumps(RAG_REQUEST))
anatomy_req["components"] = [{"component_code": "gpt4o"}]
anatomy_req["usage"]["input_tokens_per_request"] = 0
anatomy_req["usage"]["anatomy"] = {
    "system_prompt": 200, "conversation_history": 400, "rag_context": 600,
    "tool_definitions": 100, "tool_results": 100, "user_message": 100}  # = 1500
flat_req = json.loads(json.dumps(RAG_REQUEST))
flat_req["components"] = [{"component_code": "gpt4o"}]
r_anat = client.post("/estimates", json=anatomy_req).json()
r_flat = client.post("/estimates", json=flat_req).json()
check("anatomy total == flat 1500 total",
      D(r_anat["total_expected"]) == D(r_flat["total_expected"]))

# ----------------------------------------------------------------------
print("\nAPI TEST 8 — immutability THROUGH the API (price change after save)")
conn = sqlite3.connect(DB)
conn.execute("UPDATE price SET effective_to='2026-06-29' WHERE component_code='pega' AND effective_to IS NULL")
conn.execute("INSERT INTO price (component_code,unit,unit_price,currency,effective_from,effective_to) "
             "VALUES ('pega','licence','100000.00','USD','2026-06-29',NULL)")
conn.commit(); conn.close()

# the SAVED estimate still shows the old, frozen numbers
resp6 = client.get(f"/estimates/{ESTIMATE_ID}")
check("saved estimate UNCHANGED after price change",
      D(resp6.json()["total_expected"]) == D("111116.80"))

# a NEW estimate priced after the change picks up the new price (+100k)
new_req = dict(RAG_REQUEST, priced_on="2026-06-29")
resp7 = client.post("/estimates", json=new_req)
check("new estimate uses NEW price (211116.80)",
      D(resp7.json()["total_expected"]) == D("211116.80"))

# and re-pricing on the OLD date still reproduces the old total
repro_req = dict(RAG_REQUEST)   # priced_on stays 2026-06-28
resp8 = client.post("/estimates", json=repro_req)
check("old date reproduces old total (reproducibility)",
      D(resp8.json()["total_expected"]) == D("111116.80"))

# ----------------------------------------------------------------------
print("\nAPI TEST 9 — GET /catalogue lists components + current prices")
resp9 = client.get("/catalogue")
check("200 ok", resp9.status_code == 200)
cat = resp9.json()
check("51 components listed", len(cat["components"]) == 51)
check("11 archetypes listed (incl. V2 additions)", len(cat["archetypes"]) == 11)
check("V1 archetypes all still present (additive only)",
      {"rag_assistant", "ml_solution", "agentic_ai", "chatbot", "fraud_triage",
       "doc_qa", "tiny", "none"} <= {a["code"] for a in cat["archetypes"]})
check("register templates present (Chatbot, Fraud Triage, Doc Q&A)",
      {"chatbot", "fraud_triage", "doc_qa"} <= {a["code"] for a in cat["archetypes"]})
check("components carry layer + description",
      all(c["layer"] and "description" in c for c in cat["components"]))
check("all components carry a cloud tag (azure for now)",
      all(c["cloud"] == "azure" for c in cat["components"]))
check("agentic archetype has 10-call default",
      [a for a in cat["archetypes"] if a["code"] == "agentic_ai"][0]
      ["default_usage"]["calls_per_request"] == 10)
gpt = [c for c in cat["components"] if c["code"] == "gpt4o"][0]
check("gpt4o has 3 current prices", len(gpt["current_prices"]) == 3)
check("prices are strings on the wire",
      all(isinstance(p["unit_price"], str) for p in gpt["current_prices"]))
rogue_c = [c for c in cat["components"] if c["code"] == "rogue"][0]
check("unapproved component flagged, not hidden", rogue_c["approved"] is False)
rag = [a for a in cat["archetypes"] if a["code"] == "rag_assistant"][0]
check("archetype defaults exposed", rag["default_usage"]["requests_per_month"] == 10000)
# NB: test 8 doubled the pega price effective 2026-06-29; /catalogue uses
# today's date, so pega's current price must now be the NEW 100000 row —
# proving the listing reads live prices, not stale ones.
pega_c = [c for c in cat["components"] if c["code"] == "pega"][0]
check("catalogue shows the LIVE price after a change",
      pega_c["current_prices"][0]["unit_price"] == "100000.00")

# ----------------------------------------------------------------------
print("\nAPI TEST 10 — every line carries a human-readable derivation trace")
resp10 = client.post("/estimates", json=RAG_REQUEST)
lines10 = resp10.json()["lines"]
by_key = {(l["component_code"], l["unit"]): l for l in lines10}
gin = by_key[("gpt4o", "input_token")]["derivation"]
check("LLM input trace shows the full chain",
      "10,000 req/mo" in gin and "3 calls" in gin and "1,500 tok/call" in gin
      and "12 mo" in gin and "540,000,000 tokens" in gin)
check("LLM input trace ends at the engine's own cost", "$1,350.00" in gin)
dep = by_key[("appsvc", "month")]["derivation"]
check("dependency line is labelled as auto-added",
      dep.startswith("auto-dependency of Azure OpenAI GPT-4o"))
check("dependency trace multiplies the horizon", "12 mo" in dep and "$876.00" in dep)
pega_d = by_key[("pega", "licence")]["derivation"]
check("one-off licence trace does NOT multiply months",
      "2 licence" in pega_d and "one-off" in pega_d and "$100,000.00" in pega_d)
check("every line has a derivation", all(l["derivation"] for l in lines10))

# ----------------------------------------------------------------------
print("\nAPI TEST 11 — Epic 1a: volume modes + solution naming")
# 500 requests/day x 30 must equal an explicit 15,000/month run
vol_day = json.loads(json.dumps(RAG_REQUEST))
vol_day["usage"]["requests_per_month"] = 0
vol_day["usage"]["volume"] = {"mode": "per_day", "count": 500}
explicit = json.loads(json.dumps(RAG_REQUEST))
explicit["usage"]["requests_per_month"] = 15000
r_day = client.post("/estimates", json=vol_day).json()
r_exp = client.post("/estimates", json=explicit).json()
check("per_day 500 == explicit 15,000/month",
      D(r_day["total_expected"]) == D(r_exp["total_expected"]))
# 300 users x 50 req/user/month = the same 15,000
vol_user = json.loads(json.dumps(RAG_REQUEST))
vol_user["usage"]["requests_per_month"] = 0
vol_user["usage"]["volume"] = {"mode": "per_user", "count": 300, "per_unit_rate": "50"}
r_user = client.post("/estimates", json=vol_user).json()
check("per_user 300x50 == explicit 15,000/month",
      D(r_user["total_expected"]) == D(r_exp["total_expected"]))
# solution name + components persisted with the estimate
named = dict(RAG_REQUEST, solution_name="Mortgage RAG Assistant", description="demo")
r_named = client.post("/estimates", json=named).json()
conn = sqlite3.connect(DB)
sol = conn.execute(
    "SELECT s.name, s.description FROM solution s JOIN estimate e ON e.solution_id=s.id WHERE e.id=?",
    (r_named["estimate_id"],)).fetchone()
ncomps = conn.execute(
    "SELECT count(*) FROM solution_component sc JOIN estimate e ON e.solution_id=sc.solution_id WHERE e.id=?",
    (r_named["estimate_id"],)).fetchone()[0]
conn.close()
check("solution name persisted", sol[0] == "Mortgage RAG Assistant")
check("chosen components persisted (4)", ncomps == 4)
check("bad volume mode -> 422",
      client.post("/estimates", json=dict(RAG_REQUEST, usage={"volume": {"mode": "per_hour", "count": 5}})).status_code == 422)

# ----------------------------------------------------------------------
print("\nAPI TEST 12 — Epic 2 AC4-6: observability coverage in the response")
r12 = client.post("/estimates", json=RAG_REQUEST).json()
obs = r12["observability"]
check("0% coverage with no observability components", D(obs["coverage_pct"]) == 0)
check("all SEVEN dimensions missing (register's 6 + alerting)",
      set(obs["missing"]) == {"logging", "tracing", "metrics", "alerting",
                              "drift", "rag_eval", "governance"})
check("understated warning present", any("understated" in w for w in obs["warnings"]))
check("warning quantifies FINANCIAL impact (Epic 2 AC6: 5-15% = $5,555.84-$16,667.52)",
      "$5,555.84" in obs["warnings"][0] and "$16,667.52" in obs["warnings"][0])
with_obs = json.loads(json.dumps(RAG_REQUEST))
with_obs["components"] += [{"component_code": "appinsights"}, {"component_code": "tracing"}]
r12b = client.post("/estimates", json=with_obs).json()
check("2 of 7 covered", D(r12b["observability"]["coverage_pct"]) == D(2) / D(7) * 100)
check("partial warning names the gaps",
      "metrics" in r12b["observability"]["warnings"][0])
ai_obs = json.loads(json.dumps(RAG_REQUEST))
ai_obs["priced_on"] = "2026-07-02"   # new obs components priced from 2026-07-02
ai_obs["components"] += [{"component_code": "driftmon"}, {"component_code": "rageval"},
                         {"component_code": "aigov"}, {"component_code": "datadog"}]
r12c = client.post("/estimates", json=ai_obs).json()
check("AI-specific + SaaS dimensions count (drift/rag_eval/governance covered)",
      {"drift", "rag_eval", "governance"} <= set(r12c["observability"]["covered"]))

print("\nAPI TEST 13 — Epic 9: assumption sources + confidence")
# RAG_REQUEST supplies requests/in/out/calls; archetype fills nothing extra
# (user values match all material fields except horizon comes from user too)
a13 = {a["field"]: a for a in r12["assumptions"]}
check("requests_per_month = user", a13["requests_per_month"]["source"] == "user")
check("horizon = user (12 sent explicitly)", a13["time_horizon_months"]["source"] == "user")
blank = dict(RAG_REQUEST, usage={})   # archetype fills everything
r13 = client.post("/estimates", json=blank).json()
a13b = {a["field"]: a for a in r13["assumptions"]}
check("blank usage -> archetype_default", a13b["requests_per_month"]["source"] == "archetype_default")
check("archetype values marked assumed", a13b["requests_per_month"]["status"] == "assumed")
check("blank usage -> 0% confidence", D(r13["confidence_pct"]) == 0)
check("full user usage -> 100% confidence", D(r12["confidence_pct"]) == 100)

print("\nAPI TEST 14 — Epic 5: projection + model comparison endpoints")
# identity check on a RUN-RATE solution (no one-off licence):
# zero growth -> projection total == flat estimate total
runrate = json.loads(json.dumps(RAG_REQUEST))
runrate["components"] = [{"component_code": "gpt4o"}, {"component_code": "embed"},
                         {"component_code": "aisearch"}]
flat = client.post("/estimates", json=runrate).json()
p0 = client.post("/estimates/projection", json=runrate).json()
check("zero growth: projection total == flat total (run-rate solution)",
      D(p0["total"]) == D(flat["total_expected"]))
check("12 monthly points", len(p0["monthly"]) == 12)
check("no warning for run-rate solution", p0["warnings"] == [])
# one-off licence in the solution -> projection warns (engine's simple model)
p_lic = client.post("/estimates/projection", json=RAG_REQUEST).json()
check("licence in projection -> explicit warning",
      any("One-off" in w for w in p_lic["warnings"]))
# growth 10%: month2 = month1 x 1.1 exactly
grow = json.loads(json.dumps(runrate))
grow["usage"]["growth_rate_monthly"] = "0.1"
p1 = client.post("/estimates/projection", json=grow).json()
check("month2 = month1 x 1.1", D(p1["monthly"][1]) == D(p1["monthly"][0]) * D("1.1"))
check("growth total > flat total", D(p1["total"]) > D(p0["total"]))
cmp_req = {"request": RAG_REQUEST, "swap_from": "gpt4o",
           "candidates": ["gpt4o", "gpt4omini"]}
c14 = client.post("/estimates/compare", json=cmp_req).json()
check("2 candidates returned", isinstance(c14, list) and len(c14) == 2)
check("sorted cheapest first", D(c14[0]["total_expected"]) <= D(c14[-1]["total_expected"]))
check("gpt4o candidate == original estimate",
      any(D(row["total_expected"]) == D(r12["total_expected"]) for row in c14))
# a candidate with no price on the pricing date is REFUSED, not guessed:
# gpt54nano prices start 2026-07-02; this request prices on 2026-06-28
no_price_cmp = {"request": RAG_REQUEST, "swap_from": "gpt4o", "candidates": ["gpt54nano"]}
r_np = client.post("/estimates/compare", json=no_price_cmp)
check("candidate without a dated price -> 422 missing_price",
      r_np.status_code == 422 and r_np.json().get("error") == "missing_price")
bad_cmp = {"request": RAG_REQUEST, "swap_from": "not_in_solution", "candidates": ["gpt4omini"]}
check("bad swap_from -> 422", client.post("/estimates/compare", json=bad_cmp).status_code == 422)

print("\nAPI TEST 15 — Epic 3a: admin price change (RBAC-enforced, logged)")
ADMIN = {"X-API-Key": "local-admin-key"}
r15 = client.post("/estimates", json=RAG_REQUEST).json()   # freeze before change
pc_body = {"component_code": "aisearch", "unit": "month",
           "new_price": "300.00", "effective_from": "2026-06-29"}
check("no key -> 401", client.post("/admin/prices", json=pc_body).status_code == 401)
check("User role -> 403", client.post("/admin/prices", json=pc_body,
      headers={"X-API-Key": "local-user-key"}).status_code == 403)
pc = client.post("/admin/prices", json=pc_body, headers=ADMIN)
check("Admin key -> 201", pc.status_code == 201)
check("old price reported", pc.json()["old_price"] == "250.00")
check("editor identity stamped (Epic 3a AC3)", pc.json()["changed_by"] == "Local Admin")
hist = client.get("/admin/prices/aisearch").json()["history"]
check("history keeps BOTH rows (audit trail)", len(hist) == 2)
check("old row closed at change date", hist[0]["effective_to"] == "2026-06-29")
# frozen estimate unaffected; new estimate on a later date picks up 300
r15b = client.get(f"/estimates/{r15['estimate_id']}").json()
check("frozen estimate unaffected by admin change",
      D(r15b["total_expected"]) == D(r15["total_expected"]))
later = dict(RAG_REQUEST, priced_on="2026-06-29")
r15c = client.post("/estimates", json=later).json()
# 2026-06-29 sees BOTH dated changes in this test DB: +600 (aisearch 250->300
# x12mo, this test) AND +100,000 (pega 50k->100k x2, from TEST 8)
check("new estimate re-priced (+600 search, +100k pega)",
      D(r15c["total_expected"]) == D(r15["total_expected"]) + D("600.00") + D("100000.00"))
check("unknown component -> 404",
      client.post("/admin/prices", json={"component_code": "ghost", "unit": "month",
                                         "new_price": "1.00"}, headers=ADMIN).status_code == 404)

print("\nAPI TEST 16 — Epic 6: estimate list + stored solution (duplicate basis)")
listed = client.get("/estimates").json()
check("list returns saved estimates", len(listed) >= 5)
check("newest first", listed[0]["estimate_id"] == r15c["estimate_id"])
named2 = dict(RAG_REQUEST, solution_name="List Test")
rn = client.post("/estimates", json=named2).json()
listed2 = client.get("/estimates").json()
check("name appears in list", listed2[0]["name"] == "List Test")
stored_full = client.get(f"/estimates/{rn['estimate_id']}").json()
check("stored solution has archetype", stored_full["solution"]["archetype_code"] == "rag_assistant")
check("stored solution has 4 components", len(stored_full["solution"]["components"]) == 4)
check("stored usage has requests", stored_full["solution"]["usage"]["requests_per_month"] == 10000)

print("\nAPI TEST 17 — Epic 8: actuals/variance + CSV export")
eid = rn["estimate_id"]
a1 = client.post(f"/estimates/{eid}/actuals", json={"period": "2026-07", "amount": "9500.00"})
a2 = client.post(f"/estimates/{eid}/actuals", json={"period": "2026-08", "amount": "9400.00"})
check("actuals recorded", a1.status_code == 201 and a2.status_code == 201)
va = client.get(f"/estimates/{eid}").json()
# expected/period = 111116.80/12 = 9259.733... x 2 = 18519.47 (2dp)
check("expected_to_date = 18519.47", D(va["expected_to_date"]) == D("18519.47"))
check("actual_total = 18900.00", D(va["actual_total"]) == D("18900.00"))
check("variance = +380.53", D(va["variance"]) == D("380.53"))
check("frozen total STILL unchanged", D(va["total_expected"]) == D(rn["total_expected"]))
check("actuals on unknown estimate -> 404",
      client.post("/estimates/no-such/actuals", json={"period": "2026-07", "amount": "1"}).status_code == 404)
check("bad period format -> 422",
      client.post(f"/estimates/{eid}/actuals", json={"period": "July", "amount": "1"}).status_code == 422)
csv_resp = client.get(f"/estimates/{eid}/export")
check("CSV export 200 + attachment", csv_resp.status_code == 200
      and "attachment" in csv_resp.headers.get("content-disposition", ""))
check("CSV has the frozen total", "TOTAL_EXPECTED,111116.80" in csv_resp.text)
check("CSV has line rows", "PEGA Licence" in csv_resp.text)

# ----------------------------------------------------------------------
print("\nAPI TEST 18 — shared components through the API (cost attribution)")
shared_req = json.loads(json.dumps(RAG_REQUEST))
shared_req["components"] = [
    {"component_code": "gpt4o"}, {"component_code": "embed"},
    {"component_code": "aisearch"},
    {"component_code": "pega", "quantity": "2", "shared": True},
]
r18 = client.post("/estimates", json=shared_req).json()
check("shared pega: total drops to 11,116.80", D(r18["total_expected"]) == D("11116.80"))
check("shared_cost = 100,000 on the wire", D(r18["shared_cost"]) == D("100000.00"))
pega_line = [l for l in r18["lines"] if l["component_code"] == "pega"][0]
check("pega line flagged shared", pega_line["shared"] is True)
check("shared trace says costed elsewhere", "costed elsewhere" in pega_line["derivation"])
check("Mortgages absent from MI split", "Mortgages" not in r18["by_business_area"])
# frozen record keeps the distinction + duplicate basis keeps the flag
stored18 = client.get(f"/estimates/{r18['estimate_id']}").json()
comp18 = [c for c in stored18["solution"]["components"] if c["component_code"] == "pega"][0]
check("shared flag persisted on the solution", comp18["shared"] == 1)
check("frozen total excludes shared (11,116.80)",
      D(stored18["total_expected"]) == D("11116.80"))

print("\nAPI TEST 19 — ML + agentic archetypes price end-to-end")
ml_req = {"archetype_code": "ml_solution",
          "components": [{"component_code": "databricks"},
                          {"component_code": "aml_endpoint"},
                          {"component_code": "aml_gpu", "quantity": "40"},
                          {"component_code": "adf"}],
          "usage": {}, "priced_on": "2026-07-02", "business_area": "Risk"}
r19 = client.post("/estimates", json=ml_req).json()
# databricks 600x12 + endpoint 205x12 + gpu 40hx3.67x12 + adf 100x12 + adls dep 21x12(x2 parents? dedup->qty 2? ratio1 each parent: 1+1=2 units x12mo x21)...
# hand-calc: 7200 + 2460 + 1761.60 + 1200 + adls (2 parents x 1 x 12 x 21 = 504) = 13,125.60
check("ML solution prices (13,125.60)", D(r19["total_expected"]) == D("13125.60"))
check("adls dependency expanded from BOTH ML parents (qty 24)",
      any(l["component_code"] == "adls" and D(l["quantity"]) == 24 for l in r19["lines"]))
agentic_req = {"archetype_code": "agentic_ai",
               "components": [{"component_code": "gpt4o"}, {"component_code": "functions"},
                               {"component_code": "cosmos"}, {"component_code": "apim"},
                               {"component_code": "contentsafety"}],
               "usage": {}, "priced_on": "2026-07-02"}
r19b = client.post("/estimates", json=agentic_req).json()
# agentic defaults: 5000 req x 10 calls = 50k calls x 2500 in x 12 = 1.5B in; x800 out x12=480M out
# gpt: 1500x2.50 + 480x10 = 3750+4800=8550; functions 1920 + cosmos 720 + apim 1764 + cs 600
# + deps appsvc 876 + sql 4560 = 19,290? -> 8550+1920+720+1764+600+876+4560 = 18,990.00
check("agentic solution prices (18,990.00)", D(r19b["total_expected"]) == D("18990.00"))
check("agentic archetype filled 10 calls/request",
      any(a["field"] == "calls_per_request" and a["value"] == "10"
          for a in r19b["assumptions"]))

# ----------------------------------------------------------------------
print("\nAPI TEST 20 — Epic 7 AC3: component CRUD + audit log (RBAC)")
new_comp = {"code": "zz_test", "name": "Test Fixture Component",
            "component_type": "infra", "layer": "data_platform",
            "description": "Low-latency cache", "mi_tag": "Platform"}
check("add component without key -> 401",
      client.post("/admin/components", json=new_comp).status_code == 401)
check("add component -> 201",
      client.post("/admin/components", json=new_comp, headers=ADMIN).status_code == 201)
check("duplicate add -> 409",
      client.post("/admin/components", json=new_comp, headers=ADMIN).status_code == 409)
check("new component appears in catalogue",
      any(c["code"] == "zz_test" for c in client.get("/catalogue").json()["components"]))
check("archive -> gone from catalogue",
      client.post("/admin/components/zz_test/archive", headers=ADMIN).status_code == 200
      and not any(c["code"] == "zz_test" for c in client.get("/catalogue").json()["components"]))
check("archived component cannot be estimated (engine can't see it)",
      client.post("/estimates", json=dict(RAG_REQUEST,
          components=[{"component_code": "zz_test"}])).status_code == 422)
check("restore -> back in catalogue",
      client.post("/admin/components/zz_test/restore", headers=ADMIN).status_code == 200
      and any(c["code"] == "zz_test" for c in client.get("/catalogue").json()["components"]))
log = client.get("/admin/log", headers=ADMIN).json()["log"]
check("audit log records add/archive/restore with actor",
      {"component_add", "archive", "restore"} <= {e["action"] for e in log}
      and all(e["actor"] == "Local Admin" for e in log[:3]))

print("\nAPI TEST 21 — Epic 6 AC1: drafts (save at any stage)")
draft = {"name": "half-finished idea", "payload": {"archetype_code": "chatbot",
         "components": [{"component_code": "gpt4omini"}]}, "created_by": "madhurjya"}
d = client.post("/drafts", json=draft)
check("draft saved -> 201", d.status_code == 201)
did = d.json()["draft_id"]
check("draft listed", any(x["id"] == did for x in client.get("/drafts").json()))
back = client.get(f"/drafts/{did}").json()
check("draft payload round-trips", back["payload"]["archetype_code"] == "chatbot")
check("draft is NOT an estimate (not in the ledger)",
      not any(e["estimate_id"] == did for e in client.get("/estimates").json()))

print("\nAPI TEST 22 — Epic 8 AC2/AC5: business dashboard + export")
dash = client.get("/dashboard/business").json()
check("dashboard aggregates across estimates", dash["estimate_count"] >= 10)
tags = {r["mi_tag"] for r in dash["by_mi_tag"]}
check("MI tags aggregated", {"AI", "Platform"} <= tags)
filtered = client.get("/dashboard/business", params={"area": "Mortgages"}).json()
check("area filter reduces the set", filtered["estimate_count"] < dash["estimate_count"])
exp = client.get("/dashboard/business/export")
check("dashboard CSV export", exp.status_code == 200 and "mi_tag,total" in exp.text)

print("\nAPI TEST 23 — Epic 2 AC1/AC3/AC8: figures + confidence band")
r23 = client.post("/estimates", json=RAG_REQUEST).json()
f = r23["figures"]
check("monthly = total/12", D(f["monthly"]) == (D(r23["total_expected"]) / 12).quantize(D("0.01")))
check("daily = monthly/30", D(f["daily"]) == (D(f["monthly"]) / 30).quantize(D("0.01")))
# token cost 2440.80 / (10,000 req x 12 mo) = 0.02034/request
check("per-request AI cost = 0.0203", D(f["per_request_ai"]) == D("0.0203"))
check("tokens per request: 4,500 uncached in (1500x3 calls)",
      f["tokens_per_request"]["uncached_input"] == "4500")
check("confidence band High at 100%", r23["confidence_band"] == "High")
blank23 = client.post("/estimates", json=dict(RAG_REQUEST, usage={})).json()
check("confidence band Low at 0%", blank23["confidence_band"] == "Low")

print("\nAPI TEST 24 — Epic 8 AC1 + Epic 9 AC5: multi-area + assumptions in CSV")
multi = dict(RAG_REQUEST, business_area=["Mortgages", "Payments"])
r24 = client.post("/estimates", json=multi).json()
stored24 = client.get(f"/estimates/{r24['estimate_id']}").json()
check("multiple business areas stored",
      stored24["solution"]["business_area"] == "Mortgages, Payments")
csv24 = client.get(f"/estimates/{r24['estimate_id']}/export").text
check("CSV includes assumption statuses (Epic 9 AC5)",
      "assumption,value,source,status" in csv24 and "requests_per_month" in csv24)
check("CSV assumption marked supplied", "10000,user,supplied" in csv24.replace('"', ''))

# ----------------------------------------------------------------------
print("\nAPI TEST 26 — Epic 1b: calls per volume unit (AC1) + saved/visible (AC2)")
# gpt4o only, explicit usage, priced 2026-06-28 (appsvc 73, sql 400 on that date).
# archetype 'none' (blank canvas): no defaults interfere with the linearity check
base_1b = {"archetype_code": "none",
           "components": [{"component_code": "gpt4o"}],
           "usage": {"requests_per_month": 10000, "input_tokens_per_request": 1500,
                     "output_tokens_per_request": 300, "calls_per_request": "1",
                     "time_horizon_months": 12},
           "priced_on": "2026-06-28"}
r_c1 = client.post("/estimates", json=base_1b).json()
# hand-calc calls=1: in 180M x 2.50 = 450 · out 36M x 10 = 360 · fixed 876+4800
check("calls=1 -> 6,486.00", D(r_c1["total_expected"]) == D("6486.00"))
c2 = json.loads(json.dumps(base_1b)); c2["usage"]["calls_per_request"] = "2"
r_c2 = client.post("/estimates", json=c2).json()
# AC1 is a LINEAR multiplier on token lines ONLY: doubling calls adds exactly
# the calls=1 token cost (810) and moves nothing else
check("calls=2 adds exactly the token cost (810.00)",
      D(r_c2["total_expected"]) - D(r_c1["total_expected"]) == D("810.00"))
fixed_1 = [l["cost"] for l in r_c1["lines"] if l["unit"] == "month"]
fixed_2 = [l["cost"] for l in r_c2["lines"] if l["unit"] == "month"]
check("fixed lines untouched by the calls multiplier", fixed_1 == fixed_2)
# template default when omitted, and LABELLED as the template's
noc = json.loads(json.dumps(base_1b)); noc["archetype_code"] = "rag_assistant"
del noc["usage"]["calls_per_request"]
r_nc = client.post("/estimates", json=noc).json()
a_nc = {a["field"]: a for a in r_nc["assumptions"]}
check("omitted calls -> archetype default 3, marked assumed",
      a_nc["calls_per_request"]["value"] == "3"
      and a_nc["calls_per_request"]["source"] == "archetype_default")
# KNOWN MERGE LIMITATION (pinned deliberately, logged as an open question):
# calls=1 is the engine's 'not set' sentinel, so with an archetype that
# defines calls, an explicit user 1 is overridden by the template — and the
# assumption chip HONESTLY reports source=archetype, value=3.
sent = json.loads(json.dumps(base_1b)); sent["archetype_code"] = "rag_assistant"
r_sent = client.post("/estimates", json=sent).json()
a_sent = {a["field"]: a for a in r_sent["assumptions"]}
check("sentinel quirk pinned: explicit calls=1 + rag archetype -> engine uses 3, labelled archetype",
      a_sent["calls_per_request"]["value"] == "3"
      and a_sent["calls_per_request"]["source"] == "archetype_default")
# AC2: persisted with the estimate
stored_1b = client.get(f"/estimates/{r_c2['estimate_id']}").json()
check("calls persisted on the stored solution",
      stored_1b["solution"]["usage"]["calls_per_request"] == "2")
# boundary: zero calls makes no sense -> rejected at the shape layer
zc = json.loads(json.dumps(base_1b)); zc["usage"]["calls_per_request"] = "0"
check("calls=0 -> 422", client.post("/estimates", json=zc).status_code == 422)

# ----------------------------------------------------------------------
print("\nAPI TEST 27 — V2: sourced components, BOM, PTU, quote-only, price correction")
cat27 = client.get("/catalogue").json()
arch27 = {a["code"]: a for a in cat27["archetypes"]}
check("rag_assistant BOM = its canonical 3 components",
      {c["component_code"] for c in arch27["rag_assistant"]["components"]}
      == {"gpt4o", "embed", "aisearch"})
check("ml_batch BOM pre-marks purview as SHARED",
      any(c["component_code"] == "purview" and c["shared"]
          for c in arch27["ml_batch"]["components"]))
# quote-only component: NO price row -> the engine refuses (honest Class D)
r_lab = client.post("/estimates", json={"archetype_code": "none",
    "components": [{"component_code": "labeling"}], "usage": {},
    "priced_on": "2026-07-08"})
check("unpriced (quote-only) labeling -> 422 missing_price",
      r_lab.status_code == 422 and r_lab.json()["error"] == "missing_price")
# dated price correction: functions 160 before 2026-07-07, 146 after
f_old = client.post("/estimates", json={"archetype_code": "none",
    "components": [{"component_code": "functions"}], "usage": {},
    "priced_on": "2026-07-06"}).json()
f_new = client.post("/estimates", json={"archetype_code": "none",
    "components": [{"component_code": "functions"}], "usage": {},
    "priced_on": "2026-07-08"}).json()
check("functions on 2026-07-06 -> 1,920 (old 160)", D(f_old["total_expected"]) == D("1920.00"))
check("functions on 2026-07-08 -> 1,752 (sourced 146)", D(f_new["total_expected"]) == D("1752.00"))
# PTU: month unit, qty = PTUs -> 50 PTU x 12 mo x 730.00
r_ptu = client.post("/estimates", json={"archetype_code": "none",
    "components": [{"component_code": "ptu_global", "quantity": "50"}], "usage": {},
    "priced_on": "2026-07-08"}).json()
check("50 Global PTUs x 12mo = 438,000.00", D(r_ptu["total_expected"]) == D("438000.00"))
# free component: 0.00 line VISIBLE, deps still expand and cost
r_fs = client.post("/estimates", json={"archetype_code": "none",
    "components": [{"component_code": "feature_store"}], "usage": {},
    "priced_on": "2026-07-08"}).json()
fs_line = [l for l in r_fs["lines"] if l["component_code"] == "feature_store"][0]
check("free feature store: 0.00 line listed", D(fs_line["cost"]) == 0)
check("free feature store still pulls adls+redis (732.00 total)",
      D(r_fs["total_expected"]) == D("732.00"))
# full ML-batch BOM estimate, built FROM the catalogue BOM (integration)
bom_comps = [{"component_code": c["component_code"], "quantity": c["quantity"],
              "shared": bool(c["shared"])} for c in arch27["ml_batch"]["components"]]
r_mlb = client.post("/estimates", json={"archetype_code": "ml_batch",
    "components": bom_comps, "usage": {}, "priced_on": "2026-07-08"}).json()
# hand-calc: databricks 7200 + adf 1200 + aml_batch 160h x 12 x .192 = 368.64
# + mlops 480 + driftmon 480 + redis 480 + adls(3 parents) 756 + free 0s = 10,964.64
check("ML-batch template = 10,964.64 attributed", D(r_mlb["total_expected"]) == D("10964.64"))
check("purview 3,600 sits in shared estate", D(r_mlb["shared_cost"]) == D("3600.00"))

# ----------------------------------------------------------------------
print("\nAPI TEST 28 — Phase 2 LLM advisor: ask loop, grounding, sign-off audit")
# The LLM is MOCKED with scripted responses: deterministic, free, key-independent.
# What we test is OUR machinery: session state, the grounding guardrail, the
# question budget, and the sign-off audit trail.
import service as _service_mod
_scripted = []
def _fake_llm(self, messages, max_tokens=4096):
    return _scripted.pop(0)
_orig_llm = _service_mod.EstimateService._llm_call
_service_mod.EstimateService._llm_call = _fake_llm

# (a) triage asks -> ready -> PIPELINE: inventory -> architect x2 <- evaluator
_arch_v1 = {"archetype_code": "doc_qa", "solution_name": "Policy Q&A",
    "business_area": "Mortgages", "summary": "RAG over policy documents.",
    "archetype_confidence": "ABSOLUTELY",   # invalid -> sanitized to medium
    "archetype_confidence_reason": "Classic document Q&A shape.",
    "usage_confidence": "low",              # valid -> passes through
    "usage_confidence_reason": "Volumes were a rough verbal estimate.",
    "usage": {"requests_per_month": 5000, "input_tokens_per_request": 3000,
              "output_tokens_per_request": 400, "calls_per_request": 2,
              "eligibility_rate": 1, "time_horizon_months": 12},
    "components": [
        {"component_code": "gpt4o", "quantity": 1, "shared": False,
         "rationale": "generation", "how_to_use": "cache the system prompt",
         "confidence": "medium",
         "confidence_reason": "A smaller model with tuned prompts could handle this workload.",
         "alternatives": ["gpt4omini", "rogue_model", "gpt4o"]},
        {"component_code": "aisearch", "quantity": 1, "shared": True,
         "rationale": "existing index", "how_to_use": "reuse the shared index",
         "confidence": "EXTREMELY SURE",
         "alternatives": []},
        {"component_code": "embed", "quantity": 1, "shared": False,
         "rationale": "vectorise queries and documents for retrieval",
         "confidence": "high", "alternatives": []},
    ]}
_arch_v2 = json.loads(json.dumps(_arch_v1))
_arch_v2["components"] += [
    {"component_code": "appinsights", "quantity": 1, "shared": False,
     "rationale": "logging per evaluator", "how_to_use": "wire app logs"},
    {"component_code": "rogue", "quantity": 1, "shared": False, "rationale": "sneaky"},
    {"component_code": "made_up_thing", "quantity": 9, "shared": False, "rationale": "hallucinated"},
]
_scripted[:] = [
    {"action": "ask", "question": "Roughly how many documents per month?"},   # triage
    {"action": "ready", "brief": "Policy doc Q&A, 5000/mo"},                   # triage
    {"checklist": [
        {"capability": "generation model", "layer": "intelligence",
         "required": True, "catalogue_options": ["gpt4o", "gpt54"],
         "confidence": "high", "confidence_reason": "Core of the solution."},
        {"capability": "application logs", "layer": "telemetry",   # invalid layer
         "required": True,
         "catalogue_options": ["appinsights", "datadog", "made_up_obs"],  # rogue option
         "confidence": "certain!!"},                                # invalid confidence
        {"layer": "observability", "required": True}]},   # no capability -> dropped  # Agent 1
    _arch_v1,                                                                   # Agent 2 v1
    {"satisfied": False, "score": 55, "issues": [
        {"severity": "high", "issue": "no logging", "fix": "add appinsights"}]},# Agent 3 rejects
    _arch_v2,                                                                   # Agent 2 v2 (poisoned)
    {"satisfied": True, "score": 90, "issues": []},                             # Agent 3 satisfied
]
c1 = client.post("/advisor/chat", json={"message": "I want to answer questions from policy documents"}).json()
check("first turn -> clarifying question", c1["type"] == "question" and "documents" in c1["question"])
sid = c1["session_id"]
c2 = client.post("/advisor/chat", json={"session_id": sid, "message": "about 5000 a month"}).json()
check("second turn -> proposal via the pipeline", c2["type"] == "proposal")
check("iteration loop recorded: v1 rejected (55), v2 satisfied (90)",
      len(c2["iterations"]) == 2 and c2["iterations"][0]["score"] == 55
      and c2["iterations"][1]["satisfied"] is True and c2["evaluator_satisfied"] is True)
check("deployment checklist attached (holistic view)",
      len(c2["checklist"]) == 2 and c2["checklist"][0]["capability"] == "generation model")
codes = {c["component_code"] for c in c2["components"]}
check("evaluator feedback acted on: appinsights added in v2", "appinsights" in codes)
check("guardrail STRIPPED unapproved + hallucinated components",
      "rogue" not in codes and "made_up_thing" not in codes and {"gpt4o", "aisearch"} <= codes)
check("guardrail is transparent about what it stripped",
      set(c2["stripped_by_guardrail"]) == {"rogue", "made_up_thing"})
check("shared flag survives from the proposal",
      [c for c in c2["components"] if c["component_code"] == "aisearch"][0]["shared"] is True)
check("how_to_use passes the guardrail",
      [c for c in c2["components"] if c["component_code"] == "gpt4o"][0]["how_to_use"] == "cache the system prompt")
check("usage clamped + passed through", c2["usage"]["requests_per_month"] == 5000)
check("advisor NEVER prices", "total_expected" not in json.dumps(c2))
_g4 = [c for c in c2["components"] if c["component_code"] == "gpt4o"][0]
_ai = [c for c in c2["components"] if c["component_code"] == "aisearch"][0]
check("confidence passes through when valid", _g4["confidence"] == "medium")
check("confidence reason survives the guardrail",
      "smaller model" in _g4["confidence_reason"])
check("invalid confidence sanitized to medium (whitelist, not trust)",
      _ai["confidence"] == "medium")
check("alternatives filtered: catalogue-only, no self, order kept",
      _g4["alternatives"] == ["gpt4omini"])
check("alternative names resolved for the UI",
      _g4["alternative_names"] == ["Azure OpenAI GPT-4o mini"])
check("archetype confidence sanitized (invalid -> medium), reason kept",
      c2["archetype_confidence"] == "medium"
      and "document Q&A" in c2["archetype_confidence_reason"])
check("usage confidence passes through when valid",
      c2["usage_confidence"] == "low"
      and "verbal estimate" in c2["usage_confidence_reason"])
_ck = c2["checklist"]
check("checklist guardrail: malformed item dropped", len(_ck) == 2)
check("checklist confidence passthrough + reason",
      _ck[0]["confidence"] == "high" and _ck[0]["confidence_reason"] == "Core of the solution.")
check("checklist guardrail: invalid confidence -> medium, invalid layer defaulted",
      _ck[1]["confidence"] == "medium" and _ck[1]["layer"] == "orchestration")
check("checklist guardrail: rogue catalogue option filtered",
      _ck[1]["catalogue_options"] == ["appinsights", "datadog"])
check("consistent proposal (model present) carries no consistency warnings",
      c2["consistency_warnings"] == [])

# (a2b) internal consistency: tokens without an llm_model + rageval without retrieval
_arch_no_model = {"archetype_code": "multi_agent", "solution_name": "Runtime-only agent",
    "business_area": "Payments", "summary": "Agent workflow, model implied but never picked.",
    "usage": {"requests_per_month": 4000, "input_tokens_per_request": 25000,
              "output_tokens_per_request": 8000, "calls_per_request": 10,
              "eligibility_rate": 0.8, "time_horizon_months": 12},
    "components": [
        {"component_code": "appsvc", "quantity": 1, "shared": False, "rationale": "front end"},
        {"component_code": "rageval", "quantity": 1, "shared": False, "rationale": "rag eval"},
    ]}
_scripted[:] = [{"action": "ready", "brief": "agentic DD workflow"},
                {"checklist": []}, _arch_no_model,
                {"satisfied": True, "score": 90, "issues": []}]
c4 = client.post("/advisor/chat", json={"message": "automate direct debit claims"}).json()
check("consistency guardrail: tokens without an LLM model flagged",
      any("NO LLM model" in w for w in c4["consistency_warnings"]))
check("consistency guardrail: rag eval without retrieval flagged",
      any("retrieval stack" in w for w in c4["consistency_warnings"]))

# (a2c) RAG solution that forgets the retrieval stack (embedding + vector store)
_arch_rag_gap = {"archetype_code": "rag_assistant", "solution_name": "Knowledge assistant",
    "business_area": "Mortgages", "summary": "Retrieves from a document corpus and drafts answers.",
    "usage": {"requests_per_month": 12000, "input_tokens_per_request": 3000,
              "output_tokens_per_request": 450, "calls_per_request": 2,
              "eligibility_rate": 0.85, "time_horizon_months": 12},
    "components": [
        {"component_code": "gpt4o", "quantity": 1, "shared": False, "rationale": "generation"},
        {"component_code": "appsvc", "quantity": 1, "shared": False, "rationale": "front end"},
    ]}
_scripted[:] = [{"action": "ready", "brief": "mortgage RAG assistant"},
                {"checklist": []}, _arch_rag_gap,
                {"satisfied": True, "score": 90, "issues": []}]
c5 = client.post("/advisor/chat", json={"message": "answer policy questions from documents"}).json()
check("consistency guardrail: RAG solution without embedding+vector store flagged",
      any("NEITHER an embedding model NOR a vector store" in w for w in c5["consistency_warnings"]))

_arch_rag_ok = json.loads(json.dumps(_arch_rag_gap))
_arch_rag_ok["components"] += [
    {"component_code": "embed", "quantity": 1, "shared": False, "rationale": "vectorise"},
    {"component_code": "aisearch", "quantity": 1, "shared": True, "rationale": "vector store"}]
_scripted[:] = [{"action": "ready", "brief": "mortgage RAG assistant"},
                {"checklist": []}, _arch_rag_ok,
                {"satisfied": True, "score": 92, "issues": []}]
c6 = client.post("/advisor/chat", json={"message": "answer policy questions from documents"}).json()
check("complete RAG proposal (embedding + vector store) has no retrieval warning",
      not any("retrieval" in w.lower() or "vector store" in w.lower() for w in c6["consistency_warnings"]))

# (a2d) brief demands observability the proposal omits -> named-dimension warning
_arch_obs_gap = {"archetype_code": "rag_assistant", "solution_name": "Servicing assistant",
    "business_area": "Mortgages",
    "summary": "Retrieves from a corpus; drafts answers. Full observability including model drift and RAG evaluation required.",
    "usage": {"requests_per_month": 12000, "input_tokens_per_request": 3000,
              "output_tokens_per_request": 450, "calls_per_request": 2,
              "eligibility_rate": 0.85, "time_horizon_months": 12},
    "components": [
        {"component_code": "gpt4o", "quantity": 1, "shared": False, "rationale": "generation"},
        {"component_code": "embed", "quantity": 1, "shared": False, "rationale": "vectorise"},
        {"component_code": "aisearch", "quantity": 1, "shared": True, "rationale": "vector store"},
        {"component_code": "appinsights", "quantity": 1, "shared": False, "rationale": "logging only"},
    ]}
_scripted[:] = [{"action": "ready",
                 "brief": "mortgage RAG assistant with full observability including model drift and RAG evaluation"},
                {"checklist": []}, _arch_obs_gap,
                {"satisfied": True, "score": 90, "issues": []}]
c7 = client.post("/advisor/chat", json={"message": "servicing assistant, full observability, drift and rag eval"}).json()
_obsw = " ".join(c7["consistency_warnings"]).lower()
check("observability guardrail: brief-demanded dims that are missing get named",
      "observability the proposal does not fully cover" in _obsw
      and "metrics" in _obsw and "model-drift" in _obsw and "rag evaluation" in _obsw)
check("observability guardrail: covered dimension (logging) is NOT listed missing",
      "missing: logging" not in _obsw and "logging," not in _obsw.split("missing:")[-1])

_arch_obs_ok = json.loads(json.dumps(_arch_obs_gap))
_arch_obs_ok["components"] += [
    {"component_code": "metrics", "quantity": 1, "shared": False, "rationale": "metrics"},
    {"component_code": "tracing", "quantity": 1, "shared": False, "rationale": "tracing"},
    {"component_code": "alerting", "quantity": 1, "shared": False, "rationale": "alerting"},
    {"component_code": "driftmon", "quantity": 1, "shared": False, "rationale": "drift"},
    {"component_code": "rageval", "quantity": 1, "shared": False, "rationale": "rag eval"}]
_scripted[:] = [{"action": "ready",
                 "brief": "mortgage RAG assistant with full observability including model drift and RAG evaluation"},
                {"checklist": []}, _arch_obs_ok,
                {"satisfied": True, "score": 94, "issues": []}]
c8 = client.post("/advisor/chat", json={"message": "servicing assistant, full observability, drift and rag eval"}).json()
check("complete observability proposal has no observability warning",
      not any("observability the proposal" in w for w in c8["consistency_warnings"]))

# (a2) evaluator never satisfied -> bounded at MAX_ITERATIONS, issues surfaced
_unsat = {"satisfied": False, "score": 40, "issues": [
    {"severity": "high", "issue": "still incomplete", "fix": "cover data layer"}]}
_scripted[:] = ([{"action": "ready", "brief": "vague ML thing"},
                 {"checklist": []}]
                + [_arch_v1, _unsat, _arch_v1, _unsat, _arch_v1, _unsat])
c3 = client.post("/advisor/chat", json={"message": "score customer churn somehow"}).json()
check("bounded loop: exactly 3 iterations", len(c3["iterations"]) == 3)
check("honest delivery: unsatisfied + open issues shown",
      c3["evaluator_satisfied"] is False and c3["open_issues"][0]["issue"] == "still incomplete")

# (a3) document upload: BRD in -> AI-distilled brief -> same pipeline
_scripted[:] = [
    {"brief": "Policy document Q&A over a shared search index, 5000 requests a month, Mortgages."},  # distill
    {"action": "ready", "brief": "Policy doc Q&A, 5000/mo"},                                          # triage
    {"checklist": []},                                                                                # Agent 1
    _arch_v1,                                                                                         # Agent 2
    {"satisfied": True, "score": 88, "issues": []},                                                   # Agent 3
]
_doc = ("The bank receives direct debit indemnity claims that require validation. " * 15).encode()
up = client.post("/advisor/upload",
                 files={"file": ("stage0_brd.txt", _doc, "text/plain")},
                 data={"created_by": "test"})
check("document upload -> proposal via the same pipeline",
      up.status_code == 200 and up.json()["type"] == "proposal")
check("brief was AI-generated from the document + source recorded",
      "5000 requests" in up.json()["generated_brief"]
      and up.json()["source_document"] == "stage0_brd.txt")

import io as _io
import zipfile as _zipf
_buf = _io.BytesIO()
with _zipf.ZipFile(_buf, "w") as _z:
    _z.writestr("word/document.xml",
                "<w:document><w:p><w:t>"
                + ("Claims validation requirements for direct debit operations. " * 10)
                + "</w:t></w:p></w:document>")
_scripted[:] = [
    {"brief": "Claims validation workflow."},
    {"action": "ready", "brief": "claims validation"},
    {"checklist": []}, _arch_v1, {"satisfied": True, "score": 85, "issues": []},
]
up2 = client.post("/advisor/upload", files={"file": ("req.docx", _buf.getvalue(),
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document")})
check("docx extraction works (stdlib zip+xml)",
      up2.status_code == 200 and up2.json()["type"] == "proposal")

# pptx extraction — a Stage-0 deck is a zip of slides; text lives in <a:t> runs
_pbuf = _io.BytesIO()
with _zipf.ZipFile(_pbuf, "w") as _z:
    _z.writestr("ppt/slides/slide1.xml",
                "<p:sld><a:t>Direct Debit Agentic Asset</a:t>"
                "<a:t>" + ("Claims validation over bank source systems. " * 8) + "</a:t></p:sld>")
    _z.writestr("ppt/slides/slide2.xml",
                "<p:sld><a:t>" + ("Human oversight and observability required. " * 6) + "</a:t></p:sld>")
_txt = _service_mod.EstimateService.extract_document_text("deck.pptx", _pbuf.getvalue())
check("pptx extraction reads slide <a:t> runs in order",
      "Direct Debit Agentic Asset" in _txt and "Human oversight" in _txt and len(_txt) > 80)
_scripted[:] = [
    {"brief": "Direct debit claims validation deck."},
    {"action": "ready", "brief": "dd claims validation"},
    {"checklist": []}, _arch_v1, {"satisfied": True, "score": 86, "issues": []},
]
up3 = client.post("/advisor/upload", files={"file": ("stage0.pptx", _pbuf.getvalue(),
      "application/vnd.openxmlformats-officedocument.presentationml.presentation")})
check("pptx upload runs the pipeline like any document",
      up3.status_code == 200 and up3.json()["type"] == "proposal")

# (a4) per-field usage assistants: config + guarded extraction
cfg = client.get("/advisor/assist/config").json()
check("assist config: dictionary + playbooks for all usage fields",
      cfg["dictionary"]["page"] == 650
      and {p["field"] for p in cfg["playbooks"]} >= {
          "u_req", "u_calls", "u_in", "u_out", "u_cached", "u_elig",
          "u_months", "u_growth", "a_sys", "a_hist", "a_rag", "a_tool",
          "a_res", "a_user"})
_chip_shapes_ok = all(
    (isinstance(v, (int, float)) or v in cfg["dictionary"])
    for p in cfg["playbooks"] for c in p["chips"] for v in (c.get("set") or {}).values())
check("assist config: every chip resolves to a number or a dictionary shape", _chip_shapes_ok)

_scripted[:] = [{"status": "derived", "values": {"a_rag": "page"}, "basis": "reads a page"}]
a1 = client.post("/advisor/assist", json={"field": "a_rag", "text": "about a page"}).json()
check("assist: shape token converted server-side via the dictionary",
      a1["status"] == "derived" and a1["values"]["a_rag"] == 650 and "650" in a1["working"])

_scripted[:] = [{"status": "derived",
                 "values": {"u_volmode": "per_day", "u_req": 400, "u_elig": 500,
                            "made_up_field": 99}}]
a2 = client.post("/advisor/assist", json={"field": "u_req", "text": "400 cases a day, all of them"}).json()
check("assist: composite volume derives mode + count, clamps %, drops rogue fields",
      a2["values"]["u_volmode"] == "per_day" and a2["values"]["u_req"] == 400
      and a2["values"]["u_elig"] == 100 and "made_up_field" not in a2["values"])

_scripted[:] = [{"status": "ask", "question": "Is that per user or in total?"}]
a3 = client.post("/advisor/assist", json={"field": "u_req", "text": "loads"}).json()
check("assist: ambiguous answer returns one clarifying question",
      a3["status"] == "ask" and "per user" in a3["question"])

_scripted[:] = [{"status": "derived", "values": {"u_out": "not_a_shape"}}]
a4 = client.post("/advisor/assist", json={"field": "u_out", "text": "hmm"}).json()
check("assist: unresolvable shapes collapse to unknown, never a made-up number",
      a4["status"] == "unknown")
check("assist: unknown field rejected with 404",
      client.post("/advisor/assist", json={"field": "u_nope", "text": "x"}).status_code == 404)

check("unsupported file type rejected with 415",
      client.post("/advisor/upload",
                  files={"file": ("x.exe", b"MZ binary junk", "application/octet-stream")}).status_code == 415)
check("too little readable text rejected with 422",
      client.post("/advisor/upload",
                  files={"file": ("tiny.txt", b"hi", "text/plain")}).status_code == 422)

# (b) sign-off: reject aisearch, accept gpt4o -> audit rows recorded
s1 = client.post("/advisor/signoff", json={"session_id": sid, "decided_by": "madhurjya",
    "decisions": [{"component_code": "gpt4o", "accepted": True},
                   {"component_code": "aisearch", "accepted": False}]}).json()
check("sign-off returns ONLY the accepted subset",
      [c["component_code"] for c in s1["accepted"]] == ["gpt4o"])
conn = sqlite3.connect(DB)
rows = conn.execute("SELECT component_code, accepted, decided_by FROM advisor_signoff "
                    "WHERE session_id=? ORDER BY component_code", (sid,)).fetchall()
status = conn.execute("SELECT status FROM advisor_session WHERE id=?", (sid,)).fetchone()[0]
conn.close()
check("audit trail: one decision row per component with identity (undecided -> rejected)",
      [(r[0], r[1]) for r in rows] == [("aisearch", 0), ("appinsights", 0), ("embed", 0), ("gpt4o", 1)]
      and all(r[2] == "madhurjya" for r in rows))
check("session marked signed_off", status == "signed_off")

# (c) question budget: model that keeps asking gets force-refused
_scripted[:] = [{"action": "ask", "question": f"q{i}?"} for i in range(7)]
sid2 = None
last = None
for i in range(7):
    last = client.post("/advisor/chat", json={"session_id": sid2, "message": f"answer {i}"}).json()
    sid2 = last["session_id"]
    if last["type"] != "question":
        break
check("question budget enforced -> forced refusal", last["type"] == "refusal")

# (d) hygiene: empty message 422, unknown session 404
check("empty message -> 422",
      client.post("/advisor/chat", json={"message": "  "}).status_code == 422)
check("unknown session -> 404",
      client.post("/advisor/chat", json={"session_id": "ghost", "message": "hi"}).status_code == 404)
check("sign-off without proposal -> 404",
      client.post("/advisor/signoff", json={"session_id": "ghost", "decisions": []}).status_code == 404)
_service_mod.EstimateService._llm_call = _orig_llm

# ----------------------------------------------------------------------
print("\nAPI TEST 29 — RBAC: whoami + Admin-only user management")
ADMIN_H = {"X-API-Key": "local-admin-key"}
USER_H = {"X-API-Key": "local-user-key"}
# whoami resolves identity + role
check("whoami admin -> Admin", client.get("/whoami", headers=ADMIN_H).json()["role"] == "Admin")
check("whoami user -> User", client.get("/whoami", headers=USER_H).json()["role"] == "User")
check("whoami no key -> 401", client.get("/whoami").status_code == 401)
# only Admin can list/add users
check("User cannot list users -> 403",
      client.get("/admin/users", headers=USER_H).status_code == 403)
check("no key cannot list users -> 401",
      client.get("/admin/users").status_code == 401)
seed_users = client.get("/admin/users", headers=ADMIN_H).json()["users"]
check("seed users present (Admin + User)",
      {u["role"] for u in seed_users} == {"Admin", "User"})
check("user key is never returned in full (hint only)",
      all("key" not in u or "…" in u.get("key_hint", "") for u in seed_users))
# add a user -> get a one-time key that actually works
added = client.post("/admin/users", json={"holder": "Priya (Reviewer)", "role": "User"},
                    headers=ADMIN_H)
check("add user -> 201 with one-time key",
      added.status_code == 201 and added.json()["api_key"].startswith("key-"))
new_key = added.json()["api_key"]
check("the new key authenticates as its role",
      client.get("/whoami", headers={"X-API-Key": new_key}).json()["role"] == "User")
check("new User still cannot change prices -> 403",
      client.post("/admin/prices", json={"component_code": "aisearch", "unit": "month",
          "new_price": "1.00"}, headers={"X-API-Key": new_key}).status_code == 403)
check("duplicate user -> 409",
      client.post("/admin/users", json={"holder": "Priya (Reviewer)", "role": "User"},
                  headers=ADMIN_H).status_code == 409)
check("bad role -> 422",
      client.post("/admin/users", json={"holder": "X", "role": "Superuser"},
                  headers=ADMIN_H).status_code == 422)
# deactivate the new user -> its key stops working
check("deactivate user -> 200",
      client.post("/admin/users/Priya (Reviewer)/deactivate", headers=ADMIN_H).status_code == 200)
check("deactivated key no longer authenticates",
      client.get("/whoami", headers={"X-API-Key": new_key}).status_code == 401)
# the last-admin guard: cannot deactivate the only Admin
check("cannot deactivate the last Admin -> 409",
      client.post("/admin/users/Local Admin/deactivate", headers=ADMIN_H).status_code == 409)
# admin actions are logged with the actor
ulog = client.get("/admin/log", headers=ADMIN_H).json()["log"]
check("user management is audited",
      any(e["action"] == "user_add" and e["target"] == "Priya (Reviewer)" for e in ulog))

# ----------------------------------------------------------------------
print("\nAPI TEST 30 — editable sizing: per-unit price × size (default preserves old flat)")
cat30 = {c["code"]: c for c in client.get("/catalogue").json()["components"]}
# catalogue exposes the sizing metadata
check("orchestrator_aca is sizable (GiB, default 2)",
      cat30["orchestrator_aca"]["sizing_unit"] == "GiB memory"
      and cat30["orchestrator_aca"]["default_quantity"] == "2")
check("app insights sizable (GB logs, default 20)",
      cat30["appinsights"]["sizing_unit"] == "GB logs/month"
      and cat30["appinsights"]["default_quantity"] == "20")
# at the DEFAULT size, the monthly matches the old documented flat price
def month_total(code, qty, months=12):
    r = client.post("/estimates", json={"archetype_code": "none",
        "components": [{"component_code": code, "quantity": str(qty)}],
        "usage": {}, "priced_on": "2026-07-08"}).json()
    return D(r["total_expected"])
check("orchestrator_aca @ 2 GiB × 12mo = 933.12 (old 77.76/mo)",
      month_total("orchestrator_aca", 2) == D("933.12"))
check("app insights @ 20 GB × 12mo = 552.00 (old 46/mo)",
      month_total("appinsights", 20) == D("552.00"))
# resizing changes the total LINEARLY — the whole point
check("orchestrator_aca @ 6 GiB = 3× the 2 GiB total (2799.36)",
      month_total("orchestrator_aca", 6) == D("933.12") * 3)
check("app insights @ 40 GB = 2× the 20 GB total (1104.00)",
      month_total("appinsights", 40) == D("552.00") * 2)
check("cosmos @ 4×1000 RU/s = 4× the 1-unit total",
      month_total("cosmos", 4) == month_total("cosmos", 1) * 4)
# a sizable component with NO dependency-scaling side effects: orchestrator_aca
# no longer drags servicebus/memory in (deps would have multiplied by GiB!)
r_orch = client.post("/estimates", json={"archetype_code": "none",
    "components": [{"component_code": "orchestrator_aca", "quantity": "6"}],
    "usage": {}, "priced_on": "2026-07-08"}).json()
check("resizing orchestrator does NOT scale phantom dependencies",
      {l["component_code"] for l in r_orch["lines"]} == {"orchestrator_aca"})

# ----------------------------------------------------------------------
print(f"\n==== API RESULTS: {PASS} passed, {FAIL} failed ====")
Path(DB).unlink(missing_ok=True)   # clean up the throwaway DB
raise SystemExit(1 if FAIL else 0)
