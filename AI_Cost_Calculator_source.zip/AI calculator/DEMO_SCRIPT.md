# Demo Script — AI Cost Calculator

> **2026-07-03 update: ALL 44 register ACs are live** (221 tests green). New since the scenes below were written: RBAC on admin endpoints (X-API-Key: `local-admin-key`), Diagram/Hub architecture views, multi-model curve chart, drafts, business dashboard, figures strip (monthly/daily/per-request), Low/Med/High confidence, 7-dimension observability with £ impact, register archetypes (Chatbot, Fraud Triage, Doc Q&A). The scripted scene numbers are UNCHANGED — new features are additive. One scene change: Scene 5's live SQL price change can now ALSO be done via the API with the admin key — sexier: `curl -X POST localhost:8000/admin/prices -H "X-API-Key: local-admin-key" -H "Content-Type: application/json" -d '{"component_code":"gpt4o","unit":"input_token","new_price":"5.00"}'` — and `GET /admin/log` shows the audit trail with your identity.
*(~20 min + Q&A. Every number below is exact — the engine is deterministic, so if you click what's written, you get what's written.)*

---

## 0. Pre-demo checklist (15 min before)

```bash
# 1. fresh, clean DB (removes yesterday's test estimates)
cd "/Users/madhurjyatamuly/AI calculator/db"
rm -f calculator.db
python3 -c "import sqlite3; c=sqlite3.connect('calculator.db'); c.executescript(open('schema.sql').read()); c.executescript(open('seed.sql').read()); c.commit()"

# 2. start the server (leave this terminal running, visible)
cd "/Users/madhurjyatamuly/AI calculator/api"
python3 -m uvicorn main:app --port 8000
```

- Browser tab 1: **http://localhost:8000** (the app)
- Browser tab 2: **http://localhost:8000/docs** (auto-generated API docs)
- VS Code open with: `engine/engine.py`, `engine/domain.py`, `engine/repository.py`, `api/main.py`
- A second terminal ready at `AI calculator/` for the live tests + SQL moment

---

## 1. The story (2 min, no screen needed)

> "Every AI proposal today comes with a cost guess made in a spreadsheet — different assumptions, different prices, not reproducible. This tool makes AI solution costing **deterministic, auditable, and reproducible**. You describe the solution — components plus usage numbers — and a pure calculation engine prices it from an approved catalogue. Same inputs, same answer, every time, and every estimate is frozen forever."

Then the **four design rules** (this is the architecture in four sentences):
1. **Prices are data, not code** — a price change is a database row, never a deployment.
2. **The engine is deterministic — no AI does arithmetic.** (AI advisor comes later; it will only *propose* components, and its proposals go through this same engine.)
3. **Estimates are immutable** — every estimate freezes the prices it used. A price change tomorrow cannot rewrite last month's business case.
4. **Money is Decimal, never float** — down to the wire format (JSON strings).

---

## 2. Live UI demo (6–8 min) — the exact click path

### Scene 1 — the catalogue is the approved register
Open http://localhost:8000. Point out:
- Every component shows its **live price** (pulled from dated price rows) — and these are **real Microsoft list prices, verified 2 July 2026**: the full current Azure OpenAI lineup, GPT-5.5 down to GPT-4o mini. Sources documented in `db/PRICING_SOURCES.md`.
- **"Unapproved Tool"** is struck through — *"this is the approved-technology register as data; watch what happens if I try to use it later."*
- Archetype "RAG Assistant" shows its **usage defaults** — *"if the user doesn't know their numbers yet, the archetype pre-fills them; anything they type wins."*

### Scene 2 — first estimate (defaults)
gpt4o + Embeddings + AI Search are pre-ticked. Leave usage blank. **Run Estimate.**

Result: **USD 10,876.80** · range **9,900.48 – 11,853.12**
- **Hover the GPT-4o input line** — a TRACE card appears: `10,000 req/mo × 3 calls × 1,500 tok/call × 12 mo = 540,000,000 tokens · ÷1M × $2.50 = $1,350.00`. Say: *"Every line shows its own derivation — hover any of them. This isn't a black box; it's a ledger that shows its working. Finance can audit every number."* (If asked about "3 calls": one user question fans out into multiple model calls inside the pipeline — query rewrite, generation, guardrails. The multiplier spreadsheets forget.)
- **App Service and SQL appeared without being ticked** — *"GPT-4o declares infrastructure dependencies; the engine expands them automatically, transitively, cycle-safely."*
- The **amber warning**: *"the engine says this looks too cheap for a RAG assistant (typical 50k–500k) — it warns, it doesn't block. It's right: we're missing the licence."*
- The **range**: *"usage-driven lines flex ±40%, fixed costs don't — we give a defensible range, not false precision."*

### Scene 3 — complete the solution
Tick **PEGA Licence**, set qty **2**. Run.

**Framing (important):** this is ONE worked example — a customer-service RAG assistant that plugs into a licensed business platform. The calculator is fully general: *"the engine doesn't know what a mortgage is — 'Mortgages' is an MI tag on a catalogue row, and 'PEGA' could be any licensed system in your estate. Tag components with whatever business areas finance reports on."* (Provable: `grep -ri mortgage engine/*.py` returns nothing.)

Say: *"The engine says something's missing — and it's right. In this example the solution plugs into a business platform, two licences. Watch what completing the picture does."*

Result: **USD 110,876.80** — warning gone. MI split: **AI 5,440.80 / Platform 5,436.00 / Mortgages 100,000.00** — *"the split labels are data, not code — every estimate reports cost by business area automatically."*
Bonus beat: hover the PEGA line — trace says **"one-off, not × horizon"** — *"the engine knows a licence isn't a monthly cost; recurring-vs-one-off is a classic spreadsheet error."*

### Scene 4 — what-if in seconds (the model swap)
Untick GPT-4o, tick **GPT-4o mini**. Run.

Result: **USD 108,592.60** — *"the AI inference line collapsed from 2,430 to 145.80 — 94% cheaper. This is the tool's day-one value: model choice becomes a costed decision, not a vibe."*

**Optional second beat — "newer isn't cheaper":** swap to **GPT-5.4** instead → **111,416.80** (more than GPT-4o), or **GPT-5.5** → **114,386.80**. Say: *"The newest models cost MORE than the legacy one here — output tokens went up. Without this tool, 'let's use the latest model' is an uncosted decision."* Budget options: 5.4 nano → **108,689.80**.

(Swap back to GPT-4o before the next scene.)

### Scene 5 — the killer: immutability, live
Copy the **estimate ID** from Scene 3's run. In the second terminal, change a price *in production, right now*:

```bash
cd "/Users/madhurjyatamuly/AI calculator/db"
sqlite3 calculator.db "UPDATE price SET effective_to=date('now') WHERE component_code='gpt4o' AND unit='input_token' AND effective_to IS NULL;
INSERT INTO price (component_code,unit,unit_price,currency,effective_from) VALUES ('gpt4o','input_token','5.00','USD',date('now'));"
```

> *"Microsoft just doubled GPT-4o input pricing. No deploy, no code change — I closed the old dated row and inserted a new one."*

- **Run** the same solution again → **112,226.80** (the input-token line doubled: 1,350 → 2,700).
- Paste the old estimate ID into **"Retrieve frozen estimate"** → **110,876.80, unchanged, old prices in every line.** 
- Say: *"The estimate you took to the investment committee cannot silently change under you. That's rule 3, and it's physically enforced — prices are copied into the estimate lines, never referenced."*

Restore afterwards (or during Q&A):
```bash
sqlite3 calculator.db "DELETE FROM price WHERE component_code='gpt4o' AND unit='input_token' AND unit_price='5.00';
UPDATE price SET effective_to=NULL WHERE component_code='gpt4o' AND unit='input_token';"
```

### Scene 6 — governance
Tick **Unapproved Tool**. Run.
→ **"REJECTED BY THE ENGINE — Component not approved or not found: rogue."** No number produced.
> *"An estimate built on unapproved tech is worthless, so the engine refuses to produce one. Governance is enforced at the calculation layer, not by a checkbox in a process doc."*

*(Optional 30s: tab 2, /docs — "the API documents itself; this is what the POC team integrates against.")*

### Scene 7 (optional, if time / if asked "what else?") — the epics sweep
All of these are LIVE and tested — pick per audience interest:
- **Solution name** (top of the sheet) + **volume modes**: switch "requests/month" to "requests/day" — 500/day → the engine sees 15,000/month. *"Volume the way the business states it; the engine still only ever sees raw monthly numbers."*
- **Token anatomy** (collapsible, under usage): break input into system prompt / history / RAG / tools / user message — *"the parts sum into the same token quantity; finance sees WHERE the tokens go."*
- **Observability coverage strip** (in results): all four struck-through red + *"understated by 5–15%"* warning → tick App Insights + Tracing → 50%, names the gaps.
- **Assumptions & confidence** (in results): every usage value tagged `supplied` / `archetype` / `default` — *"the estimate tells you which numbers a human should confirm before you trust it."*
- **Projection** (What-if tools): set Growth 5%/mo → 12 compounding bars. *"M1 to M12, compounded — a flat ×12 understates a growing service."*
- **Compare models** (What-if tools): tick candidates → sorted table, cheapest badged.
- **Ledger** (bottom): every estimate saved + named; **view** any → frozen record; **Load into builder** = duplicate; **CSV ↓** for finance; **record actuals** → variance vs frozen expected-to-date.
- **Admin price change via API** (in /docs): POST /admin/prices — closes the old dated row, inserts the new one. GET /admin/prices/{code} = the full audit history. *"RBAC wraps this next — that's why it's the next increment."*
- **The AI seam**: open `engine/advisor.py` — *"the advisor plugs in HERE. It proposes; the engine prices. It doesn't exist yet, deliberately — but the boundary does."*

---

## 3. Code walkthrough (6 min) — files in this order

### `engine/domain.py` — "the vocabulary" (1 min)
- Top docstring: frozen dataclasses, no prices in code, **Decimal never float**.
- `Price.covers()` (~line 62): *"a price is a dated fact — current price = the row whose date range covers the pricing date. Price history is never overwritten."*
- `UsageAssumptions` (~line 120): *"the user gives raw metered numbers — requests, tokens, calls. The engine never interprets free text."*
- The error types at the bottom (~line 213): *"rejection is a first-class concept."*

### `engine/engine.py` — "the product" (3 min — spend the time here)
- Top docstring: **five pure stages** — resolve → apply_prices → calculate → aggregate → sanity_check. *"Each stage is a pure function: data in, data out, no I/O, no state — which is why every one is unit-testable in isolation."*
- `resolve()` (~line 102): point at the approval check (~117) — *"unapproved dies here"* — and the token derivation (~127): *"requests × eligibility × calls × tokens × months — the engine derives billable quantities from raw usage."*
- `_expand_dependencies()` (~line 46): *"transitive, cycle-safe, de-duplicated — the App Service you saw appear comes from here."*
- `calculate()` (~line 213): *"strategy per pricing model — flat, per-unit, per-token, tiered. A brand-new pricing model is one new function here; a new price is just data."*
- `aggregate()` (~line 237): *"±40% band on usage-driven lines only — that's the range you saw; the MI split happens in the same pass."*
- `run_estimate()` (~line 284): *"the whole engine is these five lines chained."*
- If time: `compare_models()` (~line 382) — *"the model comparison is literally re-running the same pure engine with one component swapped — no new maths, so nothing new to get wrong."*

### `engine/repository.py` — "the freeze" (1 min)
- `save_estimate()` (~line 99): *"insert-only. The price is COPIED into each estimate line — `unit_price_used` — never referenced. That's why the frozen estimate survived the live price change you watched."*
- Top docstring: *"swap this one file for a SQLAlchemy version and we're on Azure SQL; the engine can't tell the difference."*

### `api/main.py` + `api/schemas.py` — "the boundary" (1 min)
- `schemas.py` `Money` type (~line 20): *"Decimal serializes to a JSON **string** — a float never touches money, even on the wire."*
- `main.py` exception handlers: *"engine rejections become clean 422s that name the component; the engine itself knows nothing about HTTP."*

### Finish with the tests, live (1 min — highest credibility-per-second)
```bash
cd "/Users/madhurjyatamuly/AI calculator/engine"
python3 run_tests.py       # 51 passed — engine maths, hand-calculated expectations
python3 run_db_tests.py    # 14 passed — incl. proof a DB price change can't alter a saved estimate
cd ../api && python3 run_api_tests.py   # 98 passed — HTTP boundary, all epics, immutability end-to-end
```
> *"**163 assertions**, every expected value calculated by hand before the code was written — the tests check the engine against arithmetic, not against itself."*
(Note: `run_db_tests.py` mutates the DB by design — re-run the rebuild command from §0 afterwards if you demo more.)

---

## 4. Roadmap slide-in-words (30 sec)
1. ✅ Deterministic engine + SQLite + API + UI (what you just saw)
2. Next: **RBAC** (Entra ID roles — needed before admins can change live prices via API)
3. Then: **Azure SQL** (repository swap only — schema written for it)
4. Later: **AI advisor** behind the existing port — it *proposes* approved components, a human signs off, and the proposal re-enters this same deterministic pipeline. Pending AI Council approval — and deliberately not blocking any of this.

---

## 5. Q&A — likely questions, honest answers

**"Why isn't AI doing the estimation?"** — Because finance can't audit a language model. AI will *propose* solutions later; this engine *prices* them. AI suggestions re-enter the same pipeline as human input. LLMs never do arithmetic here.

**"Where does ±40% come from?"** — A policy placeholder, deliberately data-not-code (`DEFAULT_BAND`, one constant). Who owns that number is an open design question we've logged — same for archetype defaults.

**"Are these real prices?"** — The Microsoft prices are **real list prices, verified 2 July 2026** (Azure OpenAI Global Standard, East US infra SKUs) — every price and its source is documented in `db/PRICING_SOURCES.md`, including the SKU assumptions (App Service P0v3 Linux, SQL GP 2-vCore, S1 Search) and the observability GB baselines. PEGA is an illustrative placeholder (vendor quote needed). NBS's approved register still replaces this catalogue wholesale — as data.

**"What happens when Azure changes prices?"** — What you watched me do live: close the old dated row, insert a new one. Historical estimates untouched, new estimates re-priced. No deployment.

**"Currency shows USD but warnings say £?"** — Known cosmetic inconsistency in the seed data (engine sanity messages are £, seed prices are USD). Currency handling per the NBS register is one of the logged open questions.

**"How does this differ from SEI / Copilot reporting?"** — SEI reports *actuals* of existing usage. This estimates *pre-build* — new solutions that don't exist yet. Complementary, not overlapping.

**"Multi-year? Growth?"** — Growth-based 12-month projection is already implemented and tested in the engine (`project_monthly`); exposing it in the UI is a next increment. Multi-year discounting is a logged open question.

**"Can I trust the maths?"** — 107 hand-calculated assertions, including one bug we caught and kept as a note in the README: dependencies weren't being multiplied by the time horizon — caught by a hand-calculated test, which is exactly why we test that way.

---

## 6. Traps — don't do these tomorrow
- **Don't** run `run_db_tests.py` and then demo estimates without rebuilding the DB (it changes the pega price by design).
- **Don't** promise the AI advisor — it's stubbed and gated on AI Council approval. Say "deliberately later."
- **Don't** call seed prices real. "Illustrative" every time.
- **Don't** resize/zoom the browser mid-demo; if the layout stacks, widen the window before you start.
- If a click misbehaves, **refresh** — the DB has everything; nothing is lost.
