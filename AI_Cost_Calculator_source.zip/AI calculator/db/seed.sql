-- ============================================================
-- Seed data — identical to the test catalogue in run_tests.py,
-- so a DB-loaded estimate must produce the SAME numbers.
-- ============================================================

-- pricing models
INSERT INTO pricing_model (code, type) VALUES
 ('flat','flat'),
 ('per_unit','per_unit'),
 ('per_token','per_token'),
 ('tiered_search','tiered');

-- tiers for the tiered model (0-100 @0.10, 100-1000 @0.08, 1000+ @0.06)
INSERT INTO pricing_tier (model_code, lower_bound, upper_bound, rate) VALUES
 ('tiered_search','0','100','0.10'),
 ('tiered_search','100','1000','0.08'),
 ('tiered_search','1000','Infinity','0.06');

-- components
-- (real Azure OpenAI model lineup verified 2026-07-02 — see db/PRICING_SOURCES.md)
-- layer: experience | orchestration | intelligence | data_platform (Epic 3b AC1)
INSERT INTO component (code,name,component_type,approved,pricing_model_code,default_unit,mi_tag,observability_category,layer,description) VALUES
 ('gpt55','Azure OpenAI GPT-5.5','llm_model',1,'per_token','input_token','AI',NULL,'intelligence','Flagship reasoning model; highest quality, highest cost'),
 ('gpt54','Azure OpenAI GPT-5.4','llm_model',1,'per_token','input_token','AI',NULL,'intelligence','Current mainstream model for production workloads'),
 ('gpt54mini','Azure OpenAI GPT-5.4 mini','llm_model',1,'per_token','input_token','AI',NULL,'intelligence','Cost-efficient tier of the 5.4 family'),
 ('gpt54nano','Azure OpenAI GPT-5.4 nano','llm_model',1,'per_token','input_token','AI',NULL,'intelligence','Cheapest current model; classification and routing'),
 ('gpt5','Azure OpenAI GPT-5 (legacy)','llm_model',1,'per_token','input_token','AI',NULL,'intelligence','Legacy tier; cheaper input than 4o'),
 ('gpt4o','Azure OpenAI GPT-4o','llm_model',1,'per_token','input_token','AI',NULL,'intelligence','Legacy multimodal model'),
 ('gpt4omini','Azure OpenAI GPT-4o mini','llm_model',1,'per_token','input_token','AI',NULL,'intelligence','Legacy budget model'),
 ('embed','Azure OpenAI Embeddings','embedding',1,'per_token','input_token','AI',NULL,'intelligence','text-embedding-3-small; vectorises text for search'),
 ('embedlarge','Azure OpenAI Embeddings 3-large','embedding',1,'per_token','input_token','AI',NULL,'intelligence','Higher-accuracy embeddings at 6.5x the price'),
 ('contentsafety','Azure AI Content Safety','infra',1,'per_unit','month','AI',NULL,'intelligence','Guardrails: harmful-content filtering for agent output'),
 ('aisearch','Azure AI Search (vector store)','vector_store',1,'per_unit','month','AI',NULL,'data_platform','Vector + keyword index backing RAG retrieval'),
 ('appsvc','Azure App Service','infra',1,'per_unit','month','Platform',NULL,'experience','Hosts the solution web app / API front end'),
 ('sql','Azure SQL Database','infra',1,'per_unit','month','Platform',NULL,'data_platform','Relational store for solution data'),
 ('pega','PEGA Licence','licence',1,'flat','licence','Mortgages',NULL,'experience','Business workflow platform licence (vendor quote)'),
 ('appinsights','Application Insights','observability',1,'per_unit','month','Platform','logging','data_platform','Azure-native: application logs'),
 ('tracing','Distributed Tracing','observability',1,'per_unit','month','Platform','tracing','data_platform','Azure-native: request tracing across services'),
 ('metrics','Metrics Dashboard','observability',1,'per_unit','month','Platform','metrics','data_platform','Azure-native: metrics and dashboards'),
 ('alerting','Alerting','observability',1,'per_unit','month','Platform','alerting','data_platform','Azure-native: alert rules and notifications'),
 ('datadog','Datadog (third-party SaaS)','observability',1,'per_unit','month','Platform','logging','data_platform','SaaS observability suite; logs shown here'),
 ('driftmon','ML Model Drift Monitor (AI-specific)','observability',1,'per_unit','month','AI','drift','intelligence','Watches model inputs/outputs for statistical drift'),
 ('rageval','RAG Evaluation Harness (AI-specific)','observability',1,'per_unit','month','AI','rag_eval','intelligence','Continuous groundedness/relevance scoring of RAG answers'),
 ('aigov','AI Governance & Audit (Purview)','observability',1,'per_unit','month','AI','governance','data_platform','Usage policies, lineage and audit for AI workloads'),
 -- classic ML stack
 ('aml_endpoint','Azure ML Managed Endpoint','infra',1,'per_unit','month','AI',NULL,'intelligence','Real-time model serving endpoint (DS3v2)'),
 ('aml_gpu','Azure ML GPU Training (A100)','infra',1,'per_unit','hour','AI',NULL,'intelligence','GPU compute for model training, billed hourly'),
 ('databricks','Azure Databricks Cluster','infra',1,'per_unit','month','AI',NULL,'data_platform','Spark cluster for feature engineering and training'),
 ('adls','Data Lake Storage (1TB)','infra',1,'per_unit','month','Platform',NULL,'data_platform','ADLS Gen2 storage for training and telemetry data'),
 ('adf','Azure Data Factory','infra',1,'per_unit','month','Platform',NULL,'orchestration','Data pipelines feeding the solution'),
 -- agentic AI stack
 ('functions','Azure Functions (tool execution)','infra',1,'per_unit','month','Platform',NULL,'orchestration','Runs the tools agents call'),
 ('cosmos','Cosmos DB (agent state)','infra',1,'per_unit','month','Platform',NULL,'data_platform','Low-latency store for agent memory/state'),
 ('apim','API Management Gateway','infra',1,'per_unit','month','Platform',NULL,'orchestration','Gateway, throttling and auth for solution APIs'),
 ('rogue','Unapproved Tool','infra',0,'flat','month',NULL,NULL,'data_platform','Deliberately unapproved test component'),
 -- ===== V2: classic ML lifecycle (sourced 2026-07-07, db/PRICING_SOURCES.md) =====
 ('feature_store','Feature Store (AML managed)','infra',1,'per_unit','month','AI',NULL,'data_platform','FREE — registry/metadata costs nothing; real costs are materialization compute + the Redis online store (auto-dependency). If using Databricks Feature Store it is already inside your DBUs.'),
 ('redis','Redis Cache (online feature serving)','infra',1,'per_unit','month','Platform',NULL,'data_platform','Standard tier — low-latency online feature serving'),
 ('mlflow_registry','Experiment Tracking & Model Registry','infra',1,'per_unit','month','AI',NULL,'intelligence','FREE — MLflow OSS / AML registry; artifacts ride on the Data Lake'),
 ('aml_batch','Batch Scoring Compute (D4s v5)','infra',1,'per_unit','hour','AI',NULL,'intelligence','CPU cluster hours for batch inference; qty = hours/month'),
 ('labeling','Data Labeling (workforce)','infra',1,'per_unit','month','AI',NULL,'data_platform','QUOTE REQUIRED — the AML labeling tool is free; the human workforce is a vendor/internal quote. Unpriced until an Admin enters the quoted rate; estimates including it are refused until then.'),
 ('purview','Data Quality & Governance (Purview)','infra',1,'per_unit','month','Platform',NULL,'data_platform','1 Capacity Unit; PLATFORM-WIDE governance — usually one per estate: consider marking SHARED'),
 ('mlops_cicd','MLOps CI/CD (DevOps parallel job)','infra',1,'per_unit','month','Platform',NULL,'orchestration','Retrain-test-deploy automation; one hosted parallel job'),
 ('aks_serving','AKS Serving Cluster (3x D4s v5)','infra',1,'per_unit','month','AI',NULL,'intelligence','High-throughput model serving alternative to the managed endpoint; control plane free'),
 ('acr','Container Registry (Basic)','infra',1,'per_unit','month','Platform',NULL,'data_platform','Model/container images'),
 -- ===== V2: agentic AI (multi-agent autonomous) =====
 ('orchestrator_aca','Agent Orchestrator Hosting (Container Apps)','infra',1,'per_unit','month','AI',NULL,'orchestration','Runs LangGraph/AutoGen/SK — the FRAMEWORKS ARE FREE OSS; this is the always-on 1 vCPU + 2 GiB compute they run on'),
 ('agent_runtime','Agent Runtime (Foundry Agent Service)','infra',1,'per_unit','month','AI',NULL,'intelligence','FREE — bills through the model tokens and tools it drives, which are already on this estimate'),
 ('servicebus','Agent Message Bus (Service Bus Std)','infra',1,'per_unit','month','Platform',NULL,'orchestration','Reliable agent-to-agent messaging; base incl. 12.5M ops'),
 ('durable_wf','Durable Workflow Engine (Functions)','infra',1,'per_unit','month','Platform',NULL,'orchestration','Long-running agent sagas; basis ~2M executions/month consumption'),
 ('agent_memory','Agent Memory (Cosmos vector, 2000 RU/s)','infra',1,'per_unit','month','Platform',NULL,'data_platform','Episodic + semantic long-term memory. NOTE: `cosmos` (agent state, 1000 RU/s) is the transactional store — do not double-count'),
 ('sandbox','Code Execution Sandbox (ACA Dynamic Sessions)','infra',1,'per_unit','hour','AI',NULL,'orchestration','Isolated code-interpreter sessions; qty = session-hours/month'),
 ('hitl_gate','Human-in-the-Loop Gate (Logic Apps)','infra',1,'per_unit','month','Platform',NULL,'experience','Approval checkpoints for autonomous actions; basis ~1,300 runs x 10 actions'),
 ('agent_eval','Agent Evaluation Harness','observability',1,'per_unit','month','AI','rag_eval','intelligence','FREE harness — evaluations are LLM calls, captured in calls/request; category counts toward eval coverage'),
 ('langsmith','Agent Semantic Tracing (LangSmith Plus)','observability',1,'per_unit','month','AI','tracing','data_platform','Commercial SaaS, per seat per month — qty = seats'),
 -- ===== V2: provisioned capacity (official retail-price meters) =====
 ('ptu_global','Provisioned Throughput (per PTU, Global)','infra',1,'per_unit','month','AI',NULL,'intelligence','REPLACES per-token billing for the deployed model — do not also tick that model with usage. Official meter $1.00/PTU-hr x 730h; Data Zone $1.10, Regional $2.00; reservations discount further; minimum PTUs vary by model — verify via the Azure PTU calculator.'),
 ('ptu_regional','Provisioned Throughput (per PTU, Regional)','infra',1,'per_unit','month','AI',NULL,'intelligence','REPLACES per-token billing for the deployed model. Official meter $2.00/PTU-hr x 730h; see ptu_global notes.');

-- ===== sizing: components priced per resource-unit; quantity == the SIZE =====
-- default_quantity pre-fills the documented SKU; the user edits it to their sizing.
-- (effective price at default = the old flat monthly, so nothing changes until sized)
UPDATE component SET default_quantity='20', sizing_unit='GB logs/month' WHERE code='appinsights';
UPDATE component SET default_quantity='10', sizing_unit='GB traces/month' WHERE code='tracing';
UPDATE component SET default_quantity='1',  sizing_unit='×1000 RU/s' WHERE code='cosmos';
UPDATE component SET default_quantity='2',  sizing_unit='×1000 RU/s' WHERE code='agent_memory';
UPDATE component SET default_quantity='1',  sizing_unit='TB' WHERE code='adls';
UPDATE component SET default_quantity='3',  sizing_unit='D4s v5 nodes' WHERE code='aks_serving';
UPDATE component SET default_quantity='2',  sizing_unit='GiB memory' WHERE code='orchestrator_aca';
-- already per-unit (hourly / count) — just label the size dimension
UPDATE component SET default_quantity='40',  sizing_unit='A100 GPU-hours/month' WHERE code='aml_gpu';
UPDATE component SET default_quantity='160', sizing_unit='cluster-hours/month' WHERE code='aml_batch';
UPDATE component SET default_quantity='100', sizing_unit='session-hours/month' WHERE code='sandbox';
UPDATE component SET sizing_unit='licences' WHERE code='pega';
UPDATE component SET sizing_unit='seats' WHERE code='langsmith';
-- descriptions that now name the editable unit
UPDATE component SET description='Container Apps hosting for LangGraph/AutoGen/SK (frameworks are free OSS). Priced $38.88/GiB-month with vCPU scaling at Azure''s 2 GiB:1 vCPU ratio — edit the GiB to your sizing.' WHERE code='orchestrator_aca';
UPDATE component SET description='Azure-native application logs. $2.30/GB ingested — edit the GB/month to your expected log volume.' WHERE code='appinsights';
UPDATE component SET description='Request tracing across services. $2.30/GB — edit the GB/month to your trace volume.' WHERE code='tracing';
UPDATE component SET description='Low-latency store for agent memory/state. $60 per 1000 RU/s-month — edit the throughput.' WHERE code='cosmos';
UPDATE component SET description='Vector-indexed long-term agent memory. $60 per 1000 RU/s-month — edit the throughput. (Cosmos state store `cosmos` is separate — do not double-count.)' WHERE code='agent_memory';
UPDATE component SET description='ADLS Gen2 hot storage. $21/TB-month — edit the TB.' WHERE code='adls';
UPDATE component SET description='High-throughput model serving. $140.16/node-month (D4s v5); control plane free — edit the node count.' WHERE code='aks_serving';

-- dated prices (token prices are per 1,000,000 tokens)
-- Verified against Microsoft/aggregator sources on 2026-07-02 (db/PRICING_SOURCES.md).
-- Price CHANGES are dated: the old row is closed at 2026-07-02, the new row starts
-- there. Estimates priced before 2026-07-02 still reproduce the old figures.
INSERT INTO price (component_code,unit,unit_price,currency,effective_from,effective_to) VALUES
 -- GPT-4o (Global Standard) — verified unchanged
 ('gpt4o','input_token','2.50','USD','2026-01-01',NULL),
 ('gpt4o','output_token','10.00','USD','2026-01-01',NULL),
 ('gpt4o','cached_input_token','1.25','USD','2026-01-01',NULL),
 -- GPT-4o mini — verified unchanged; cached price ADDED 2026-07-02 (was missing)
 ('gpt4omini','input_token','0.15','USD','2026-01-01',NULL),
 ('gpt4omini','output_token','0.60','USD','2026-01-01',NULL),
 ('gpt4omini','cached_input_token','0.075','USD','2026-07-02',NULL),
 -- GPT-5.5 (current flagship)
 ('gpt55','input_token','5.00','USD','2026-07-02',NULL),
 ('gpt55','cached_input_token','0.50','USD','2026-07-02',NULL),
 ('gpt55','output_token','30.00','USD','2026-07-02',NULL),
 -- GPT-5.4 (current mainstream)
 ('gpt54','input_token','2.50','USD','2026-07-02',NULL),
 ('gpt54','cached_input_token','0.25','USD','2026-07-02',NULL),
 ('gpt54','output_token','15.00','USD','2026-07-02',NULL),
 -- GPT-5.4 mini
 ('gpt54mini','input_token','0.75','USD','2026-07-02',NULL),
 ('gpt54mini','cached_input_token','0.075','USD','2026-07-02',NULL),
 ('gpt54mini','output_token','4.50','USD','2026-07-02',NULL),
 -- GPT-5.4 nano
 ('gpt54nano','input_token','0.20','USD','2026-07-02',NULL),
 ('gpt54nano','cached_input_token','0.02','USD','2026-07-02',NULL),
 ('gpt54nano','output_token','1.25','USD','2026-07-02',NULL),
 -- GPT-5 (legacy tier)
 ('gpt5','input_token','1.25','USD','2026-07-02',NULL),
 ('gpt5','cached_input_token','0.125','USD','2026-07-02',NULL),
 ('gpt5','output_token','10.00','USD','2026-07-02',NULL),
 -- embeddings: 3-small verified unchanged; 3-large added
 ('embed','input_token','0.02','USD','2026-01-01',NULL),
 ('embedlarge','input_token','0.13','USD','2026-07-02',NULL),
 -- Azure AI Search Standard S1 — verified unchanged ($250/mo)
 ('aisearch','month','250.00','USD','2026-01-01',NULL),
 -- App Service Premium P0v3 Linux — verified unchanged (~$73/mo post price cut)
 ('appsvc','month','73.00','USD','2026-01-01',NULL),
 ('appsvc','month','60.00','USD','2025-01-01','2026-01-01'),   -- closed-off old price (history kept)
 -- Azure SQL GP Gen5 2 vCore + 100GB: $0.504/hr*730 + storage ≈ $380 (was 400)
 ('sql','month','400.00','USD','2026-01-01','2026-07-02'),     -- closed 2026-07-02
 ('sql','month','380.00','USD','2026-07-02',NULL),
 -- PEGA: not a Microsoft product — illustrative placeholder, unchanged
 ('pega','licence','50000.00','USD','2026-01-01',NULL),
 -- Observability: Azure Monitor Analytics Logs $2.30/GB (see sources for GB basis)
 ('appinsights','month','50.00','USD','2026-01-01','2026-07-02'),  -- closed 2026-07-02
 ('appinsights','month','2.30','USD','2026-07-02',NULL),           -- $2.30/GB-month; default 20 GB
 ('tracing','month','30.00','USD','2026-01-01','2026-07-02'),      -- closed 2026-07-02
 ('tracing','month','2.30','USD','2026-07-02',NULL),               -- $2.30/GB-month; default 10 GB
 ('metrics','month','20.00','USD','2026-01-01',NULL),
 ('alerting','month','10.00','USD','2026-01-01',NULL),
 -- ML + agentic stack (documented approximations — db/PRICING_SOURCES.md)
 ('aml_endpoint','month','205.00','USD','2026-07-02',NULL),   -- DS3v2 x730h
 ('aml_gpu','hour','3.67','USD','2026-07-02',NULL),           -- NC A100 hourly
 ('databricks','month','600.00','USD','2026-07-02',NULL),     -- small premium cluster
 ('adls','month','21.00','USD','2026-07-02',NULL),            -- $21/TB-month; default 1 TB
 ('adf','month','100.00','USD','2026-07-02',NULL),            -- pipeline activity approx
 -- functions: V1 seeded 160; corrected to the sourced EP1 rate via a DATED row
 ('functions','month','160.00','USD','2026-07-02','2026-07-07'),
 ('functions','month','146.00','USD','2026-07-07',NULL),      -- EP1, sourced 2026-07-07
 ('cosmos','month','60.00','USD','2026-07-02',NULL),          -- $60 per 1000 RU/s-month; default 1
 ('apim','month','147.00','USD','2026-07-02',NULL),           -- Basic tier
 ('contentsafety','month','50.00','USD','2026-07-02',NULL),   -- volume approx
 -- observability: SaaS + AI-specific (approximations, documented)
 ('datadog','month','70.00','USD','2026-07-02',NULL),
 ('driftmon','month','40.00','USD','2026-07-02',NULL),
 ('rageval','month','60.00','USD','2026-07-02',NULL),
 ('aigov','month','85.00','USD','2026-07-02',NULL),
 -- ===== V2 prices (sourced 2026-07-07 — every basis in db/PRICING_SOURCES.md) =====
 ('feature_store','month','0.00','USD','2026-07-07',NULL),      -- free (Class B)
 ('redis','month','40.00','USD','2026-07-07',NULL),             -- Standard tier
 ('mlflow_registry','month','0.00','USD','2026-07-07',NULL),    -- free (Class B)
 ('aml_batch','hour','0.192','USD','2026-07-07',NULL),          -- D4s v5 PAYG
 -- labeling: NO price row on purpose (Class D, quote required)
 ('purview','month','300.00','USD','2026-07-07',NULL),          -- 1 CU x 0.411 x 730
 ('mlops_cicd','month','40.00','USD','2026-07-07',NULL),        -- DevOps parallel job
 ('aks_serving','month','140.16','USD','2026-07-07',NULL),      -- $140.16/node-month (D4s v5); default 3
 ('acr','month','5.08','USD','2026-07-07',NULL),                -- Basic 0.167/day
 ('orchestrator_aca','month','38.88','USD','2026-07-07',NULL),  -- $38.88/GiB-month (vCPU scales 2GiB:1vCPU); default 2
 ('agent_runtime','month','0.00','USD','2026-07-07',NULL),      -- free (bills via tokens)
 ('servicebus','month','10.00','USD','2026-07-07',NULL),        -- Standard base
 ('durable_wf','month','25.00','USD','2026-07-07',NULL),        -- ~2M executions basis
 ('agent_memory','month','60.00','USD','2026-07-07',NULL),      -- $60 per 1000 RU/s-month; default 2
 ('sandbox','hour','0.03','USD','2026-07-07',NULL),             -- ACA dynamic sessions
 ('hitl_gate','month','5.00','USD','2026-07-07',NULL),          -- Logic Apps basis
 ('agent_eval','month','0.00','USD','2026-07-07',NULL),         -- free (evals = LLM calls)
 ('langsmith','month','39.00','USD','2026-07-07',NULL),         -- Plus, per seat
 ('ptu_global','month','730.00','USD','2026-07-07',NULL),       -- $1.00/PTU-hr x 730 (official meter)
 ('ptu_regional','month','1460.00','USD','2026-07-07',NULL);    -- $2.00/PTU-hr x 730 (official meter)

-- dependencies (every LLM implies App Service + SQL)
INSERT INTO component_dependency (component_code,requires_code,ratio) VALUES
 ('gpt4o','appsvc','1'),
 ('gpt4o','sql','1'),
 ('gpt4omini','appsvc','1'),
 ('gpt4omini','sql','1'),
 ('gpt55','appsvc','1'),
 ('gpt55','sql','1'),
 ('gpt54','appsvc','1'),
 ('gpt54','sql','1'),
 ('gpt54mini','appsvc','1'),
 ('gpt54mini','sql','1'),
 ('gpt54nano','appsvc','1'),
 ('gpt54nano','sql','1'),
 ('gpt5','appsvc','1'),
 ('gpt5','sql','1'),
 -- ML: training + serving imply the data lake
 ('databricks','adls','1'),
 ('aml_endpoint','adls','1'),
 -- V2 dependency wiring
 ('feature_store','adls','1'),
 ('feature_store','redis','1'),
 ('mlflow_registry','adls','1'),
 ('agent_runtime','contentsafety','1');

-- archetypes (default_usage as JSON)
INSERT INTO archetype (code,name,low_range,high_range,default_usage) VALUES
 ('rag_assistant','RAG Assistant','50000','500000',
  '{"requests_per_month":10000,"input_tokens_per_request":1500,"output_tokens_per_request":300,"calls_per_request":3,"time_horizon_months":12}'),
 ('ml_solution','Classic ML Solution','20000','250000',
  '{"time_horizon_months":12}'),
 ('agentic_ai','Agentic AI Workflow','100000','1000000',
  '{"requests_per_month":5000,"input_tokens_per_request":2500,"output_tokens_per_request":800,"calls_per_request":10,"time_horizon_months":12}'),
 -- register templates (Epic 1a AC1)
 ('chatbot','Chatbot','30000','300000',
  '{"requests_per_month":20000,"input_tokens_per_request":800,"output_tokens_per_request":200,"calls_per_request":2,"time_horizon_months":12}'),
 ('fraud_triage','Fraud Triage','40000','400000',
  '{"requests_per_month":50000,"input_tokens_per_request":1200,"output_tokens_per_request":150,"calls_per_request":1,"eligibility_rate":0.2,"time_horizon_months":12}'),
 ('doc_qa','Doc Q&A','25000','250000',
  '{"requests_per_month":5000,"input_tokens_per_request":3000,"output_tokens_per_request":400,"calls_per_request":2,"time_horizon_months":12}'),
 ('tiny','Tiny Tool','100000','200000',NULL),
 ('none','none (blank canvas)','0','Infinity',NULL),
 -- ===== V2 archetypes (ADDITIVE — all V1 archetypes above unchanged) =====
 ('ml_batch','ML — Batch Scoring','15000','150000',
  '{"time_horizon_months":12}'),
 ('ml_realtime','ML — Real-time Inference','30000','300000',
  '{"time_horizon_months":12}'),
 ('multi_agent','Multi-Agent Workflow','200000','2000000',
  '{"requests_per_month":2000,"input_tokens_per_request":6000,"output_tokens_per_request":1200,"calls_per_request":25,"time_horizon_months":12}');

-- ===== V2: template bill-of-materials (UI pre-tick; engine never reads this) =====
-- multi_agent input tokens are a LOOP AVERAGE incl. context accumulation (declared assumption)
INSERT INTO archetype_component (archetype_code,component_code,quantity,shared) VALUES
 -- RAG assistant: the canonical trio (matches V1 default selection)
 ('rag_assistant','gpt4o','1',0),
 ('rag_assistant','embed','1',0),
 ('rag_assistant','aisearch','1',0),
 -- ML batch scoring
 ('ml_batch','databricks','1',0),
 ('ml_batch','adf','1',0),
 ('ml_batch','feature_store','1',0),
 ('ml_batch','mlflow_registry','1',0),
 ('ml_batch','aml_batch','160',0),          -- 160 cluster-hours/month
 ('ml_batch','mlops_cicd','1',0),
 ('ml_batch','purview','1',1),              -- platform-wide: pre-marked SHARED
 ('ml_batch','driftmon','1',0),
 -- ML real-time inference
 ('ml_realtime','aml_endpoint','1',0),
 ('ml_realtime','aml_gpu','40',0),          -- 40 training-hours/month
 ('ml_realtime','feature_store','1',0),
 ('ml_realtime','mlflow_registry','1',0),
 ('ml_realtime','acr','1',0),
 ('ml_realtime','mlops_cicd','1',0),
 ('ml_realtime','driftmon','1',0),
 ('ml_realtime','appinsights','1',0),
 -- doc Q&A + chatbot (register templates)
 ('doc_qa','gpt4o','1',0),
 ('doc_qa','embed','1',0),
 ('doc_qa','aisearch','1',0),
 ('chatbot','gpt4omini','1',0),
 ('chatbot','contentsafety','1',0),
 ('chatbot','appinsights','1',0),
 -- multi-agent workflow
 ('multi_agent','gpt54','1',0),
 ('multi_agent','orchestrator_aca','2',0),
 ('multi_agent','servicebus','1',0),
 ('multi_agent','agent_memory','2',0),
 ('multi_agent','durable_wf','1',0),
 ('multi_agent','sandbox','100',0),         -- 100 session-hours/month
 ('multi_agent','hitl_gate','1',0),
 ('multi_agent','agent_runtime','1',0),
 ('multi_agent','agent_eval','1',0),
 ('multi_agent','langsmith','3',0),         -- 3 seats
 ('multi_agent','apim','1',0);

-- application-layer RBAC (Epic 3a AC4 / Epic 7): local identity source;
-- production swaps this lookup for Entra ID claims — same role check.
INSERT INTO api_key (key,holder,role,active) VALUES
 ('local-admin-key','Local Admin','Admin',1),
 ('local-user-key','Local User','User',1);
