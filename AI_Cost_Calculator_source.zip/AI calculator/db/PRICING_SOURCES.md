# Catalogue Pricing — Sources & Assumptions
*Verified 2026-07-02. All USD. Token prices are per 1M tokens, Azure OpenAI Global Standard (pay-as-you-go) deployment. Region basis: East US. Prices entered as dated rows effective 2026-07-02 (changes) or carried over (verified unchanged).*

## Azure OpenAI models (per 1M tokens)

| Component | Input | Cached input | Output | Status |
|---|---|---|---|---|
| GPT-5.5 (flagship) | 5.00 | 0.50 | 30.00 | added |
| GPT-5.4 (mainstream) | 2.50 | 0.25 | 15.00 | added |
| GPT-5.4 mini | 0.75 | 0.075 | 4.50 | added |
| GPT-5.4 nano | 0.20 | 0.02 | 1.25 | added |
| GPT-5 (legacy) | 1.25 | 0.125 | 10.00 | added |
| GPT-4o (legacy) | 2.50 | 1.25 | 10.00 | verified unchanged |
| GPT-4o mini (legacy) | 0.15 | 0.075 | 0.60 | cached price added |
| text-embedding-3-small (`embed`) | 0.02 | — | — | verified unchanged |
| text-embedding-3-large (`embedlarge`) | 0.13 | — | — | added |

Sources: [Azure OpenAI pricing](https://azure.microsoft.com/en-us/pricing/details/azure-openai/) ·
[OpenAI API pricing](https://developers.openai.com/api/docs/pricing) ·
[DevTk OpenAI pricing guide (June 2026)](https://devtk.ai/en/blog/openai-api-pricing-guide-2026/) ·
[CloudZero Azure OpenAI pricing (May 2026)](https://www.cloudzero.com/blog/azure-openai-pricing/) ·
[Helicone Azure embedding calculators](https://www.helicone.ai/llm-cost/provider/azure/model/text-embedding-3-large) ·
[PricePerToken Azure endpoints](https://pricepertoken.com/endpoints/azure)

## Infrastructure (monthly, East US)

| Component | Price/mo | SKU basis | Status |
|---|---|---|---|
| Azure AI Search | 250.00 | Standard S1, 1 search unit | verified unchanged |
| Azure App Service | 73.00 | Premium P0v3 Linux (post price-reduction) | verified unchanged |
| Azure SQL Database | 380.00 | GP Gen5 2 vCore ($0.504/hr × 730 ≈ $368) + ~100GB storage ($0.115/GB) | **updated from 400** |

Sources: [Azure AI Search pricing](https://azure.microsoft.com/en-us/pricing/details/search/) ·
[App Service Linux pricing](https://azure.microsoft.com/en-us/pricing/details/app-service/linux/) ·
[P0v3 price-reduction announcement](https://techcommunity.microsoft.com/blog/appsonazureblog/announcing-lower-pricing-for-azure-app-service-premium-p0v3-to-help-build-and-mo/4207811) ·
[Azure SQL single database pricing](https://azure.microsoft.com/en-us/pricing/details/azure-sql-database/single/) ·
[nOps Azure SQL pricing guide](https://www.nops.io/blog/azure-sql-database-pricing/)

## Observability (monthly approximations from metered rates)

Azure Monitor Analytics Logs ingestion: **$2.30/GB** (first 5 GB/mo free; workspace-based App Insights bills through Log Analytics).

| Component | Price/mo | Basis | Status |
|---|---|---|---|
| Application Insights (logging) | 46.00 | 20 GB/mo × $2.30 | **updated from 50** |
| Distributed Tracing | 23.00 | 10 GB/mo × $2.30 | **updated from 30** |
| Metrics Dashboard | 20.00 | custom metrics + dashboard approximation | kept |
| Alerting | 10.00 | ~10 metric + a few log alert rules | kept |
| Datadog (SaaS) | 70.00 | small-host SaaS plan approximation | added 2026-07-02 |
| ML Model Drift Monitor (AI) | 40.00 | Azure ML model monitoring approximation | added |
| RAG Evaluation Harness (AI) | 60.00 | continuous eval-run compute approximation | added |
| AI Governance / Purview | 85.00 | governance tooling approximation | added |

Source: [Azure Monitor pricing](https://azure.microsoft.com/en-us/pricing/details/monitor/) ·
[Azure Monitor logs cost docs](https://learn.microsoft.com/en-us/azure/azure-monitor/logs/cost-logs)

## ML + Agentic stack (added 2026-07-02, monthly approximations — East US)

| Component | Price | SKU basis |
|---|---|---|
| Azure ML Managed Endpoint | 205.00/mo | DS3 v2 × 730h |
| Azure ML GPU Training | 3.67/hour | NC-series A100 |
| Azure Databricks Cluster | 600.00/mo | small Premium-tier cluster incl. DBUs |
| Data Lake Storage (1TB) | 21.00/mo | ADLS Gen2 hot LRS |
| Azure Data Factory | 100.00/mo | pipeline-activity approximation |
| Azure Functions (tools) | 160.00/mo | Premium EP1 |
| Cosmos DB (agent state) | 60.00/mo | 1000 RU/s provisioned |
| API Management Gateway | 147.00/mo | Basic tier |
| Azure AI Content Safety | 50.00/mo | volume approximation |

These are list-price approximations at a stated SKU — tune per solution when
real sizing is known. Sources: [Azure ML pricing](https://azure.microsoft.com/en-us/pricing/details/machine-learning/) ·
[Databricks pricing](https://azure.microsoft.com/en-us/pricing/details/databricks/) ·
[Functions pricing](https://azure.microsoft.com/en-us/pricing/details/functions/) ·
[Cosmos DB pricing](https://azure.microsoft.com/en-us/pricing/details/cosmos-db/) ·
[APIM pricing](https://azure.microsoft.com/en-us/pricing/details/api-management/) ·
[Content Safety pricing](https://azure.microsoft.com/en-us/pricing/details/cognitive-services/content-safety/)

## V2 components (sourced 2026-07-07)

| Component | Class | Price | Basis + source |
|---|---|---|---|
| Feature Store (AML managed) | B free | 0.00 | registry free; costs = materialization + Redis dep ([MS Learn](https://learn.microsoft.com/en-us/azure/machine-learning/concept-what-is-managed-feature-store?view=azureml-api-2)) |
| Redis Cache | A | 40.00/mo | Standard tier |
| Experiment Tracking/Registry | B free | 0.00 | MLflow OSS / AML registry free |
| Batch Scoring Compute | A | 0.192/hr | D4s v5 PAYG East US ([CloudPrice](https://cloudprice.net/vm/Standard_D4s_v5)) |
| Data Labeling (workforce) | **D quote** | *unpriced* | tool free; workforce quoted — engine refuses until priced |
| Purview (governance) | A | 300.00/mo | 1 CU × $0.411/hr × 730 ([Purview pricing](https://azure.microsoft.com/en-us/pricing/details/purview/)) — recommend SHARED |
| MLOps CI/CD | A | 40.00/mo | DevOps hosted parallel job ([DevOps pricing](https://azure.microsoft.com/en-us/pricing/details/devops/azure-devops-services/)) |
| AKS Serving | A | 420.48/mo | 3× D4s v5 × 730h; control plane free ([AKS pricing](https://azure.microsoft.com/en-us/pricing/details/kubernetes-service/)) |
| Container Registry | A | 5.08/mo | Basic $0.167/day ([ACR pricing](https://azure.microsoft.com/en-us/pricing/details/container-registry/)) |
| Agent Orchestrator Hosting | A | 77.76/mo | ACA 1 vCPU+2 GiB always-on: $0.000024/vCPU-s + $0.000003/GiB-s ([ACA billing](https://learn.microsoft.com/en-us/azure/container-apps/billing)); LangGraph/AutoGen = free OSS |
| Agent Runtime (Foundry) | B free | 0.00 | bills via tokens/tools already on the estimate |
| Service Bus Standard | A | 10.00/mo | base incl. 12.5M ops ([Service Bus pricing](https://azure.microsoft.com/en-us/pricing/details/service-bus/)) |
| Durable Workflow (Functions) | A | 25.00/mo | ~2M executions basis ([Functions pricing](https://azure.microsoft.com/en-us/pricing/details/functions/)) |
| Agent Memory (Cosmos 2000 RU/s) | A | 120.00/mo | 2× the sourced 1000-RU/s basis |
| Code Sandbox (ACA Dynamic Sessions) | A | 0.03/hr | per session-hour ([announcement](https://techcommunity.microsoft.com/blog/appsonazureblog/new-secure-sandboxes-at-scale-with-azure-container-apps-dynamic-sessions/4142148)) |
| HITL Gate (Logic Apps) | A | 5.00/mo | ~1,300 runs × 10 std actions × $0.000125 ([Logic Apps pricing](https://learn.microsoft.com/en-us/azure/logic-apps/logic-apps-pricing)) |
| Agent Eval Harness | B free | 0.00 | evals are LLM calls — in calls/request |
| LangSmith Plus | C | 39.00/seat/mo | published SaaS ([LangSmith pricing](https://www.langchain.com/pricing)) |
| PTU Global / Regional | A | 730.00 / 1,460.00 per PTU-mo | **official Azure Retail Prices API meters**: Global $1.00/PTU-hr, Data Zone $1.10, Regional $2.00 (`prices.azure.com/api/retail/prices`, eastus, 2026-07-07); reservations discount further |

**V1 correction via dated row:** Azure Functions 160.00 → **146.00** (sourced EP1) effective 2026-07-07; old row closed, history kept.

## Not Microsoft
- **PEGA Licence (50,000/licence)** — illustrative placeholder; vendor quote required.
- **Unapproved Tool** — deliberately unapproved test component, no price.

## Editable sizing (2026-07-09)
Sizing-assumption components are now priced **per resource-unit**, with the size an
**editable quantity** (green box + `✎` unit label in the UI) defaulting to the documented SKU.
Change the size and the cost updates linearly — the assumption is on screen, not hidden.

| Component | Per-unit price | Default size | Sizing unit |
|---|---|---|---|
| Agent Orchestrator Hosting | $38.88 | 2 | GiB memory (vCPU scales 2 GiB:1 vCPU) |
| Application Insights | $2.30 | 20 | GB logs/month |
| Distributed Tracing | $2.30 | 10 | GB traces/month |
| Cosmos DB (state) | $60.00 | 1 | ×1000 RU/s |
| Agent Memory (Cosmos vector) | $60.00 | 2 | ×1000 RU/s |
| Data Lake Storage | $21.00 | 1 | TB |
| AKS Serving | $140.16 | 3 | D4s v5 nodes |
| ML GPU Training | $3.67 | 40 | A100 GPU-hours/month |
| Batch Scoring Compute | $0.192 | 160 | cluster-hours/month |
| Code Sandbox | $0.03 | 100 | session-hours/month |

Effective cost at the default size equals the previous flat monthly, so historical
figures are unchanged until a user resizes. Components with coupled dependencies
(orchestrator's Service Bus + memory) had those moved into the template so resizing
the host does not multiply the dependencies.

## Notes
- GB/month observability volumes are stated assumptions — tune per solution when NBS provides real telemetry baselines.
- Price changes were applied as **dated rows** (old row closed at 2026-07-02, new row effective 2026-07-02). Estimates priced before that date still reproduce the old figures — by design.
