-- ============================================================
-- AI Cost Calculator - Phase 1 schema (SQLite)
-- Matches the ERD: PRICING_MODEL, COMPONENT, PRICE (dated),
-- COMPONENT_DEPENDENCY, ARCHETYPE, plus the estimate side
-- (SOLUTION, LINE_ITEM, ESTIMATE, ESTIMATE_LINE).
-- Portable to Azure SQL: types are deliberately conservative.
-- ============================================================

PRAGMA foreign_keys = ON;

-- ---------- catalogue side (the "live" world) ----------

CREATE TABLE pricing_model (
    code        TEXT PRIMARY KEY,
    type        TEXT NOT NULL CHECK (type IN ('flat','per_unit','per_token','tiered')),
    notes       TEXT
);

-- tiers for tiered models (one row per band)
CREATE TABLE pricing_tier (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    model_code  TEXT NOT NULL REFERENCES pricing_model(code),
    lower_bound TEXT NOT NULL,     -- Decimal as TEXT to avoid float drift
    upper_bound TEXT NOT NULL,     -- 'Infinity' for the top band
    rate        TEXT NOT NULL
);

CREATE TABLE component (
    code                    TEXT PRIMARY KEY,
    name                    TEXT NOT NULL,
    component_type          TEXT NOT NULL CHECK (component_type IN
        ('llm_model','embedding','infra','licence','vector_store','observability')),
    approved                INTEGER NOT NULL DEFAULT 0,   -- 0/1 boolean
    pricing_model_code      TEXT NOT NULL REFERENCES pricing_model(code),
    default_unit            TEXT NOT NULL,
    mi_tag                  TEXT,
    observability_category  TEXT,     -- logs|metrics|traces|alerting|drift|rag_eval|governance
    cloud                   TEXT NOT NULL DEFAULT 'azure'
        CHECK (cloud IN ('azure','aws','gcp')),           -- AWS/GCP: future (Epic 4 AC1)
    layer                   TEXT NOT NULL DEFAULT 'data_platform'
        CHECK (layer IN ('experience','orchestration','intelligence','data_platform')),
    description             TEXT,                         -- Epic 3b AC3
    archived                INTEGER NOT NULL DEFAULT 0,   -- Epic 7 AC3: archive/restore
    -- sizing: for components priced per resource-unit (memory, throughput, GB,
    -- nodes, hours), quantity == the SIZE. default_quantity pre-fills the
    -- documented SKU; sizing_unit labels what a unit of quantity means.
    default_quantity        TEXT NOT NULL DEFAULT '1',
    sizing_unit             TEXT                          -- e.g. 'GiB memory', '×1000 RU/s'
);

-- dated prices: current = the row whose [effective_from, effective_to) covers the date.
-- a price change INSERTS a new row and closes the old one; nothing is overwritten.
CREATE TABLE price (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    component_code  TEXT NOT NULL REFERENCES component(code),
    unit            TEXT NOT NULL,           -- input_token|output_token|cached_input_token|month|licence|GB...
    unit_price      TEXT NOT NULL,           -- Decimal as TEXT
    currency        TEXT NOT NULL DEFAULT 'USD',
    effective_from  TEXT NOT NULL,           -- ISO date
    effective_to    TEXT,                    -- NULL = open-ended (current)
    changed_by      TEXT                     -- Epic 3a AC3: editor identity (NULL = seed)
);
CREATE INDEX idx_price_lookup ON price(component_code, unit, effective_from);

CREATE TABLE component_dependency (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    component_code  TEXT NOT NULL REFERENCES component(code),
    requires_code   TEXT NOT NULL REFERENCES component(code),
    ratio           TEXT NOT NULL DEFAULT '1'
);
CREATE INDEX idx_dep_component ON component_dependency(component_code);

CREATE TABLE archetype (
    code            TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    low_range       TEXT NOT NULL,
    high_range      TEXT NOT NULL,
    default_usage   TEXT               -- JSON blob (avoids schema churn while it settles)
);

-- V2: template bill-of-materials — an archetype can pre-select components.
-- Purely presentational data: the UI pre-ticks these; the user adjusts freely;
-- the engine never reads this table.
CREATE TABLE archetype_component (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    archetype_code  TEXT NOT NULL REFERENCES archetype(code),
    component_code  TEXT NOT NULL REFERENCES component(code),
    quantity        TEXT NOT NULL DEFAULT '1',
    shared          INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_bom_archetype ON archetype_component(archetype_code);

-- ---------- estimate side (the "frozen" world) ----------

CREATE TABLE solution (
    id               TEXT PRIMARY KEY,          -- uuid
    name             TEXT,                      -- free-text solution name (Epic 1a)
    description      TEXT,                      -- free-text description (Epic 1a)
    archetype_code   TEXT REFERENCES archetype(code),
    usage_assumptions TEXT,                     -- JSON snapshot of what was used
    business_area    TEXT,
    version          INTEGER NOT NULL DEFAULT 1,
    created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);

-- the components the user chose (enables duplicate / re-load, Epic 6)
-- shared=1: the component already runs elsewhere — listed but NOT attributed
CREATE TABLE solution_component (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    solution_id     TEXT NOT NULL REFERENCES solution(id),
    component_code  TEXT NOT NULL,
    quantity        TEXT NOT NULL DEFAULT '1',
    shared          INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_solcomp_solution ON solution_component(solution_id);

CREATE TABLE estimate (
    id              TEXT PRIMARY KEY,           -- uuid
    solution_id     TEXT NOT NULL REFERENCES solution(id),
    total_low       TEXT NOT NULL,
    total_expected  TEXT NOT NULL,
    total_high      TEXT NOT NULL,
    priced_on       TEXT NOT NULL,              -- the date whose prices were used
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    created_by      TEXT,
    assumptions_json TEXT                       -- Epic 9 AC5: frozen assumption statuses
);

-- ---------- access + audit (Epic 3a AC4 / Epic 7) ----------
-- Application-layer RBAC with a pluggable identity source. Locally: API keys.
-- In production the same role check reads Entra ID claims — a config swap.
CREATE TABLE api_key (
    key         TEXT PRIMARY KEY,
    holder      TEXT NOT NULL,
    role        TEXT NOT NULL CHECK (role IN ('User','Admin')),
    active      INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE admin_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    actor       TEXT NOT NULL,                  -- key holder name
    action      TEXT NOT NULL,                  -- price_change|component_add|archive|restore
    target      TEXT NOT NULL,
    detail      TEXT,
    at          TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ---------- Phase 2: advisor sessions + sign-off audit ----------
-- A session is the clarifying-question loop; the proposal is frozen into it.
CREATE TABLE advisor_session (
    id          TEXT PRIMARY KEY,               -- uuid
    messages    TEXT NOT NULL,                  -- JSON transcript (user/assistant)
    status      TEXT NOT NULL DEFAULT 'open'    -- open|proposed|refused|signed_off
        CHECK (status IN ('open','proposed','refused','signed_off')),
    proposal    TEXT,                           -- JSON of the validated proposal
    created_by  TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- the human decision, per component — the audit trail the design demands
CREATE TABLE advisor_signoff (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id     TEXT NOT NULL REFERENCES advisor_session(id),
    component_code TEXT NOT NULL,
    accepted       INTEGER NOT NULL,            -- 1 accepted / 0 rejected
    decided_by     TEXT,
    at             TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_signoff_session ON advisor_signoff(session_id);

-- ---------- drafts (Epic 6 AC1: save at ANY stage, before pricing) ----------
-- A draft is builder STATE, not an estimate — immutability of estimates holds.
CREATE TABLE draft (
    id          TEXT PRIMARY KEY,               -- uuid
    name        TEXT,
    payload     TEXT NOT NULL,                  -- the request JSON as typed so far
    created_by  TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- frozen lines: prices are COPIED in, never referenced — immutability by design
CREATE TABLE estimate_line (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    estimate_id      TEXT NOT NULL REFERENCES estimate(id),
    component_name   TEXT NOT NULL,
    unit             TEXT NOT NULL,
    quantity         TEXT NOT NULL,
    unit_price_used  TEXT NOT NULL,             -- the frozen price
    line_total       TEXT NOT NULL,
    mi_tag           TEXT,
    shared           INTEGER NOT NULL DEFAULT 0 -- 1 = shown, NOT in the totals
);
CREATE INDEX idx_line_estimate ON estimate_line(estimate_id);

-- actuals recorded against a FROZEN estimate (Epic 8). Deliberately separate
-- from the costing engine: actuals compare against the estimate, never change it.
CREATE TABLE estimate_actual (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    estimate_id  TEXT NOT NULL REFERENCES estimate(id),
    period       TEXT NOT NULL,                 -- e.g. '2026-07' (month)
    amount       TEXT NOT NULL,                 -- Decimal as TEXT
    recorded_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_actual_estimate ON estimate_actual(estimate_id);
