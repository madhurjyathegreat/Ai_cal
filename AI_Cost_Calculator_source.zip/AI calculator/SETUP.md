# AI Cost Calculator ("Estimation Ledger") — setup guide

A deterministic costing engine for AI solutions with a FastAPI backend, a
single-file web frontend, and an optional multi-agent AI advisor (OpenAI).
Prices are data, estimates are immutable, and the LLM never does arithmetic.

## What's in the box

```
engine/     the pure costing engine (no I/O, Decimal money) + its test suites
api/        FastAPI app (main.py, service.py, schemas.py) + static/ frontend
            static/site.html   -> landing page        (served at /v3)
            static/about.html  -> product story       (served at /v3/about)
            static/v3.html     -> the app             (served at /v3/app)
            static/index.html  -> legacy V2 UI        (served at /)
db/         schema.sql + seed.sql (51 components, real Microsoft list prices,
            sources in PRICING_SOURCES.md). calculator.db is BUILT, not shipped.
diagrams/   LLD / ERD / sequence diagrams
Dockerfile, start.sh   container build for Cloud Run (or any container host)
```

## Prerequisites

- Python 3.12+ (3.10 works)
- pip
- (optional) an OpenAI API key — only needed for the AI advisor features;
  everything else runs without it

## Local setup — 4 steps

```bash
# 1) install the only runtime dependencies
pip install fastapi uvicorn pypdf python-multipart

# 2) build the seeded database (from the project root)
python3 -c "
import sqlite3
c = sqlite3.connect('db/calculator.db')
c.executescript(open('db/schema.sql').read())
c.executescript(open('db/seed.sql').read())
c.commit()
print('db built')"

# 3) (optional) enable the AI advisor — pick ONE:
echo 'sk-your-openai-key' > .openai_key          # git-ignored file, or
export OPENAI_API_KEY=sk-your-openai-key          # environment variable

# 4) run
cd api && python3 -m uvicorn main:app --port 8000
```

Open:

- http://localhost:8000/v3        — landing page
- http://localhost:8000/v3/app    — the application
- http://localhost:8000/docs      — OpenAPI docs

Sign in with the local seed keys: `local-admin-key` (Admin) or
`local-user-key` (User). In production these are replaced at boot (see
Deployment) and the identity layer is designed to swap to Microsoft Entra ID.

## Running the tests

```bash
python3 engine/run_tests.py      # 64 hand-calculated engine assertions
python3 api/run_api_tests.py     # 238 API tests (advisor LLM is mocked — no key needed)
```

Note: `engine/run_db_tests.py` mutates `db/calculator.db`; rebuild it with
step 2 afterwards.

## What needs the OpenAI key (and what doesn't)

| Works with no key | Needs the key |
|---|---|
| Estimates, catalogue, ledger, admin console | AI advisor chat |
| All diagrams and projections | Document (BRD/FRD/deck) upload → brief |
| Usage-field assistants via chips (deterministic dictionary) | Usage-field assistants via free text / document mining |

If the key is missing, AI endpoints return a clear 503 — nothing else breaks.

## Deployment (Cloud Run, or any container host)

The Dockerfile builds a self-contained image; `start.sh` rebuilds the seeded
database at boot (the container filesystem is ephemeral — saved estimates do
not survive an instance recycle; the production path is pointing the
repository layer at Azure SQL).

```bash
gcloud run deploy ai-cost-calculator \
  --source . --region <region> --allow-unauthenticated \
  --set-env-vars "ADMIN_API_KEY=<strong-admin-key>,USER_API_KEY=<strong-user-key>,OPENAI_API_KEY=<openai-key>"
```

`start.sh` replaces the publicly-known local seed keys with ADMIN_API_KEY /
USER_API_KEY at boot, so the demo keys never work on a public URL. The
frontend hides its local-demo hints automatically when not on localhost.

## Security notes for whoever operates this

- NEVER commit `.openai_key` or any `.admin_key*` / `.user_key*` files
  (`.gitignore` / `.gcloudignore` already exclude them).
- The OpenAI key on a public deployment makes the advisor publicly usable —
  treat the URL as semi-private and rotate the key if it leaks.
- RBAC is app-layer (X-API-Key header → role). The `require_admin` dependency
  is the single place to swap in Entra ID token validation for production.

## Design rules the codebase enforces (don't break these)

1. Prices are data — a price change is a dated row insert, never a deploy.
2. The engine is pure: no I/O inside `engine/`; adapters live in `api/`.
3. Money is `Decimal`, never float, end to end.
4. Estimates are immutable — stored with the prices they used.
5. The LLM never does arithmetic: advisor proposals and the usage-field
   assistants only name catalogue codes / dictionary shapes; deterministic
   server code converts, clamps, and prices. Guardrails in
   `api/service.py::_ground_proposal` and `::_assist_resolve` enforce this.
