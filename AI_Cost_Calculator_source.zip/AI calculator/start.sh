#!/bin/sh
# Build a fresh seeded DB at boot (Cloud Run filesystem is EPHEMERAL —
# estimates saved on the public URL do not survive instance recycling).
python - <<'EOF'
import os, sqlite3, secrets
db = '/app/db/calculator.db'
conn = sqlite3.connect(db)
conn.executescript(open('/app/db/schema.sql').read())
conn.executescript(open('/app/db/seed.sql').read())
admin = os.environ.get('ADMIN_API_KEY')
user = os.environ.get('USER_API_KEY')
if admin:
    # never ship the publicly-known seed keys on a public URL
    conn.execute("UPDATE api_key SET key=? WHERE role='Admin'", (admin,))
    # user key: use the provided one (so a demo user can sign in), else random
    conn.execute("UPDATE api_key SET key=? WHERE role='User'",
                 (user or secrets.token_hex(16),))
conn.commit()
EOF
cd /app/api && exec uvicorn main:app --host 0.0.0.0 --port ${PORT:-8080}
