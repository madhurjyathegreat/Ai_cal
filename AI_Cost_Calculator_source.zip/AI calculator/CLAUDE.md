# AI Cost Calculator — Project Context

## What this is
A cost calculator for AI solutions, built for Nationwide Building Society (NBS).
It takes a proposed AI solution (components + usage numbers), computes its full
cost of ownership deterministically, and compares options. An AI advisor
(suggesting approved components) comes in a LATER phase — it is deliberately
stubbed. Accenture architects this; an NBS POC team builds/deploys it.

## Non-negotiable design rules (do not violate these)
1. **Prices are DATA, not code.** The engine holds no prices; they live in the
   database (dated PRICE rows). A price change is a data update, never a deploy.
2. **The engine is deterministic. The LLM never does arithmetic.** AI (later)
   only PROPOSES components; the engine decides cost. AI suggestions re-enter
   the same pipeline as user input.
3. **Estimates are immutable and reproducible.** Every estimate freezes the
   prices + date used (copied into ESTIMATE_LINE, never referenced live).
4. **Money is Decimal, never float.**
5. **The engine is pure — no I/O inside it.** Data is loaded by a repository
   into a CatalogueView snapshot and handed in. All I/O lives in adapters.
6. **Unapproved components are hard-rejected** (UnapprovedComponentError).
7. **Output is a low/expected/high RANGE** (usage-driven lines flex ±40%),
   split by business area via MI tags — never a false-precision single number.

## Current state (all working, all tested)
- `engine/` — the five-stage deterministic engine:
  resolve → apply_prices → calculate → aggregate → sanity_check
  - resolve: validates approval; expands dependencies (transitive, cycle-safe,
    de-duplicated); derives AI token quantities from raw usage; archetype
    defaults pre-fill omitted usage (user values win).
  - calculate: strategy per pricing model — flat / per_unit / per_token / tiered.
  - Epic features implemented: token anatomy (6 prompt parts), cached vs
    uncached input tokens, eligibility rate, growth-based 12-month projection
    (project_monthly/project_total), multi-model comparison (compare_models),
    observability as priced components + coverage matrix (observability_coverage).
- `db/` — SQLite: schema.sql (ERD + solution_component + estimate_actual),
  seed.sql (REAL Microsoft prices verified 2026-07-02 — sources in
  db/PRICING_SOURCES.md; changes applied as dated rows), calculator.db (seeded).
  repository.py loads a CatalogueView from the DB (engine unchanged) and
  saves/reads immutable estimates (+list, +actuals).
- `engine/advisor.py` — AdvisorPort Protocol + NoOpAdvisor: the DELIBERATE stub
  boundary for the Post-MVP AI advisor (proposes only; engine prices).
- `api/` — FastAPI layer + static ledger UI at `/`:
  POST/GET /estimates (+list), /estimates/projection, /estimates/compare,
  /estimates/{id}/actuals, /estimates/{id}/export (CSV),
  POST /admin/prices + GET /admin/prices/{code} (dated price change as data),
  GET /catalogue. Response includes per-line derivation traces, observability
  coverage (Epic 2 AC4-6), assumption sources + confidence (Epic 9).
  Volume modes per_day/per_user/per_event adapt to requests_per_month in the
  SERVICE (engine untouched, Epic 1a). Money = JSON strings, never floats.
- Tests: `engine/run_tests.py` (51) + `engine/run_db_tests.py` (14, mutates the
  real DB by design — rebuild after) + `api/run_api_tests.py` (98, throwaway DB).
  **163/163 pass.** Run all three after ANY change.
- Epics register status: all engine+exposure epics closed; remaining honest gaps
  are RBAC (Epic 7, next increment), full assumption status workflow (Epic 9
  has sources+confidence only), Cost Atlas (Epic 10, Post-MVP), AI advisor
  implementation (Epic 11, stubbed behind AdvisorPort).

## How to run
```
cd engine
python run_tests.py        # engine logic (in-memory seed)
# rebuild the DB if needed:
python -c "import sqlite3; c=sqlite3.connect('../db/calculator.db'); c.executescript(open('../db/schema.sql').read()); c.executescript(open('../db/seed.sql').read()); c.commit()"
python run_db_tests.py     # DB-backed tests (expects ../db/calculator.db or copy it local)
```
Note: run_db_tests.py opens 'calculator.db' relative to CWD — keep the db file
next to where you run it, or update the path.

## Working style (carry this over)
- Build ONE feature at a time: extend → write a hand-calculated test → run →
  green → next. Never batch untested changes.
- Pre-mortem before building anything structural; fix logic when tests fail
  rather than adjusting tests to pass.
- Seed data is TEST data — NBS's approved-technology register replaces it.
  The catalogue contents are illustrative; the engine mechanics are the product.

## Target stack / next steps (in order)
1. **FastAPI layer** — routers (/estimates, /catalogue, /admin), Pydantic v2
   DTOs, EstimateService + Unit of Work per the LLD (docs/AI_Cost_Calculator_LLD.docx).
   Python 3.12, SQLAlchemy 2.x when moving beyond sqlite3.
2. **RBAC** at the API layer (Entra ID roles: User/Reviewer/Approver/Admin) —
   required because Admins can change live prices (see gap analysis §4.1).
3. Port SQLite → Azure SQL (schema written conservatively for this).
4. LATER: AI advisor behind the existing AdvisorPort pattern (LangGraph,
   RAG-grounded on the approved catalogue, human sign-off per suggestion).
   Blocked on NBS AI Council approval — the deterministic core is NOT blocked.

## Key open questions (do not silently assume)
- Archetype-merge sentinels: usage values equal to their dataclass defaults
  (calls=1, eligibility=1, horizon=12, growth=0) read as "not set", so a user
  cannot explicitly override an archetype BACK to those values. The assumption
  report labels the outcome honestly (source=archetype). Pinned in API TEST 26.
  Proper fix: pass model_fields_set explicitness into the merge — service-layer
  change, engine signature untouched. Deferred deliberately.
- The real set of NBS pricing models (flat/per_unit/per_token/tiered assumed).
- Who owns archetype usage defaults; the ±40% band; multi-year discounting.
- Approved-technology register: source of truth, owner, update flow (pending).
- SEI overlap: our lane is PRE-BUILD estimation of new solutions (SEI reports
  actuals of existing Copilot usage) — keep the tool pointed at that gap.

## Docs
- docs/AI_Cost_Calculator_LLD.docx — full low-level design (API contracts,
  sequence, ERD; §9 lists the open design decisions).
- docs/AI_Cost_Calculator_Gap_Analysis.docx — engine vs product epics register.
- diagrams/ — architecture (numbered flow), ERD, logic flow, catalogue map,
  editable draw.io of the component architecture.
