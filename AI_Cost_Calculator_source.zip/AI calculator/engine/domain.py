"""
Machine 1 — Deterministic Costing Engine
domain.py — the data structures the engine computes over.

Design rules embodied here:
  - Value objects are frozen (immutable) — once created they don't change.
  - The engine holds NO prices in code; prices live in the catalogue data.
  - Money is Decimal, never float (no rounding surprises in financial maths).
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from enum import Enum
from uuid import UUID, uuid4


# ----- enums -----
class PricingModelType(str, Enum):
    FLAT = "flat"            # fixed price regardless of usage (e.g. a licence)
    PER_UNIT = "per_unit"    # price x quantity (storage £/GB, calls)
    PER_TOKEN = "per_token"  # AI inference, embeddings (price per 1M tokens)
    TIERED = "tiered"        # rate changes across volume bands


class ComponentType(str, Enum):
    LLM_MODEL = "llm_model"        # priced on tokens; expands to input+output lines
    EMBEDDING = "embedding"        # priced on tokens (input only)
    INFRA = "infra"                # App Service, SQL, etc.
    LICENCE = "licence"            # PEGA and similar
    VECTOR_STORE = "vector_store"  # AI Search / knowledge base
    OBSERVABILITY = "observability"  # App Insights, Log Analytics, etc. (Epic 2 AC4-6)


# ----- catalogue (the "live" world) -----
@dataclass(frozen=True)
class Tier:
    """One band of a tiered price: [lower, upper) charged at `rate` per unit."""
    lower: Decimal
    upper: Decimal          # use Decimal('Infinity') for the top band
    rate: Decimal


@dataclass(frozen=True)
class PricingModel:
    code: str
    type: PricingModelType
    tiers: tuple[Tier, ...] = ()   # only used when type == TIERED


@dataclass(frozen=True)
class Price:
    """A dated price for a component+unit. Current price = the one whose
    [effective_from, effective_to) range covers the pricing date."""
    component_code: str
    unit: str                      # 'input_token','output_token','GB','licence','hour'...
    unit_price: Decimal            # price PER unit (or per 1M tokens for token units)
    currency: str
    effective_from: date
    effective_to: date | None      # None = open-ended (still current)

    def covers(self, on: date) -> bool:
        if on < self.effective_from:
            return False
        if self.effective_to is not None and on >= self.effective_to:
            return False
        return True


@dataclass(frozen=True)
class Component:
    code: str
    name: str
    component_type: ComponentType
    approved: bool
    pricing_model_code: str
    default_unit: str
    mi_tag: str | None = None       # business area for MI split
    observability_category: str | None = None  # e.g. 'logging','tracing','metrics','alerting'


@dataclass(frozen=True)
class Dependency:
    """component_code requires requires_code at the given ratio (per 1 of component)."""
    component_code: str
    requires_code: str
    ratio: Decimal


@dataclass(frozen=True)
class Archetype:
    code: str
    name: str
    low_range: Decimal
    high_range: Decimal
    default_usage: dict = field(default_factory=dict)


# ----- the request (what the user supplies) -----
@dataclass(frozen=True)
class TokenAnatomy:
    """Breakdown of what makes up ONE request's input tokens (Epic 2 AC2).
    Each field is a token count. The engine sums them into the input-token
    quantity — the pricing stage is unchanged. All optional; omitted = 0."""
    system_prompt: int = 0
    conversation_history: int = 0
    rag_context: int = 0
    tool_definitions: int = 0
    tool_results: int = 0
    user_message: int = 0

    def total(self) -> int:
        return (self.system_prompt + self.conversation_history + self.rag_context
                + self.tool_definitions + self.tool_results + self.user_message)

    def is_empty(self) -> bool:
        return self.total() == 0


@dataclass(frozen=True)
class UsageAssumptions:
    """Raw metered numbers from the user (archetype may pre-fill these)."""
    requests_per_month: int = 0
    input_tokens_per_request: int = 0          # flat input (used if anatomy empty)
    output_tokens_per_request: int = 0
    cached_input_tokens_per_request: int = 0   # cached portion, priced separately (Epic 2 AC3)
    calls_per_request: Decimal = Decimal(1)    # orchestration multiplier
    eligibility_rate: Decimal = Decimal(1)     # fraction of events that hit the AI (Epic 1b)
    time_horizon_months: int = 12
    growth_rate_monthly: Decimal = Decimal(0)  # month-on-month growth for projection (Epic 5)
    anatomy: "TokenAnatomy | None" = None      # if set, its total overrides input_tokens_per_request

    def effective_input_tokens(self) -> int:
        """The input tokens per request: the anatomy total if provided, else the flat number."""
        if self.anatomy is not None and not self.anatomy.is_empty():
            return self.anatomy.total()
        return self.input_tokens_per_request


@dataclass(frozen=True)
class SolutionComponent:
    component_code: str
    quantity: Decimal = Decimal(1)
    # shared=True: the component already runs elsewhere in the estate — its
    # cost is SHOWN but NOT attributed to this estimate, and it brings no
    # new dependency infrastructure (it already has its own).
    shared: bool = False


@dataclass(frozen=True)
class SolutionSpec:
    archetype_code: str
    components: tuple[SolutionComponent, ...]
    usage: UsageAssumptions
    business_area: str | None = None


# ----- engine intermediate + output objects -----
@dataclass(frozen=True)
class LineItem:
    """Stage 1 output: something to price, with a resolved quantity. No price yet."""
    component: Component
    quantity: Decimal
    unit: str
    shared: bool = False   # priced + listed, but NOT attributed to the totals


@dataclass(frozen=True)
class PricedLine:
    """Stage 2 output: a line with the current price attached and frozen."""
    line: LineItem
    unit_price: Decimal
    effective_from: date

    @property
    def component(self) -> Component:
        return self.line.component

    @property
    def quantity(self) -> Decimal:
        return self.line.quantity

    @property
    def unit(self) -> str:
        return self.line.unit


@dataclass(frozen=True)
class CostedLine:
    """Stage 3 output: a line with its computed cost."""
    priced: PricedLine
    cost: Decimal

    @property
    def shared(self) -> bool:
        return self.priced.line.shared

    @property
    def usage_driven(self) -> bool:
        return self.priced.component.component_type in (
            ComponentType.LLM_MODEL, ComponentType.EMBEDDING
        )

    @property
    def mi_tag(self) -> str:
        return self.priced.component.mi_tag or "untagged"


@dataclass(frozen=True)
class EstimateResult:
    """Stage 4/5 output: the final estimate."""
    total_low: Decimal
    total_expected: Decimal
    total_high: Decimal
    by_business_area: dict[str, Decimal]
    lines: tuple[CostedLine, ...]
    warnings: tuple[str, ...] = ()
    priced_on: date | None = None
    shared_cost: Decimal = Decimal(0)   # value of shared lines — NOT in totals


# ----- engine errors -----
class EngineError(Exception):
    pass

class UnapprovedComponentError(EngineError):
    def __init__(self, code: str):
        super().__init__(f"Component not approved or not found: {code}")
        self.code = code

class MissingPriceError(EngineError):
    def __init__(self, code: str, unit: str):
        super().__init__(f"No current price for component '{code}' unit '{unit}'")
        self.code, self.unit = code, unit

class UnknownPricingModelError(EngineError):
    def __init__(self, code: str):
        super().__init__(f"No strategy for pricing model: {code}")
        self.code = code
