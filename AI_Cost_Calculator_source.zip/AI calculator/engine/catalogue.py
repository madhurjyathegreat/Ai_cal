"""
catalogue.py — an in-memory snapshot of the catalogue, handed to the engine.

In production a repository loads this from Azure SQL once per estimate and passes
it in. The engine never calls a database — it only reads this snapshot. That is
what keeps the engine pure and unit-testable.
"""
from __future__ import annotations
from datetime import date
from decimal import Decimal

from domain import (
    Component, Price, PricingModel, Dependency, Archetype,
    PricingModelType,
)


class CatalogueView:
    def __init__(
        self,
        components: list[Component],
        prices: list[Price],
        models: list[PricingModel],
        dependencies: list[Dependency],
        archetypes: list[Archetype],
    ):
        self._components = {c.code: c for c in components}
        self._models = {m.code: m for m in models}
        self._archetypes = {a.code: a for a in archetypes}
        # prices indexed by (component_code, unit) -> list of Price
        self._prices: dict[tuple[str, str], list[Price]] = {}
        for p in prices:
            self._prices.setdefault((p.component_code, p.unit), []).append(p)
        # dependencies indexed by component_code
        self._deps: dict[str, list[Dependency]] = {}
        for d in dependencies:
            self._deps.setdefault(d.component_code, []).append(d)

    # ----- component lookups -----
    def get(self, code: str) -> Component | None:
        return self._components.get(code)

    def dependencies_of(self, component: Component) -> list[Dependency]:
        return self._deps.get(component.code, [])

    def pricing_model(self, code: str) -> PricingModel | None:
        return self._models.get(code)

    def archetype(self, code: str) -> Archetype | None:
        return self._archetypes.get(code)

    # ----- price lookup: current price for (component, unit) on a date -----
    def current_price(self, component_code: str, unit: str, on: date) -> Price | None:
        candidates = self._prices.get((component_code, unit), [])
        for p in candidates:
            if p.covers(on):
                return p
        return None
