"""
run_tests.py — seed realistic data, run the engine, and ASSERT the maths is right.
This is the "if it fails, fix the logic" harness. Run: python run_tests.py
"""
from __future__ import annotations
from datetime import date
from decimal import Decimal, getcontext

from domain import (
    Component, Price, PricingModel, Dependency, Archetype,
    PricingModelType, ComponentType,
    SolutionSpec, SolutionComponent, UsageAssumptions,
    UnapprovedComponentError, MissingPriceError,
)
from catalogue import CatalogueView
import engine

getcontext().prec = 28
D = Decimal
TODAY = date(2026, 6, 28)


# ----------------------------------------------------------------------
# SEED DATA — a small but realistic catalogue
# ----------------------------------------------------------------------
def build_catalogue() -> CatalogueView:
    models = [
        PricingModel("flat", PricingModelType.FLAT),
        PricingModel("per_unit", PricingModelType.PER_UNIT),
        PricingModel("per_token", PricingModelType.PER_TOKEN),
        PricingModel("tiered_search", PricingModelType.TIERED, tiers=(
            # first 100 GB at 0.10, next up to 1000 at 0.08, rest at 0.06
            __import__("domain").Tier(D(0),    D(100),       D("0.10")),
            __import__("domain").Tier(D(100),  D(1000),      D("0.08")),
            __import__("domain").Tier(D(1000), D("Infinity"),D("0.06")),
        )),
    ]

    components = [
        Component("gpt4o", "Azure OpenAI GPT-4o", ComponentType.LLM_MODEL,
                  approved=True, pricing_model_code="per_token",
                  default_unit="input_token", mi_tag="AI"),
        Component("gpt4omini", "Azure OpenAI GPT-4o mini", ComponentType.LLM_MODEL,
                  approved=True, pricing_model_code="per_token",
                  default_unit="input_token", mi_tag="AI"),
        Component("embed", "Azure OpenAI Embeddings", ComponentType.EMBEDDING,
                  approved=True, pricing_model_code="per_token",
                  default_unit="input_token", mi_tag="AI"),
        Component("aisearch", "Azure AI Search (vector store)", ComponentType.VECTOR_STORE,
                  approved=True, pricing_model_code="per_unit",
                  default_unit="month", mi_tag="AI"),
        Component("appsvc", "Azure App Service", ComponentType.INFRA,
                  approved=True, pricing_model_code="per_unit",
                  default_unit="month", mi_tag="Platform"),
        Component("sql", "Azure SQL Database", ComponentType.INFRA,
                  approved=True, pricing_model_code="per_unit",
                  default_unit="month", mi_tag="Platform"),
        Component("pega", "PEGA Licence", ComponentType.LICENCE,
                  approved=True, pricing_model_code="flat",
                  default_unit="licence", mi_tag="Mortgages"),
        # observability components (Epic 2 AC4-6) — priceable + carry a category
        Component("appinsights", "Application Insights", ComponentType.OBSERVABILITY,
                  approved=True, pricing_model_code="per_unit",
                  default_unit="month", mi_tag="Platform", observability_category="logging"),
        Component("tracing", "Distributed Tracing", ComponentType.OBSERVABILITY,
                  approved=True, pricing_model_code="per_unit",
                  default_unit="month", mi_tag="Platform", observability_category="tracing"),
        Component("metrics", "Metrics Dashboard", ComponentType.OBSERVABILITY,
                  approved=True, pricing_model_code="per_unit",
                  default_unit="month", mi_tag="Platform", observability_category="metrics"),
        Component("alerting", "Alerting", ComponentType.OBSERVABILITY,
                  approved=True, pricing_model_code="per_unit",
                  default_unit="month", mi_tag="Platform", observability_category="alerting"),
        # an UNAPPROVED component to test rejection
        Component("rogue", "Unapproved Tool", ComponentType.INFRA,
                  approved=False, pricing_model_code="flat",
                  default_unit="month"),
    ]

    prices = [
        # token prices are PER 1,000,000 tokens
        Price("gpt4o", "input_token",  D("2.50"), "USD", date(2026,1,1), None),
        Price("gpt4o", "output_token", D("10.00"),"USD", date(2026,1,1), None),
        Price("gpt4o", "cached_input_token", D("1.25"), "USD", date(2026,1,1), None),  # cached = half price
        Price("gpt4omini", "input_token",  D("0.15"), "USD", date(2026,1,1), None),
        Price("gpt4omini", "output_token", D("0.60"), "USD", date(2026,1,1), None),
        Price("embed", "input_token",  D("0.02"), "USD", date(2026,1,1), None),
        # monthly infra
        Price("aisearch", "month", D("250.00"), "USD", date(2026,1,1), None),
        Price("appsvc",   "month", D("73.00"),  "USD", date(2026,1,1), None),
        Price("sql",      "month", D("400.00"), "USD", date(2026,1,1), None),
        Price("pega",     "licence", D("50000.00"), "USD", date(2026,1,1), None),
        Price("appinsights", "month", D("50.00"), "USD", date(2026,1,1), None),
        Price("tracing",     "month", D("30.00"), "USD", date(2026,1,1), None),
        Price("metrics",     "month", D("20.00"), "USD", date(2026,1,1), None),
        Price("alerting",    "month", D("10.00"), "USD", date(2026,1,1), None),
        # demonstrate dated pricing: App Service was cheaper before Jan 2026
        Price("appsvc", "month", D("60.00"), "USD", date(2025,1,1), date(2026,1,1)),
    ]

    dependencies = [
        # GPT-4o solution implies an App Service + SQL to run on
        Dependency("gpt4o", "appsvc", D(1)),
        Dependency("gpt4o", "sql", D(1)),
        Dependency("gpt4omini", "appsvc", D(1)),
        Dependency("gpt4omini", "sql", D(1)),
    ]

    archetypes = [
        Archetype("rag_assistant", "RAG Assistant",
                  low_range=D("50000"), high_range=D("500000"),
                  default_usage={
                      "requests_per_month": 10000,
                      "input_tokens_per_request": 1500,
                      "output_tokens_per_request": 300,
                      "calls_per_request": 3,
                      "time_horizon_months": 12,
                  }),
        Archetype("tiny", "Tiny Tool", low_range=D("100000"), high_range=D("200000")),
    ]

    return CatalogueView(components, prices, models, dependencies, archetypes)


# ----------------------------------------------------------------------
# helper
# ----------------------------------------------------------------------
def approx(a: Decimal, b, tol=D("0.01")) -> bool:
    return abs(D(a) - D(b)) <= tol

PASS, FAIL = 0, 0
def check(name, cond):
    global PASS, FAIL
    if cond:
        PASS += 1; print(f"  PASS  {name}")
    else:
        FAIL += 1; print(f"  FAIL  {name}")


# ----------------------------------------------------------------------
# TEST 1 — a realistic RAG assistant, verify the maths by hand
# ----------------------------------------------------------------------
def test_rag_assistant(cat):
    print("\nTEST 1 — RAG assistant, full pipeline")
    spec = SolutionSpec(
        archetype_code="rag_assistant",
        components=(
            SolutionComponent("gpt4o", D(1)),
            SolutionComponent("embed", D(1)),
            SolutionComponent("aisearch", D(1)),
            SolutionComponent("pega", D(2)),    # 2 licences
        ),
        usage=UsageAssumptions(
            requests_per_month=10_000,
            input_tokens_per_request=1_500,
            output_tokens_per_request=300,
            calls_per_request=D(3),             # orchestration multiplier
            time_horizon_months=12,
        ),
        business_area="Mortgages",
    )
    r = engine.run_estimate(spec, cat, priced_on=TODAY)

    # ---- hand-calculated expectations ----
    # monthly_calls = 10,000 * 3 = 30,000
    # GPT input tokens/yr  = 30,000 * 1,500 * 12 = 540,000,000  -> /1e6 * 2.50 = 1350.00
    # GPT output tokens/yr = 30,000 *   300 * 12 = 108,000,000  -> /1e6 * 10.0 = 1080.00
    # embed input tokens/yr= 30,000 * 1,500 * 12 = 540,000,000  -> /1e6 * 0.02 =   10.80
    # aisearch month       = 1 * 12 * 250 = 3000.00
    # appsvc (dep of gpt4o)= 1 * 12 * 73  = 876.00
    # sql    (dep of gpt4o)= 1 * 12 * 400 = 4800.00
    # pega   = 2 * 50000 = 100000.00 (flat, NOT x months)
    exp_total = D("1350.00")+D("1080.00")+D("10.80")+D("3000.00")+D("876.00")+D("4800.00")+D("100000.00")
    print(f"    expected total computed by hand = {exp_total}")
    print(f"    engine total_expected          = {r.total_expected}")
    check("total matches hand calculation", approx(r.total_expected, exp_total))

    # business-area split: AI = gpt(1350+1080+10.80)+aisearch(3000)=5440.80;
    # Platform = appsvc 876 + sql 4800 = 5676; Mortgages = pega 100000
    check("MI split AI",        approx(r.by_business_area.get("AI", 0),      D("5440.80")))
    check("MI split Platform",  approx(r.by_business_area.get("Platform",0), D("5676.00")))
    check("MI split Mortgages", approx(r.by_business_area.get("Mortgages",0),D("100000.00")))

    # range: only usage-driven (gpt+embed) lines flex +/-40%.
    # usage-driven expected = 1350+1080+10.80 = 2440.80
    # fixed = total - 2440.80
    usage_driven = D("1350.00")+D("1080.00")+D("10.80")
    fixed = exp_total - usage_driven
    exp_low = fixed + usage_driven * (D(1)-D("0.40"))
    exp_high = fixed + usage_driven * (D(1)+D("0.40"))
    check("range low",  approx(r.total_low, exp_low))
    check("range high", approx(r.total_high, exp_high))
    check("low <= expected <= high", r.total_low <= r.total_expected <= r.total_high)

    # within archetype band 50k-500k -> no warning
    check("no sanity warning (within band)", len(r.warnings) == 0)
    return r


# ----------------------------------------------------------------------
# TEST 2 — unapproved component is rejected
# ----------------------------------------------------------------------
def test_unapproved(cat):
    print("\nTEST 2 — unapproved component rejected")
    spec = SolutionSpec("rag_assistant",
                        (SolutionComponent("rogue", D(1)),),
                        UsageAssumptions(), None)
    try:
        engine.run_estimate(spec, cat, priced_on=TODAY)
        check("should have raised UnapprovedComponentError", False)
    except UnapprovedComponentError as e:
        check("raised UnapprovedComponentError for 'rogue'", e.code == "rogue")


# ----------------------------------------------------------------------
# TEST 3 — dated pricing: an estimate priced in 2025 uses the OLD price
# ----------------------------------------------------------------------
def test_dated_pricing(cat):
    print("\nTEST 3 — dated pricing (reproducibility)")
    spec = SolutionSpec("tiny",
                        (SolutionComponent("appsvc", D(1)),),
                        UsageAssumptions(time_horizon_months=1), None)
    r_now = engine.run_estimate(spec, cat, priced_on=date(2026,6,28))
    r_old = engine.run_estimate(spec, cat, priced_on=date(2025,6,1))
    # now: 1 month * 73 = 73 ; old: 1 month * 60 = 60
    check("current price used now (73)", approx(r_now.total_expected, D("73.00")))
    check("old price used in 2025 (60)", approx(r_old.total_expected, D("60.00")))


# ----------------------------------------------------------------------
# TEST 4 — sanity check fires when total is outside the band
# ----------------------------------------------------------------------
def test_sanity(cat):
    print("\nTEST 4 — sanity check warning")
    # 'tiny' archetype band is 100k-200k. A single cheap app service is way below.
    spec = SolutionSpec("tiny",
                        (SolutionComponent("appsvc", D(1)),),
                        UsageAssumptions(time_horizon_months=1), None)
    r = engine.run_estimate(spec, cat, priced_on=TODAY)
    check("warning raised (below band)", len(r.warnings) == 1)
    check("warning mentions BELOW", "BELOW" in (r.warnings[0] if r.warnings else ""))
    # but the number is NOT changed by the warning
    check("number unchanged by warning", approx(r.total_expected, D("73.00")))


# ----------------------------------------------------------------------
# TEST 5 — tiered pricing maths
# ----------------------------------------------------------------------
def test_tiered(cat):
    print("\nTEST 5 — tiered pricing")
    # build a one-off component using the tiered model, 1500 GB
    from domain import Component as C, Price as P
    comp = C("bigstore","Big Store",ComponentType.INFRA,True,"tiered_search","GB","Platform")
    price = P("bigstore","GB",D("0"),"USD",date(2026,1,1),None)  # tiered ignores unit_price
    cat2 = CatalogueView(
        [comp],
        [price],
        _models_for_tiered(),
        [],
        [Archetype("none","none",D(0),D("Infinity"))],
    )
    spec = SolutionSpec("none",(SolutionComponent("bigstore",D(1500)),),
                        UsageAssumptions(time_horizon_months=1),None)
    r = engine.run_estimate(spec, cat2, priced_on=TODAY)
    # 1500 GB: first 100 @0.10=10 ; next 900 (100-1000) @0.08=72 ; last 500 (1000-1500)@0.06=30 => 112
    # but default_unit GB is not month/hour so qty stays 1500 (not x months) - good
    check("tiered total = 112", approx(r.total_expected, D("112.00")))


def _models_for_tiered():
    from domain import Tier
    return [
        PricingModel("tiered_search", PricingModelType.TIERED, tiers=(
            Tier(D(0),    D(100),       D("0.10")),
            Tier(D(100),  D(1000),      D("0.08")),
            Tier(D(1000), D("Infinity"),D("0.06")),
        )),
        PricingModel("per_unit", PricingModelType.PER_UNIT),
        PricingModel("flat", PricingModelType.FLAT),
        PricingModel("per_token", PricingModelType.PER_TOKEN),
    ]


# ----------------------------------------------------------------------
# TEST 6 — shared dependency is NOT double-counted
# ----------------------------------------------------------------------
def test_shared_dependency_dedup():
    print("\nTEST 6 — shared dependency de-duplication")
    from domain import Component as C, Price as P
    comps = [
        C("ai1","AI One",ComponentType.INFRA,True,"per_unit","month","AI"),
        C("ai2","AI Two",ComponentType.INFRA,True,"per_unit","month","AI"),
        C("shared","Shared App Service",ComponentType.INFRA,True,"per_unit","month","Platform"),
    ]
    prices = [
        P("ai1","month",D("10"),"USD",date(2026,1,1),None),
        P("ai2","month",D("10"),"USD",date(2026,1,1),None),
        P("shared","month",D("100"),"USD",date(2026,1,1),None),
    ]
    deps = [Dependency("ai1","shared",D(1)), Dependency("ai2","shared",D(1))]
    cat = CatalogueView(comps, prices, _models_for_tiered(), deps,
                        [Archetype("none","none",D(0),D("Infinity"))])
    spec = SolutionSpec("none",
                        (SolutionComponent("ai1",D(1)), SolutionComponent("ai2",D(1))),
                        UsageAssumptions(time_horizon_months=1), None)
    r = engine.run_estimate(spec, cat, priced_on=TODAY)
    shared_lines = [l for l in r.lines if l.priced.component.code=="shared"]
    check("shared dependency emitted exactly once", len(shared_lines)==1)
    check("shared dependency quantity summed (=200)", approx(shared_lines[0].cost, D("200")))
    check("total = 10+10+200 = 220", approx(r.total_expected, D("220")))


# ----------------------------------------------------------------------
# TEST 7 — transitive dependency (A->B->C) is expanded
# ----------------------------------------------------------------------
def test_transitive_dependency():
    print("\nTEST 7 — transitive dependency expansion")
    from domain import Component as C, Price as P
    comps = [
        C("a","A",ComponentType.INFRA,True,"per_unit","month","X"),
        C("b","B",ComponentType.INFRA,True,"per_unit","month","X"),
        C("c","C",ComponentType.INFRA,True,"per_unit","month","X"),
    ]
    prices = [
        P("a","month",D("1"),"USD",date(2026,1,1),None),
        P("b","month",D("2"),"USD",date(2026,1,1),None),
        P("c","month",D("4"),"USD",date(2026,1,1),None),
    ]
    deps = [Dependency("a","b",D(1)), Dependency("b","c",D(1))]
    cat = CatalogueView(comps, prices, _models_for_tiered(), deps,
                        [Archetype("none","none",D(0),D("Infinity"))])
    spec = SolutionSpec("none",(SolutionComponent("a",D(1)),),
                        UsageAssumptions(time_horizon_months=1),None)
    r = engine.run_estimate(spec, cat, priced_on=TODAY)
    codes = {l.priced.component.code for l in r.lines}
    check("transitive dep C is included", "c" in codes)
    check("total = A1 + B2 + C4 = 7", approx(r.total_expected, D("7")))


# ----------------------------------------------------------------------
# TEST 8 — cyclic dependency does NOT infinite-loop
# ----------------------------------------------------------------------
def test_cycle_safe():
    print("\nTEST 8 — cyclic dependency is cycle-safe")
    from domain import Component as C, Price as P
    comps = [
        C("x","X",ComponentType.INFRA,True,"per_unit","month","X"),
        C("y","Y",ComponentType.INFRA,True,"per_unit","month","X"),
    ]
    prices = [
        P("x","month",D("5"),"USD",date(2026,1,1),None),
        P("y","month",D("7"),"USD",date(2026,1,1),None),
    ]
    deps = [Dependency("x","y",D(1)), Dependency("y","x",D(1))]
    cat = CatalogueView(comps, prices, _models_for_tiered(), deps,
                        [Archetype("none","none",D(0),D("Infinity"))])
    spec = SolutionSpec("none",(SolutionComponent("x",D(1)),),
                        UsageAssumptions(time_horizon_months=1),None)
    try:
        r = engine.run_estimate(spec, cat, priced_on=TODAY)
        check("cycle terminates (no hang)", True)
        check("total = X5 + Y7 = 12 (cycle broken)", approx(r.total_expected, D("12")))
    except RecursionError:
        check("cycle terminates (no hang)", False)


# ----------------------------------------------------------------------
# TEST 9 — archetype defaults fill in omitted usage numbers
# ----------------------------------------------------------------------
def test_archetype_defaults(cat):
    print("\nTEST 9 — archetype defaults pre-fill omitted usage")
    components = (
        SolutionComponent("gpt4o", D(1)),
        SolutionComponent("embed", D(1)),
        SolutionComponent("aisearch", D(1)),
        SolutionComponent("pega", D(2)),
    )
    # CASE A: user supplies all usage numbers explicitly
    spec_explicit = SolutionSpec(
        "rag_assistant", components,
        UsageAssumptions(requests_per_month=10_000, input_tokens_per_request=1_500,
                         output_tokens_per_request=300, calls_per_request=D(3),
                         time_horizon_months=12),
        "Mortgages")
    # CASE B: user supplies NOTHING — archetype defaults should fill in
    spec_default = SolutionSpec(
        "rag_assistant", components,
        UsageAssumptions(),     # all defaults/zeros
        "Mortgages")
    r_explicit = engine.run_estimate(spec_explicit, cat, priced_on=TODAY)
    r_default  = engine.run_estimate(spec_default,  cat, priced_on=TODAY)
    check("omitted usage falls back to archetype defaults",
          approx(r_default.total_expected, r_explicit.total_expected))
    check("default-filled total equals the known £111,116.80",
          approx(r_default.total_expected, D("111116.80")))

    # CASE C: user OVERRIDES one value — their value must win over the default
    spec_override = SolutionSpec(
        "rag_assistant", components,
        UsageAssumptions(requests_per_month=20_000),  # double the default 10k
        "Mortgages")
    r_override = engine.run_estimate(spec_override, cat, priced_on=TODAY)
    # token costs double (requests 10k->20k); fixed infra/licence unchanged.
    # usage-driven expected was 2440.80 -> doubles to 4881.60; delta = +2440.80
    check("user override beats the archetype default",
          approx(r_override.total_expected, D("111116.80") + D("2440.80")))


# ----------------------------------------------------------------------
# TEST 10 — token anatomy sums to the input-token quantity
# ----------------------------------------------------------------------
def test_token_anatomy(cat):
    print("\nTEST 10 — token anatomy (Epic 2 AC2)")
    from domain import TokenAnatomy
    # anatomy parts sum to 1500 (same as the flat number used elsewhere)
    anat = TokenAnatomy(system_prompt=200, conversation_history=400, rag_context=600,
                        tool_definitions=100, tool_results=100, user_message=100)
    check("anatomy.total() = 1500", anat.total() == 1500)
    spec = SolutionSpec("rag_assistant",
        (SolutionComponent("gpt4o", D(1)),),
        UsageAssumptions(requests_per_month=10_000, output_tokens_per_request=300,
                         calls_per_request=D(3), time_horizon_months=12, anatomy=anat),
        "Mortgages")
    r = engine.run_estimate(spec, cat, priced_on=TODAY)
    # input: 30k calls * 1500 * 12 = 540,000,000 -> /1e6 * 2.50 = 1350.00
    # output: 30k * 300 * 12 = 108,000,000 -> /1e6 * 10 = 1080.00
    # gpt4o also pulls appsvc+sql deps (876 + 4800)
    gpt_lines = [l for l in r.lines if l.priced.component.code=="gpt4o"]
    input_line = [l for l in gpt_lines if l.priced.unit=="input_token"][0]
    check("anatomy drives input cost = 1350", approx(input_line.cost, D("1350.00")))
    # and it equals what the flat 1500 number would produce
    spec_flat = SolutionSpec("rag_assistant",
        (SolutionComponent("gpt4o", D(1)),),
        UsageAssumptions(requests_per_month=10_000, input_tokens_per_request=1500,
                         output_tokens_per_request=300, calls_per_request=D(3),
                         time_horizon_months=12),
        "Mortgages")
    r_flat = engine.run_estimate(spec_flat, cat, priced_on=TODAY)
    check("anatomy total == flat equivalent", approx(r.total_expected, r_flat.total_expected))


# ----------------------------------------------------------------------
# TEST 11 — cached vs uncached input tokens priced separately
# ----------------------------------------------------------------------
def test_cached_tokens(cat):
    print("\nTEST 11 — cached input tokens (Epic 2 AC3)")
    # 1500 input, of which 500 cached. Uncached=1000 @2.50, cached=500 @1.25
    spec = SolutionSpec("rag_assistant",
        (SolutionComponent("gpt4o", D(1)),),
        UsageAssumptions(requests_per_month=10_000, input_tokens_per_request=1500,
                         cached_input_tokens_per_request=500, output_tokens_per_request=300,
                         calls_per_request=D(3), time_horizon_months=12),
        "Mortgages")
    r = engine.run_estimate(spec, cat, priced_on=TODAY)
    gpt = [l for l in r.lines if l.priced.component.code=="gpt4o"]
    uncached = [l for l in gpt if l.priced.unit=="input_token"][0]
    cached   = [l for l in gpt if l.priced.unit=="cached_input_token"][0]
    # calls=30k, months=12. uncached=1000 -> 30k*1000*12=360M ->/1e6*2.50=900
    # cached=500 -> 30k*500*12=180M ->/1e6*1.25=225
    check("uncached input cost = 900", approx(uncached.cost, D("900.00")))
    check("cached input cost = 225", approx(cached.cost, D("225.00")))
    check("cached is cheaper than same volume uncached", cached.cost < D("450"))


# ----------------------------------------------------------------------
# TEST 12 — eligibility rate scales down effective requests
# ----------------------------------------------------------------------
def test_eligibility(cat):
    print("\nTEST 12 — eligibility rate (Epic 1b honest-math)")
    # only 50% of events reach the AI -> token costs should halve vs 100%
    base = dict(requests_per_month=10_000, input_tokens_per_request=1500,
                output_tokens_per_request=300, calls_per_request=D(3), time_horizon_months=12)
    spec_full = SolutionSpec("rag_assistant", (SolutionComponent("gpt4o", D(1)),),
                             UsageAssumptions(**base, eligibility_rate=D(1)), "Mortgages")
    spec_half = SolutionSpec("rag_assistant", (SolutionComponent("gpt4o", D(1)),),
                             UsageAssumptions(**base, eligibility_rate=D("0.5")), "Mortgages")
    r_full = engine.run_estimate(spec_full, cat, priced_on=TODAY)
    r_half = engine.run_estimate(spec_half, cat, priced_on=TODAY)
    gpt_full = sum(l.cost for l in r_full.lines if l.priced.component.code=="gpt4o")
    gpt_half = sum(l.cost for l in r_half.lines if l.priced.component.code=="gpt4o")
    check("50% eligibility halves the AI token cost", approx(gpt_half, gpt_full / 2))
    # infra dependencies (appsvc/sql) are NOT affected by eligibility
    sql_full = sum(l.cost for l in r_full.lines if l.priced.component.code=="sql")
    sql_half = sum(l.cost for l in r_half.lines if l.priced.component.code=="sql")
    check("eligibility does NOT change fixed infra", approx(sql_full, sql_half))


# ----------------------------------------------------------------------
# TEST 13 — 12-month projection with month-on-month growth
# ----------------------------------------------------------------------
def test_projection(cat):
    print("\nTEST 13 — 12-month growth projection (Epic 5)")
    base = dict(requests_per_month=10_000, input_tokens_per_request=1500,
                output_tokens_per_request=300, calls_per_request=D(3))
    # CASE A: 0% growth -> all 12 months equal
    spec0 = SolutionSpec("rag_assistant", (SolutionComponent("gpt4o", D(1)),),
                         UsageAssumptions(**base, growth_rate_monthly=D(0)), "Mortgages")
    series0 = engine.project_monthly(spec0, cat, TODAY, months=12)
    check("0% growth -> 12 equal months", all(approx(m, series0[0]) for m in series0))
    check("0% growth -> 12 entries", len(series0) == 12)

    # CASE B: 10% growth -> month 2 = month1 * 1.1, month 3 = *1.21, etc.
    spec10 = SolutionSpec("rag_assistant", (SolutionComponent("gpt4o", D(1)),),
                          UsageAssumptions(**base, growth_rate_monthly=D("0.10")), "Mortgages")
    series10 = engine.project_monthly(spec10, cat, TODAY, months=12)
    check("10% growth month2 = month1 * 1.10", approx(series10[1], series10[0]*D("1.10")))
    check("10% growth month3 = month1 * 1.21", approx(series10[2], series10[0]*D("1.21")))
    check("10% growth month12 = month1 * 1.1^11",
          approx(series10[11], series10[0]*(D("1.10")**11)))
    # growth total > flat total
    total10 = engine.project_total(spec10, cat, TODAY, months=12)
    total0  = engine.project_total(spec0,  cat, TODAY, months=12)
    check("growth total > flat total", total10 > total0)


# ----------------------------------------------------------------------
# TEST 14 — multi-model comparison (Epic 5 AC2)
# ----------------------------------------------------------------------
def test_model_comparison(cat):
    print("\nTEST 14 — model comparison (Epic 5 AC2)")
    spec = SolutionSpec("rag_assistant",
        (SolutionComponent("gpt4o", D(1)), SolutionComponent("aisearch", D(1))),
        UsageAssumptions(requests_per_month=10_000, input_tokens_per_request=1500,
                         output_tokens_per_request=300, calls_per_request=D(3),
                         time_horizon_months=12),
        "Mortgages")
    results = engine.compare_models(spec, cat, TODAY,
                                    model_codes=["gpt4o", "gpt4omini"], swap_from="gpt4o")
    check("comparison returns 2 models", len(results) == 2)
    check("both models present", "gpt4o" in results and "gpt4omini" in results)
    check("mini is cheaper than gpt4o",
          results["gpt4omini"].total_expected < results["gpt4o"].total_expected)
    gpt_ai = results["gpt4o"].by_business_area["AI"]
    mini_ai = results["gpt4omini"].by_business_area["AI"]
    check("AI cost lower for mini", mini_ai < gpt_ai)


# ----------------------------------------------------------------------
# TEST 15 — observability priced + coverage matrix (Epic 2 AC4-6)
# ----------------------------------------------------------------------
def test_observability(cat):
    print("\nTEST 15 — observability as priced lines + coverage (Epic 2 AC4-6)")
    # CASE A: solution with NO observability -> warning + 0% coverage
    spec_none = SolutionSpec("rag_assistant",
        (SolutionComponent("gpt4o", D(1)),),
        UsageAssumptions(requests_per_month=10_000, input_tokens_per_request=1500,
                         output_tokens_per_request=300, calls_per_request=D(3),
                         time_horizon_months=12), "Mortgages")
    cov_none = engine.observability_coverage(spec_none, cat)
    check("no observability -> 0% coverage", cov_none["coverage_pct"] == D(0))
    check("no observability -> understated warning", len(cov_none["warnings"]) == 1)

    # CASE B: full observability -> priced AND 100% coverage
    spec_full = SolutionSpec("rag_assistant",
        (SolutionComponent("gpt4o", D(1)),
         SolutionComponent("appinsights", D(1)), SolutionComponent("tracing", D(1)),
         SolutionComponent("metrics", D(1)), SolutionComponent("alerting", D(1))),
        UsageAssumptions(requests_per_month=10_000, input_tokens_per_request=1500,
                         output_tokens_per_request=300, calls_per_request=D(3),
                         time_horizon_months=12), "Mortgages")
    r_full = engine.run_estimate(spec_full, cat, priced_on=TODAY)
    cov_full = engine.observability_coverage(spec_full, cat)
    check("full observability -> 100% coverage", cov_full["coverage_pct"] == D(100))
    check("full observability -> no warning", len(cov_full["warnings"]) == 0)
    # observability is PRICED: appinsights 50*12 + tracing 30*12 + metrics 20*12 + alerting 10*12 = 1320
    obs_cost = sum(l.cost for l in r_full.lines
                   if l.priced.component.component_type.value == "observability")
    check("observability priced into estimate (=1320)", approx(obs_cost, D("1320.00")))
    # adding observability INCREASES the total vs the none case
    r_none = engine.run_estimate(spec_none, cat, priced_on=TODAY)
    check("observability increases total", r_full.total_expected > r_none.total_expected)

    # CASE C: partial observability -> partial warning + missing list
    spec_partial = SolutionSpec("rag_assistant",
        (SolutionComponent("gpt4o", D(1)), SolutionComponent("appinsights", D(1))),
        UsageAssumptions(requests_per_month=10_000, input_tokens_per_request=1500,
                         output_tokens_per_request=300, calls_per_request=D(3),
                         time_horizon_months=12), "Mortgages")
    cov_part = engine.observability_coverage(spec_partial, cat)
    check("partial observability -> 25% coverage", cov_part["coverage_pct"] == D(25))
    check("partial -> lists missing categories", "tracing" in cov_part["missing"])


# ----------------------------------------------------------------------
def test_shared_components(cat: CatalogueView):
    """Shared components: listed + priced but NOT attributed, and they bring
    no new dependency infrastructure. All expectations hand-calculated from
    the canonical £111,116.80 solution."""
    print("\nTEST — shared components (cost attribution)")
    usage = UsageAssumptions(requests_per_month=10_000, input_tokens_per_request=1_500,
                             output_tokens_per_request=300, calls_per_request=D(3),
                             time_horizon_months=12)

    # A) shared licence: 2x pega (100,000) shown but not attributed
    spec_a = SolutionSpec("rag_assistant", (
        SolutionComponent("gpt4o"), SolutionComponent("embed"),
        SolutionComponent("aisearch"), SolutionComponent("pega", D(2), shared=True),
    ), usage, "Mortgages")
    r_a = engine.run_estimate(spec_a, cat, priced_on=TODAY)
    check("shared pega: expected drops to 11,116.80",
          r_a.total_expected == D("11116.80"))
    check("shared pega: shared_cost = 100,000", r_a.shared_cost == D("100000.00"))
    check("shared pega: line still LISTED",
          any(l.priced.component.code == "pega" and l.shared for l in r_a.lines))
    check("shared pega: Mortgages NOT in MI split",
          "Mortgages" not in r_a.by_business_area)
    check("shared pega: line count unchanged (7)", len(r_a.lines) == 7)

    # B) shared LLM: token lines not attributed AND its deps not expanded
    spec_b = SolutionSpec("rag_assistant", (
        SolutionComponent("gpt4o", shared=True), SolutionComponent("embed"),
        SolutionComponent("aisearch"), SolutionComponent("pega", D(2)),
    ), usage, "Mortgages")
    r_b = engine.run_estimate(spec_b, cat, priced_on=TODAY)
    # embed 10.80 + aisearch 3,000 + pega 100,000 = 103,010.80 (no appsvc/sql!)
    check("shared gpt4o: expected = 103,010.80", r_b.total_expected == D("103010.80"))
    check("shared gpt4o: shared_cost = 2,430 (its tokens)",
          approx(r_b.shared_cost, D("2430.00")))
    check("shared gpt4o: NO dependency lines (appsvc/sql absent)",
          not any(l.priced.component.code in ("appsvc", "sql") for l in r_b.lines))
    check("shared gpt4o: 5 lines (gpt in+out shared, embed, search, pega)",
          len(r_b.lines) == 5)

    # C) direct-shared infra + new LLM requiring it: direct wins, dep deduped
    spec_c = SolutionSpec("rag_assistant", (
        SolutionComponent("gpt4o"), SolutionComponent("embed"),
        SolutionComponent("aisearch"), SolutionComponent("pega", D(2)),
        SolutionComponent("appsvc", shared=True),
    ), usage, "Mortgages")
    r_c = engine.run_estimate(spec_c, cat, priced_on=TODAY)
    # 111,116.80 minus the 876 appsvc (now shared) = 110,240.80
    check("shared appsvc alongside gpt4o: expected = 110,240.80",
          r_c.total_expected == D("110240.80"))
    check("shared appsvc: shared_cost = 876", r_c.shared_cost == D("876.00"))
    appsvc_lines = [l for l in r_c.lines if l.priced.component.code == "appsvc"]
    check("appsvc appears ONCE (direct-shared wins, dep deduped)",
          len(appsvc_lines) == 1 and appsvc_lines[0].shared)

    # D) nothing shared -> shared_cost is zero (regression guard)
    spec_d = SolutionSpec("rag_assistant", (
        SolutionComponent("gpt4o"), SolutionComponent("embed"),
        SolutionComponent("aisearch"), SolutionComponent("pega", D(2)),
    ), usage, "Mortgages")
    r_d = engine.run_estimate(spec_d, cat, priced_on=TODAY)
    check("no shared flags: shared_cost = 0 and canonical total intact",
          r_d.shared_cost == D(0) and r_d.total_expected == D("111116.80"))


# ----------------------------------------------------------------------
if __name__ == "__main__":
    cat = build_catalogue()
    test_rag_assistant(cat)
    test_unapproved(cat)
    test_dated_pricing(cat)
    test_sanity(cat)
    test_tiered(cat)
    test_shared_dependency_dedup()
    test_transitive_dependency()
    test_cycle_safe()
    test_archetype_defaults(cat)
    test_token_anatomy(cat)
    test_cached_tokens(cat)
    test_eligibility(cat)
    test_projection(cat)
    test_model_comparison(cat)
    test_observability(cat)
    test_shared_components(cat)
    print(f"\n==== RESULTS: {PASS} passed, {FAIL} failed ====")
