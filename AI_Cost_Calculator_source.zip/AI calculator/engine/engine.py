"""
engine.py — the deterministic costing engine. Five pure stages, no I/O, no AI.

  Stage 1  resolve()         solution -> priceable line items
  Stage 2  apply_prices()    attach current price to each line
  Stage 3  calculate()       apply pricing-model strategy -> cost per line
  Stage 4  aggregate()       roll up, MI-tag split, low/expected/high range
  Stage 5  sanity_check()    flag totals outside the archetype band (no block)

run_estimate() chains all five.
"""
from __future__ import annotations
from collections import defaultdict
from dataclasses import replace
from datetime import date
from decimal import Decimal

from domain import (
    SolutionSpec, LineItem, PricedLine, CostedLine, EstimateResult,
    Component, ComponentType, PricingModelType, UsageAssumptions, TokenAnatomy,
    UnapprovedComponentError, MissingPriceError, UnknownPricingModelError,
)
from catalogue import CatalogueView


# Tokens are priced "per 1M tokens" by convention, so token quantities are
# divided by this to multiply against the per-1M unit price.
TOKENS_PER_PRICE_UNIT = Decimal(1_000_000)

# Confidence band applied to usage-driven lines for the low/high range.
DEFAULT_BAND = Decimal("0.40")   # +/- 40%


# ---------------------------------------------------------------------------
# STAGE 1 — RESOLVER
# ---------------------------------------------------------------------------
def _line_quantity(comp, base_qty: Decimal, months: Decimal) -> Decimal:
    """Monthly/hourly-recurring components are multiplied by the time horizon;
    one-off units (licence, GB, etc.) are not. Used for BOTH directly-added
    components and expanded dependencies so they're treated consistently."""
    if comp.default_unit in ("month", "hour"):
        return base_qty * months
    return base_qty


def _expand_dependencies(comp, base_qty: Decimal, months: Decimal,
                         catalogue: CatalogueView,
                         dep_totals: dict, seen_chain: frozenset) -> None:
    """Recursively expand dependencies into dep_totals[code] = quantity.
    - Transitive: a dependency's own dependencies are expanded too.
    - Cycle-safe: seen_chain tracks the current path; a repeat is skipped.
    - De-duplicated: quantities for the same component are ACCUMULATED, so a
      shared dependency is counted once (as a summed quantity), not duplicated.
    """
    for dep in catalogue.dependencies_of(comp):
        if dep.requires_code in seen_chain:
            # cycle guard: don't follow a component already in this path
            continue
        dep_comp = catalogue.get(dep.requires_code)
        if dep_comp is None or not dep_comp.approved:
            raise UnapprovedComponentError(dep.requires_code)
        qty = dep.ratio * base_qty
        dep_totals[dep_comp.code] = dep_totals.get(dep_comp.code, (dep_comp, Decimal(0)))
        dc, running = dep_totals[dep_comp.code]
        dep_totals[dep_comp.code] = (dc, running + qty)
        # recurse for transitive dependencies
        _expand_dependencies(dep_comp, qty, months, catalogue,
                             dep_totals, seen_chain | {dep.requires_code})


def _effective_usage(spec: SolutionSpec, catalogue: CatalogueView) -> UsageAssumptions:
    """Merge the user's usage with the chosen archetype's default_usage.
    A user value that is supplied (non-zero / non-default) WINS; any value the
    user left at its default falls back to the archetype's default for that key.
    This is how archetypes 'pre-fill' the raw numbers without the engine ever
    interpreting free text — defaults are data, the user can always override."""
    archetype = catalogue.archetype(spec.archetype_code)
    if archetype is None or not archetype.default_usage:
        return spec.usage

    d = archetype.default_usage
    u = spec.usage
    # for each field: keep the user's value if they set one, else use the default
    return UsageAssumptions(
        requests_per_month=u.requests_per_month or int(d.get("requests_per_month", 0)),
        input_tokens_per_request=u.input_tokens_per_request or int(d.get("input_tokens_per_request", 0)),
        output_tokens_per_request=u.output_tokens_per_request or int(d.get("output_tokens_per_request", 0)),
        cached_input_tokens_per_request=(u.cached_input_tokens_per_request
                                         or int(d.get("cached_input_tokens_per_request", 0))),
        calls_per_request=(u.calls_per_request if u.calls_per_request != Decimal(1)
                           else Decimal(str(d.get("calls_per_request", 1)))),
        eligibility_rate=(u.eligibility_rate if u.eligibility_rate != Decimal(1)
                          else Decimal(str(d.get("eligibility_rate", 1)))),
        time_horizon_months=(u.time_horizon_months if u.time_horizon_months != 12
                             else int(d.get("time_horizon_months", 12))),
        growth_rate_monthly=(u.growth_rate_monthly if u.growth_rate_monthly != Decimal(0)
                             else Decimal(str(d.get("growth_rate_monthly", 0)))),
        anatomy=u.anatomy,   # anatomy is user-supplied only (not a scalar default)
    )


def resolve(spec: SolutionSpec, catalogue: CatalogueView) -> list[LineItem]:
    """Turn the solution into a flat list of priceable line items.
    Validates approval, expands dependencies (transitive, cycle-safe,
    de-duplicated), derives AI token quantities from raw usage. Pure.
    Usage numbers omitted by the user are filled from the archetype defaults."""
    lines: list[LineItem] = []
    u = _effective_usage(spec, catalogue)
    months = Decimal(u.time_horizon_months)

    # accumulate dependency quantities across ALL components first, so a
    # dependency shared by two components is summed, not added as two lines.
    dep_totals: dict[str, tuple] = {}     # code -> (Component, total_qty)
    direct_codes: set[str] = set()

    for sc in spec.components:
        comp = catalogue.get(sc.component_code)
        if comp is None or not comp.approved:
            raise UnapprovedComponentError(sc.component_code)
        direct_codes.add(comp.code)

        # a SHARED component already runs elsewhere: it brings no NEW
        # dependency infrastructure, so its dependencies are not expanded
        if not sc.shared:
            _expand_dependencies(comp, sc.quantity, months, catalogue,
                                 dep_totals, frozenset({comp.code}))

        # AI cost drivers: derive metered token quantities from raw usage.
        # eligibility_rate: only a fraction of events actually reach the AI (Epic 1b).
        if comp.component_type == ComponentType.LLM_MODEL:
            effective_requests = Decimal(u.requests_per_month) * u.eligibility_rate
            monthly_calls = effective_requests * u.calls_per_request
            in_per_req = Decimal(u.effective_input_tokens())       # anatomy total or flat
            cached_per_req = Decimal(u.cached_input_tokens_per_request)
            # uncached input = total input minus the cached portion (never below zero)
            uncached_per_req = max(in_per_req - cached_per_req, Decimal(0))
            input_tokens = monthly_calls * uncached_per_req * months
            cached_tokens = monthly_calls * cached_per_req * months
            output_tokens = monthly_calls * Decimal(u.output_tokens_per_request) * months
            lines.append(LineItem(comp, quantity=input_tokens, unit="input_token", shared=sc.shared))
            if cached_tokens > 0:
                lines.append(LineItem(comp, quantity=cached_tokens, unit="cached_input_token", shared=sc.shared))
            lines.append(LineItem(comp, quantity=output_tokens, unit="output_token", shared=sc.shared))

        elif comp.component_type == ComponentType.EMBEDDING:
            effective_requests = Decimal(u.requests_per_month) * u.eligibility_rate
            monthly_calls = effective_requests * u.calls_per_request
            emb_tokens = monthly_calls * Decimal(u.effective_input_tokens()) * months
            lines.append(LineItem(comp, quantity=emb_tokens, unit="input_token", shared=sc.shared))

        else:
            lines.append(LineItem(
                comp,
                quantity=_line_quantity(comp, sc.quantity, months),
                unit=comp.default_unit,
                shared=sc.shared,
            ))

    # now emit one line per UNIQUE dependency, with summed quantity —
    # but skip any dependency that was ALSO added directly (avoid double count)
    for code, (dep_comp, total_qty) in dep_totals.items():
        if code in direct_codes:
            continue
        lines.append(LineItem(
            dep_comp,
            quantity=_line_quantity(dep_comp, total_qty, months),
            unit=dep_comp.default_unit,
        ))

    return lines


# ---------------------------------------------------------------------------
# STAGE 2 — PRICING RESOLVER (only stage that touches prices)
# ---------------------------------------------------------------------------
def apply_prices(lines: list[LineItem], catalogue: CatalogueView,
                 priced_on: date) -> list[PricedLine]:
    out: list[PricedLine] = []
    for li in lines:
        price = catalogue.current_price(li.component.code, li.unit, on=priced_on)
        if price is None:
            raise MissingPriceError(li.component.code, li.unit)
        out.append(PricedLine(
            line=li,
            unit_price=price.unit_price,
            effective_from=price.effective_from,
        ))
    return out


# ---------------------------------------------------------------------------
# STAGE 3 — CALCULATION (pricing-model strategies)
# ---------------------------------------------------------------------------
def _flat(p: PricedLine) -> Decimal:
    return p.unit_price * p.quantity

def _per_unit(p: PricedLine) -> Decimal:
    return p.unit_price * p.quantity

def _per_token(p: PricedLine) -> Decimal:
    # unit_price is per 1,000,000 tokens
    return p.unit_price * (p.quantity / TOKENS_PER_PRICE_UNIT)

def _tiered(p: PricedLine, catalogue: CatalogueView) -> Decimal:
    model = catalogue.pricing_model(p.component.pricing_model_code)
    qty = p.quantity
    total = Decimal(0)
    for tier in model.tiers:
        if qty <= tier.lower:
            continue
        upper = min(qty, tier.upper)
        band_qty = upper - tier.lower
        if band_qty > 0:
            total += band_qty * tier.rate
    return total

def calculate(priced: list[PricedLine], catalogue: CatalogueView) -> list[CostedLine]:
    out: list[CostedLine] = []
    for p in priced:
        model = catalogue.pricing_model(p.component.pricing_model_code)
        if model is None:
            raise UnknownPricingModelError(p.component.pricing_model_code)
        t = model.type
        if t == PricingModelType.FLAT:
            cost = _flat(p)
        elif t == PricingModelType.PER_UNIT:
            cost = _per_unit(p)
        elif t == PricingModelType.PER_TOKEN:
            cost = _per_token(p)
        elif t == PricingModelType.TIERED:
            cost = _tiered(p, catalogue)
        else:
            raise UnknownPricingModelError(p.component.pricing_model_code)
        out.append(CostedLine(priced=p, cost=cost))
    return out


# ---------------------------------------------------------------------------
# STAGE 4 — AGGREGATOR
# ---------------------------------------------------------------------------
def aggregate(lines: list[CostedLine], band: Decimal = DEFAULT_BAND) -> EstimateResult:
    """Roll up ATTRIBUTED lines into the totals; SHARED lines stay visible in
    `lines` and their value is reported separately as shared_cost — costed
    elsewhere in the estate, never in this estimate's business case."""
    expected = Decimal(0)
    low = Decimal(0)
    high = Decimal(0)
    shared_cost = Decimal(0)
    by_area: dict[str, Decimal] = defaultdict(lambda: Decimal(0))
    for l in lines:
        if l.shared:
            shared_cost += l.cost
            continue
        expected += l.cost
        if l.usage_driven:
            low += l.cost * (Decimal(1) - band)
            high += l.cost * (Decimal(1) + band)
        else:
            low += l.cost
            high += l.cost
        by_area[l.mi_tag] += l.cost
    return EstimateResult(
        total_low=low,
        total_expected=expected,
        total_high=high,
        by_business_area=dict(by_area),
        lines=tuple(lines),
        shared_cost=shared_cost,
    )


# ---------------------------------------------------------------------------
# STAGE 5 — SANITY CHECKER
# ---------------------------------------------------------------------------
def sanity_check(result: EstimateResult, low_range: Decimal,
                 high_range: Decimal, archetype_name: str) -> list[str]:
    w: list[str] = []
    exp = result.total_expected
    if exp < low_range:
        w.append(
            f"Total £{exp:,.0f} is BELOW the typical range for "
            f"'{archetype_name}' (£{low_range:,.0f}–£{high_range:,.0f}). "
            f"Check usage assumptions or a missing component."
        )
    if exp > high_range:
        w.append(
            f"Total £{exp:,.0f} is ABOVE the typical range for "
            f"'{archetype_name}' (£{low_range:,.0f}–£{high_range:,.0f}). "
            f"Check for an oversized assumption."
        )
    return w


# ---------------------------------------------------------------------------
# ORCHESTRATION — chain all five stages (this is what EstimateService calls)
# ---------------------------------------------------------------------------
def run_estimate(spec: SolutionSpec, catalogue: CatalogueView,
                 priced_on: date, band: Decimal = DEFAULT_BAND) -> EstimateResult:
    archetype = catalogue.archetype(spec.archetype_code)

    lines = resolve(spec, catalogue)                       # 1
    priced = apply_prices(lines, catalogue, priced_on)     # 2
    costed = calculate(priced, catalogue)                  # 3
    result = aggregate(costed, band=band)                  # 4

    warnings: list[str] = []
    if archetype is not None:
        warnings = sanity_check(result, archetype.low_range,
                                archetype.high_range, archetype.name)  # 5

    # attach warnings + priced_on (rebuild frozen result)
    return EstimateResult(
        total_low=result.total_low,
        total_expected=result.total_expected,
        total_high=result.total_high,
        by_business_area=result.by_business_area,
        lines=result.lines,
        warnings=tuple(warnings),
        priced_on=priced_on,
        shared_cost=result.shared_cost,
    )


# ---------------------------------------------------------------------------
# OBSERVABILITY COVERAGE (Epic 2 AC4-6)
# ---------------------------------------------------------------------------
# The observability categories a well-instrumented AI solution is expected to cover.
EXPECTED_OBSERVABILITY = ("logging", "tracing", "metrics", "alerting")

def observability_coverage(spec: SolutionSpec, catalogue: CatalogueView,
                           expected: tuple[str, ...] = EXPECTED_OBSERVABILITY) -> dict:
    """Report which observability categories the solution's components cover.
    Observability items are ordinary priceable components (they already flow
    through the five stages) — this is a SEPARATE completeness check on top.
    Returns coverage %, the covered/missing categories, and a warning if empty
    (Epic 2 AC6: no observability => the estimate is understated by ~5-15%)."""
    covered: set[str] = set()
    for sc in spec.components:
        comp = catalogue.get(sc.component_code)
        if comp is None:
            continue
        if comp.component_type == ComponentType.OBSERVABILITY and comp.observability_category:
            covered.add(comp.observability_category)
    covered &= set(expected)
    missing = [c for c in expected if c not in covered]
    pct = (Decimal(len(covered)) / Decimal(len(expected)) * 100) if expected else Decimal(0)
    warnings: list[str] = []
    if not covered:
        warnings.append(
            "No observability components in this solution — real running cost is "
            "typically understated by ~5-15%. Add logging/tracing/metrics/alerting."
        )
    elif missing:
        warnings.append(
            f"Partial observability: missing {', '.join(missing)}. "
            f"Cost may be slightly understated."
        )
    return {
        "coverage_pct": pct,
        "covered": sorted(covered),
        "missing": missing,
        "warnings": warnings,
    }
def project_monthly(spec: SolutionSpec, catalogue: CatalogueView, priced_on: date,
                    months: int = 12) -> list[Decimal]:
    """Return a list of monthly expected costs over `months`, applying the
    usage's month-on-month growth rate compounded. Month 1 = base monthly cost;
    month n = base * (1 + growth)^(n-1). Recurring infra and usage both grow with
    volume here (a simple, transparent model). Fixed one-off licences are included
    in every month's base — see note. Pure: repeated 1-month estimates, no new maths."""
    u = _effective_usage(spec, catalogue)
    growth = u.growth_rate_monthly

    # base = a single month's expected cost (force horizon to 1 month)
    one_month_usage = replace(u, time_horizon_months=1)
    base_spec = replace(spec, usage=one_month_usage)
    base = run_estimate(base_spec, catalogue, priced_on).total_expected

    series: list[Decimal] = []
    factor = Decimal(1)
    for _ in range(months):
        series.append(base * factor)
        factor *= (Decimal(1) + growth)
    return series


def project_total(spec: SolutionSpec, catalogue: CatalogueView, priced_on: date,
                  months: int = 12) -> Decimal:
    """Sum of the monthly projection (the true multi-month total WITH growth)."""
    return sum(project_monthly(spec, catalogue, priced_on, months), Decimal(0))


# ---------------------------------------------------------------------------
# MODEL COMPARISON (Epic 5) — run the same solution against alternative models
# ---------------------------------------------------------------------------
def compare_models(spec: SolutionSpec, catalogue: CatalogueView, priced_on: date,
                   model_codes: list[str], swap_from: str) -> dict[str, EstimateResult]:
    """Run the SAME solution once per candidate model and return {model: result}.
    Swaps the component whose code == swap_from for each candidate. Pure — just
    repeated run_estimate calls; no new costing logic. This is how the projection
    chart gets its 'selected model + 2 alternatives' curves."""
    out: dict[str, EstimateResult] = {}
    for model_code in model_codes:
        swapped = tuple(
            replace(sc, component_code=model_code) if sc.component_code == swap_from else sc
            for sc in spec.components
        )
        variant = replace(spec, components=swapped)
        out[model_code] = run_estimate(variant, catalogue, priced_on)
    return out
