"""
run_db_tests.py — prove the DB wiring is faithful:
 1. Load the catalogue FROM SQLITE and run the same RAG estimate
    -> must equal the in-memory result to the penny (£111,116.80).
 2. Dated pricing works from the DB (2025 estimate uses the old £60 price).
 3. Save an estimate -> immutable rows in the DB -> read it back identical.
 4. Prove immutability: change the live price in the DB; the SAVED estimate
    still shows the old numbers (frozen), while a NEW estimate uses the new price.

Run:  python run_db_tests.py     (after creating calculator.db from schema.sql + seed.sql)
"""
from __future__ import annotations
from datetime import date
from decimal import Decimal

from domain import SolutionSpec, SolutionComponent, UsageAssumptions
from repository import SqliteCatalogueRepository
import engine

D = Decimal
TODAY = date(2026, 6, 28)

PASS, FAIL = 0, 0
def check(name, cond):
    global PASS, FAIL
    if cond: PASS += 1; print(f"  PASS  {name}")
    else:    FAIL += 1; print(f"  FAIL  {name}")

def approx(a, b, tol=D("0.01")):
    return abs(D(a) - D(b)) <= tol


import os
DB = "../db/calculator.db" if os.path.exists("../db/calculator.db") else "calculator.db"
repo = SqliteCatalogueRepository(DB)

# ----------------------------------------------------------------------
print("\nDB TEST 1 — catalogue from SQLite produces IDENTICAL numbers")
cat = repo.load_catalogue()
spec = SolutionSpec(
    "rag_assistant",
    (SolutionComponent("gpt4o", D(1)), SolutionComponent("embed", D(1)),
     SolutionComponent("aisearch", D(1)), SolutionComponent("pega", D(2))),
    UsageAssumptions(requests_per_month=10_000, input_tokens_per_request=1_500,
                     output_tokens_per_request=300, calls_per_request=D(3),
                     time_horizon_months=12),
    "Mortgages")
r = engine.run_estimate(spec, cat, priced_on=TODAY)
check("total from DB catalogue = 111116.80", approx(r.total_expected, D("111116.80")))
check("MI split AI = 5440.80", approx(r.by_business_area.get("AI", 0), D("5440.80")))
check("MI split Platform = 5676.00", approx(r.by_business_area.get("Platform", 0), D("5676.00")))
check("MI split Mortgages = 100000", approx(r.by_business_area.get("Mortgages", 0), D("100000.00")))

# ----------------------------------------------------------------------
print("\nDB TEST 2 — dated pricing from the DB (price history)")
spec_app = SolutionSpec("tiny", (SolutionComponent("appsvc", D(1)),),
                        UsageAssumptions(time_horizon_months=1), None)
r_now = engine.run_estimate(spec_app, cat, priced_on=date(2026, 6, 28))
r_old = engine.run_estimate(spec_app, cat, priced_on=date(2025, 6, 1))
check("current price row used (73)", approx(r_now.total_expected, D("73.00")))
check("2025 estimate uses closed-off old price (60)", approx(r_old.total_expected, D("60.00")))

# ----------------------------------------------------------------------
print("\nDB TEST 3 — save the estimate, read it back")
est_id = repo.save_estimate(spec, r, created_by="madhurjya")
stored = repo.get_estimate(est_id)
check("estimate saved and retrievable", stored is not None)
check("stored total matches", approx(stored["total_expected"], r.total_expected))
check("stored line count matches", len(stored["lines"]) == len(r.lines))
check("created_by recorded", stored["created_by"] == "madhurjya")
pega_lines = [l for l in stored["lines"] if "PEGA" in l["component_name"]]
check("frozen line has unit_price_used", pega_lines and approx(pega_lines[0]["unit_price_used"], D("50000")))

# ----------------------------------------------------------------------
print("\nDB TEST 4 — immutability: price change does NOT alter the saved estimate")
import sqlite3
conn = sqlite3.connect(DB)
# close off the current pega price and insert a new (doubled) one from tomorrow
conn.execute("UPDATE price SET effective_to='2026-06-29' WHERE component_code='pega' AND effective_to IS NULL")
conn.execute("INSERT INTO price (component_code,unit,unit_price,currency,effective_from,effective_to) VALUES ('pega','licence','100000.00','USD','2026-06-29',NULL)")
conn.commit(); conn.close()

# saved estimate unchanged
stored_after = repo.get_estimate(est_id)
check("saved estimate STILL shows old total (frozen)", approx(stored_after["total_expected"], D("111116.80")))

# a NEW estimate priced after the change uses the NEW price
cat2 = repo.load_catalogue()   # fresh snapshot picks up the new price row
r_new = engine.run_estimate(spec, cat2, priced_on=date(2026, 6, 29))
# pega doubles: +100000 -> total = 111116.80 + 100000 = 211116.80
check("new estimate uses NEW price (211116.80)", approx(r_new.total_expected, D("211116.80")))
# and re-pricing on the OLD date still gives the OLD total (reproducibility)
r_repro = engine.run_estimate(spec, cat2, priced_on=TODAY)
check("re-running on the old date reproduces old total", approx(r_repro.total_expected, D("111116.80")))

print(f"\n==== DB RESULTS: {PASS} passed, {FAIL} failed ====")
