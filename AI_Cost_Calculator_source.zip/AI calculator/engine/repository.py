"""
repository.py — loads a CatalogueView from the SQLite database.

This replaces the hand-built seed data with a real DB read. The engine is
untouched: it receives the same CatalogueView object and cannot tell the
difference. In production this becomes a SQLAlchemy repository against
Azure SQL; the shape is identical.

Also provides save_estimate(): persists an EstimateResult as an immutable
ESTIMATE + frozen ESTIMATE_LINE rows (insert-only, prices copied in).
"""
from __future__ import annotations
import json
import sqlite3
import uuid
from datetime import date
from decimal import Decimal

from domain import (
    Component, Price, PricingModel, Tier, Dependency, Archetype,
    ComponentType, PricingModelType, EstimateResult, SolutionSpec,
)
from catalogue import CatalogueView


def _dec(s) -> Decimal:
    return Decimal(str(s))


class SqliteCatalogueRepository:
    def __init__(self, db_path: str):
        self._path = db_path

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    # ---------- load the full catalogue snapshot ----------
    def load_catalogue(self) -> CatalogueView:
        conn = self._conn()
        try:
            # pricing models + tiers
            tiers_by_model: dict[str, list[Tier]] = {}
            for r in conn.execute("SELECT model_code, lower_bound, upper_bound, rate FROM pricing_tier ORDER BY CAST(lower_bound AS REAL)"):
                tiers_by_model.setdefault(r["model_code"], []).append(
                    Tier(_dec(r["lower_bound"]), _dec(r["upper_bound"]), _dec(r["rate"]))
                )
            models = [
                PricingModel(r["code"], PricingModelType(r["type"]),
                             tuple(tiers_by_model.get(r["code"], [])))
                for r in conn.execute("SELECT code, type FROM pricing_model")
            ]

            components = [
                Component(
                    code=r["code"], name=r["name"],
                    component_type=ComponentType(r["component_type"]),
                    approved=bool(r["approved"]),
                    pricing_model_code=r["pricing_model_code"],
                    default_unit=r["default_unit"],
                    mi_tag=r["mi_tag"],
                    observability_category=r["observability_category"],
                )
                # archived components are invisible to the engine: they can't
                # be estimated, exactly like unapproved ones (Epic 7 AC3)
                for r in conn.execute("SELECT * FROM component WHERE archived=0")
            ]

            prices = [
                Price(
                    component_code=r["component_code"], unit=r["unit"],
                    unit_price=_dec(r["unit_price"]), currency=r["currency"],
                    effective_from=date.fromisoformat(r["effective_from"]),
                    effective_to=(date.fromisoformat(r["effective_to"])
                                  if r["effective_to"] else None),
                )
                for r in conn.execute("SELECT * FROM price")
            ]

            dependencies = [
                Dependency(r["component_code"], r["requires_code"], _dec(r["ratio"]))
                for r in conn.execute("SELECT * FROM component_dependency")
            ]

            archetypes = []
            for r in conn.execute("SELECT * FROM archetype"):
                du = json.loads(r["default_usage"]) if r["default_usage"] else {}
                archetypes.append(Archetype(
                    code=r["code"], name=r["name"],
                    low_range=_dec(r["low_range"]), high_range=_dec(r["high_range"]),
                    default_usage=du,
                ))

            return CatalogueView(components, prices, models, dependencies, archetypes)
        finally:
            conn.close()

    # ---------- persist an immutable estimate ----------
    def save_estimate(self, spec: SolutionSpec, result: EstimateResult,
                      created_by: str = "system", name: str | None = None,
                      description: str | None = None,
                      assumptions_json: str | None = None) -> str:
        """Insert-only: a SOLUTION row (+ its chosen components), an ESTIMATE row,
        and frozen ESTIMATE_LINEs with the prices COPIED in. Returns the estimate id."""
        conn = self._conn()
        try:
            solution_id = str(uuid.uuid4())
            estimate_id = str(uuid.uuid4())
            usage_json = json.dumps({
                "requests_per_month": spec.usage.requests_per_month,
                "input_tokens_per_request": spec.usage.input_tokens_per_request,
                "output_tokens_per_request": spec.usage.output_tokens_per_request,
                "cached_input_tokens_per_request": spec.usage.cached_input_tokens_per_request,
                "calls_per_request": str(spec.usage.calls_per_request),
                "eligibility_rate": str(spec.usage.eligibility_rate),
                "time_horizon_months": spec.usage.time_horizon_months,
                "growth_rate_monthly": str(spec.usage.growth_rate_monthly),
            })
            conn.execute(
                "INSERT INTO solution (id, name, description, archetype_code, usage_assumptions, business_area) VALUES (?,?,?,?,?,?)",
                (solution_id, name, description, spec.archetype_code, usage_json, spec.business_area))
            for sc in spec.components:
                conn.execute(
                    "INSERT INTO solution_component (solution_id, component_code, quantity, shared) VALUES (?,?,?,?)",
                    (solution_id, sc.component_code, str(sc.quantity), 1 if sc.shared else 0))
            conn.execute(
                "INSERT INTO estimate (id, solution_id, total_low, total_expected, total_high, priced_on, created_by, assumptions_json) VALUES (?,?,?,?,?,?,?,?)",
                (estimate_id, solution_id, str(result.total_low), str(result.total_expected),
                 str(result.total_high), result.priced_on.isoformat(), created_by,
                 assumptions_json))
            for l in result.lines:
                conn.execute(
                    "INSERT INTO estimate_line (estimate_id, component_name, unit, quantity, unit_price_used, line_total, mi_tag, shared) VALUES (?,?,?,?,?,?,?,?)",
                    (estimate_id, l.priced.component.name, l.priced.unit,
                     str(l.priced.quantity), str(l.priced.unit_price),
                     str(l.cost), l.mi_tag, 1 if l.shared else 0))
            conn.commit()
            return estimate_id
        finally:
            conn.close()

    # ---------- read a stored estimate back ----------
    def get_estimate(self, estimate_id: str) -> dict | None:
        conn = self._conn()
        try:
            e = conn.execute("SELECT * FROM estimate WHERE id=?", (estimate_id,)).fetchone()
            if e is None:
                return None
            lines = conn.execute(
                "SELECT * FROM estimate_line WHERE estimate_id=?", (estimate_id,)).fetchall()
            sol = conn.execute("SELECT * FROM solution WHERE id=?", (e["solution_id"],)).fetchone()
            comps = conn.execute(
                "SELECT component_code, quantity, shared FROM solution_component WHERE solution_id=?",
                (e["solution_id"],)).fetchall()
            actuals = conn.execute(
                "SELECT period, amount, recorded_at FROM estimate_actual WHERE estimate_id=? ORDER BY period",
                (estimate_id,)).fetchall()
            return {
                "id": e["id"],
                "total_low": _dec(e["total_low"]),
                "total_expected": _dec(e["total_expected"]),
                "total_high": _dec(e["total_high"]),
                "priced_on": e["priced_on"],
                "created_by": e["created_by"],
                "assumptions_json": e["assumptions_json"],
                "lines": [dict(l) for l in lines],
                "solution": {
                    "name": sol["name"] if sol else None,
                    "description": sol["description"] if sol else None,
                    "archetype_code": sol["archetype_code"] if sol else None,
                    "business_area": sol["business_area"] if sol else None,
                    "usage": json.loads(sol["usage_assumptions"]) if sol and sol["usage_assumptions"] else {},
                    "components": [dict(c) for c in comps],
                },
                "actuals": [dict(a) for a in actuals],
            }
        finally:
            conn.close()

    # ---------- list saved estimates (Epic 6) ----------
    def list_estimates(self, limit: int = 50) -> list[dict]:
        conn = self._conn()
        try:
            rows = conn.execute(
                "SELECT e.id, s.name, s.archetype_code, s.business_area, "
                "       e.total_expected, e.priced_on, e.created_at, e.created_by "
                "FROM estimate e JOIN solution s ON s.id = e.solution_id "
                "ORDER BY e.created_at DESC, e.rowid DESC LIMIT ?", (limit,)).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    # ---------- actuals against a frozen estimate (Epic 8) ----------
    def add_actual(self, estimate_id: str, period: str, amount: str) -> bool:
        conn = self._conn()
        try:
            e = conn.execute("SELECT id FROM estimate WHERE id=?", (estimate_id,)).fetchone()
            if e is None:
                return False
            conn.execute(
                "INSERT INTO estimate_actual (estimate_id, period, amount) VALUES (?,?,?)",
                (estimate_id, period, amount))
            conn.commit()
            return True
        finally:
            conn.close()
