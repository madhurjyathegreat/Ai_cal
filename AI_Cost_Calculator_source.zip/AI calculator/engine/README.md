# Machine 1 — Deterministic Costing Engine

The deterministic core of the AI Cost Calculator. No AI. Pure, testable, auditable.

## Files
- `domain.py`     — frozen value objects + data model (Component, Price, etc.)
- `catalogue.py`  — in-memory snapshot the engine reads (no DB calls in the engine)
- `engine.py`     — the five-stage pipeline (resolve → price → calculate → aggregate → sanity)
- `run_tests.py`  — seed data + assertions; run this to verify the logic

## Run
```
python run_tests.py      # 25 assertions, all pass
```

## Design rules enforced
- Prices live in data (the catalogue), never in code.
- Money is Decimal, never float.
- Each stage is a pure function — unit-testable in isolation.
- Estimates freeze the price + date used (reproducible).
- Unapproved components are hard-rejected.
- AI usage = raw metered numbers in; engine never interprets free text.
- Archetypes pre-fill omitted usage numbers (data-driven defaults; user overrides win).
- Dependencies are expanded transitively, cycle-safely, and de-duplicated.
- Output is a low/expected/high RANGE, split by business area (MI tags).

## A bug we found and fixed (kept as a note)
Dependencies (e.g. App Service implied by GPT-4o) were not being multiplied by the
time horizon — charged 1 month instead of 12. Fixed by routing BOTH direct and
dependency lines through `_line_quantity()`. Caught by the hand-calculated assertion
in Test 1. This is exactly why each stage has explicit expected-value tests.
