"""
advisor.py — the AI advisor BOUNDARY (Epic 11). Deliberately a stub.

The advisor's only power is to PROPOSE approved components; it never prices
anything. Proposals re-enter the deterministic pipeline at stage 1 exactly as
if a human had typed them — same validation, same rejection of unapproved
components, same pricing. A human must sign off every suggestion (Epic 11 AC4)
BEFORE it is added to a SolutionSpec.

The real implementation (LangGraph, RAG-grounded on the approved catalogue) is
Post-MVP and gated on NBS AI Council approval. Nothing in the engine blocks on
it: swap NoOpAdvisor for a real one and no other file changes.
"""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal
from typing import Protocol, runtime_checkable

from catalogue import CatalogueView


@dataclass(frozen=True)
class ComponentSuggestion:
    """One proposed component. `rationale` is display-only — the engine never
    reads it; humans do, when deciding whether to accept (Epic 11 AC5)."""
    component_code: str
    quantity: Decimal
    rationale: str


@runtime_checkable
class AdvisorPort(Protocol):
    """The seam the future AI advisor plugs into. Implementations take a
    plain-language description plus the catalogue snapshot and return
    suggestions of APPROVED components only. They never compute cost."""

    def suggest(self, description: str,
                catalogue: CatalogueView) -> list[ComponentSuggestion]: ...


class NoOpAdvisor:
    """Phase-1 implementation: suggests nothing. Keeps the boundary honest —
    callers are written against AdvisorPort today, so the real advisor is a
    drop-in later."""

    def suggest(self, description: str,
                catalogue: CatalogueView) -> list[ComponentSuggestion]:
        return []
